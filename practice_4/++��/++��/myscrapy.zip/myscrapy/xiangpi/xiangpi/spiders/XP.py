# -*- coding: utf-8 -*-
from xiangpi.items import XiangpiItem
import scrapy

import json
import datetime
import hashlib
import time
import re


class XpSpider(scrapy.Spider):
    name = 'XP'
    html_id = 10
    allowed_domain = ['xiangpi.com']
    #allowed_domains = ['http://www.xiangpi.com/tiku/3600817.html']
    #start_urls = ['http://www.xiangpi.com/tiku/3600817.html/']

    def start_requests(self):
        for i in range(250, 255):
            url = "http://www.xiangpi.com/tiku/"+str(i)+".html/"
            yield scrapy.Request(url=url,meta={'url':url},callback=self.parse)

    def parse(self, response):
        # sleep防止抓取速度过快
        time.sleep(0.1)
        questions = XiangpiItem()
        if response.status == 200:
            print(str(response))
            self.html_id += 1
            questions['key'] = response.meta['url']
            questions['html_id'] = int(self.html_id)
            questions['source'] = 80
            questions['subject'] = 0
            questions['source_id'] = re.findall(
                r'.*?tiku/(.*?).html', str(response))[0]
            questions['html'] = response.xpath('//div[@class="content clearfix dvs2"]').extract()
            m2 = hashlib.md5()
            m2.update(response.text.encode('utf-8'))
            questions['md5'] = m2.hexdigest()
            questions['record_time'] = datetime.datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')
            questions['request_info'] = str(
                {'GET ': '/1/ HTTP/1.1', 'Host': 'www.xiangpi.com'})
            questions['info'] = ''
            questions['flag_str'] = ''

            if int(str(response)[1:4]) != 200:
                questions['flag'] = 1
            else:
                questions['flag'] = None

            print('-'*50)
            print("完成第%d条数据摘取" % self.html_id)

            print(questions)
            # yield questions



        

# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql

class writeSQL(object):

    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  #使用自己的用户名 
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'   
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        values = (
        item['html_id'], 
        item['source'], 
        item['subject'], 
        item['html'], 
        item['md5'], 
        item['key'],
        item['request_info'],
        item['info'],
        item['record_time'],
        item['flag'],
        item['flag_str'],
        item['book_id'],

        )
        sql = 'INSERT INTO 1010jiajiao_spider_html_archive_table_1105 VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)' 
        self.db_cur.execute(sql, values)

# -*- coding: utf-8 -*-
from jiajiao1010_book.items import Jiajiao1010Item
import scrapy
import json
import datetime
import hashlib
import time
import re
import logging
import requests


class JjbookSpider(scrapy.Spider):
    name = 'JJBOOK'
    html_id = 2800
  

    def start_requests(self):
        for i in range(100, 200):
            for j in range(53800,53840):
                url = "http://www.1010jiajiao.com/daan/workbook.php?action=edit&bookid="+str(i)+"&chapterid="+str(j)
                print(url)
                yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
         # sleep防止抓取速度过快
        time.sleep(0.1)
        questions = Jiajiao1010Item()
        if response.xpath('//div[@class="xiti"]'):
    
            for i in response.css('div.xiti'):
                 #print(i)
                self.html_id += 1


            questions['html_id'] = int(self.html_id)
            questions['source'] = 65
            questions['subject'] = 0
            questions['html'] = i.extract()
            source_id = re.findall(
            r'.*?qid="(.*?)".*?', i.extract())[0]
            m2 = hashlib.md5()
            m2.update(i.extract().encode('utf-8'))
            questions['md5'] = m2.hexdigest()
            questions['key'] = "1010jiajiao_book_qs_" + source_id
            paper_name = response.css("div.ndwz strong::text").extract()[0]
            paper_name = re.findall(r'.*?> (.*?) >.*?', paper_name)[0]
            paper_url = str(response)[5:-1]
            questions['info'] = str({'paper_url':paper_url,'paper_name':paper_name})
            questions['record_time'] = datetime.datetime.now().strftime(
                 '%Y-%m-%d %H:%M:%S')
            questions['request_info'] = ''
            questions['flag_str'] = ''
            questions['book_id'] = re.findall(r'.*?bookid=(.*?)&chapterid=.*?', str(response))[0]
            if int(str(response)[1:4]) != 200:
                questions['flag'] = 0
            else:
                questions['flag'] = None

            print('-'*50)
            print("完成第%d条数据摘取" % self.html_id)

            yield questions

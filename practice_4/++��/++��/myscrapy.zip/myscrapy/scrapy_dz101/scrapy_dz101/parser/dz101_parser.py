#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019-08-30 11:26
# @Author: xiaopeng

import threading
import logging
import json
import re
import pymysql
import copy
from functools import reduce
from pyquery import PyQuery as pq
from bs4 import BeautifulSoup
from exceptions import DifficultyNotFoundError, TypeNotFoundError
from parse_utils import ParseUtil
from util import (db,
                  subject_mapping,
                  grade_mapping,
                  difficulty_mapping,
                  type_mapping)


class Dz101Parser(ParseUtil):
    def __init__(self, origin_table, destination_db, destination_table, pc, cc):
        # 通过父类连接需要被解析的源数据库db和表,配置在util.py文件中
        super().__init__(origin_table, db, destination_db, destination_table)
        self.max_id = self.db_max_id
        self.min_id = self.db_min_id
        # 处理线程数
        self.proccess_count = pc
        # 每个线程处理id范围
        self.cross_count = cc

    def run(self):
        for i in range(self.min_id, self.max_id + 1, self.proccess_count * self.cross_count):
            start_id = i
            end_id = self.proccess_count * self.cross_count + start_id
            if end_id > self.max_id + 1:
                end_id = self.max_id + 1
            self.sub_run(start_id, end_id)

    def sub_run(self, start_id, end_id):
        threads = []
        for j in range(start_id, end_id, self.cross_count):
            s = j
            e = j + self.cross_count
            if e > self.max_id + 1:
                e = self.max_id + 1
            t = threading.Thread(target=self.parser, args=(s, e, ))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()
        logging.info('sub_run from {} to {} is end'.format(start_id, end_id))

    @staticmethod
    def deal_sub_ques(content, type_):
        pattern = re.compile(r'<XHTML.*?>(.*?)</XHTML>', re.S | re.I)
        title = re.findall(pattern, content[0]['elementContent'])
        options = []
        answers = []
        jiexi = ""
        solution = ""
        comment = ""
        hint = ""
        if type_ in ['单选题', '不定项选择题']:
            for item in content:
                if '选项' in item['elementName']:
                    options.append(
                        {
                            'Key': item['elementName'].split('-')[1],
                            'Value': re.findall(pattern, item['elementContent'])[0]
                        }
                    )
                if item['elementName'] == '答案':
                    daans = re.findall(pattern, item['elementContent'])
                    for daan in daans[0].replace('、', '').strip():
                        order = ord(daan.upper()) - 65
                        if order < 0 or order > 25:
                            solution = daans[0]
                            break
                        answers.append(str(order))
                if item['elementName'] == '解析':
                    jiexi = re.findall(pattern, item['elementContent'])[0]
        else:
            for item in content:
                if item['elementName'] == '答案':
                    solution = re.findall(pattern, item['elementContent'])[0]
                if item['elementName'] == '解析':
                    jiexi = re.findall(pattern, item['elementContent'])[0]
        sub_dict = {
            'content': title[0],
            'options': None if not options else options,
            'answers': answers,
            'analyse': jiexi,
            'solution': solution,
            'comment': comment,
            'hint': hint,
        }
        return sub_dict

    def deal_no_sub_ques(self, type_, ques):
        origin = {
            "formate_version": 1,
        }
        item_name = [item['elementName'] for item in ques]
        if '子题目' in item_name:
            item_name.append('子题目')
            pattern = re.compile(r'<XHTML.*?>(.*?)</XHTML>', re.S | re.I)
            title = re.findall(pattern, ques[0]['elementContent'])
            sub_ques = []
            sub_index = [i for i in range(len(item_name)) if item_name[i] == '子题目']
            for j in range(len(sub_index) - 1):
                sub_question = ques[sub_index[j]:sub_index[j+1]]
                sub_dict = {'number': j + 1}
                sub_dict.update(self.deal_sub_ques(sub_question, type_))
                sub_ques.append(sub_dict)
            origin.update(
                {
                    'content': title[0] if title else '',
                    'options': None,
                    'answers': [],
                    'analyse': '',
                    'solution': '',
                    'comment': '',
                    'hint': '',
                    'sub_question': sub_ques,
                }
            )
            # print(json.dumps(origin, ensure_ascii=False))
        else:
            origin.update(
                self.deal_sub_ques(ques, type_),
            )
            origin['sub_question'] = []

        return origin

    # 针对不同的spider_source进行不同的解析
    def parser(self, s, e):
        # 参数为起始id,结束id和要解析的表名
        questions = self.choose_ques(s, e)
        for question in questions:
            if self.is_archive(question['key']):
                print('had added:{}'.format(question['key']))
                continue
            content = question['content']
            pattern = re.compile(r'"elementContent": "(.*?)"[,}]', re.S | re.I)
            results = re.findall(pattern, content)
            for result in results:
                content = content.replace(result, result.replace('"', '\\"'))

            content_json = json.loads(content)
            sub_gra = content_json.get('subject', '')
            subject = sub_gra[2:]
            grade = content_json.get('grade', '')

            difficulty = content_json.get('difficulty', '')
            difficulty_num = {'低': 3, '中': 6, '高': 9}[difficulty]
            type_ = content_json.get('type', '')
            origin = self.deal_no_sub_ques(type_, content_json['content'])
            latex = self.origin_to_latex(origin)
            html = self.latex_to_html(latex)
            # print(json.dumps(latex, ensure_ascii=False))
            extro_info = {
                "subject": sub_gra,
                "grade": grade,
                "type": type_,
                "book": content_json.get('teachCascade', ''),
                "province": content_json.get('province', ''),
                "year": content_json.get('year', ''),
                "sourceType": content_json.get('sourceType', ''),
                "quality": content_json.get('quality', ''),
                "key": content_json.get('key', ''),
            }
            item = {
                "question_id": 0,
                "source": question['source'],
                "key": question['key'],
                "subject": subject_mapping.get(subject, 0),
                "grade": grade_mapping.get(grade, 0),
                "difficulty": difficulty_num,
                "type": type_mapping.get(type_, 0),
                "knowledge_point": [],
                "extra_info": extro_info,
                "origin": origin,
                "latex": latex,
                "html": html,
            }
            for key in ['extra_info', 'knowledge_point', 'origin', 'latex', 'html']:
                item[key] = pymysql.escape_string(json.dumps(item[key],ensure_ascii=False))
            try:
                self.save_item(item)
                print(item['key'])
            except Exception as e:
                raise e


if __name__ == '__main__':
    # 原数据表，目标数据库，解析表，线程数，单个线程处理id个数
    z = Dz101Parser('dz101_html_archive', 'test', 'dz101_parsed_question', 1, 10000)
    z.run()



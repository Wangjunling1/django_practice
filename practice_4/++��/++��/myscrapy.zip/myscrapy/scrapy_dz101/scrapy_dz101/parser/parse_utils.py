#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019-08-16 15:20
# @Author: xiaopeng
import requests
import logging
import json
import copy
import pymysql
import re
from afanti_tiku_lib.question_template.question_template import Question
from exceptions import ParseTypeError

logging.basicConfig(level=logging.DEBUG,
                    filename='parseutil.log',
                    filemode='a',
                    format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                    )


class ParseUtil(object):
    render_url = "http://172.16.0.100:30001/render_latex/"
    # 去重表
    dumplicate_db = 'question_pre'
    dumplicate_table = 'question'

    def __init__(self, name, origin_db_pool, destination_db, destination_table, success_count=0, failed_count=0):
        # 被解析的表名
        self.name = name
        self.success_count = success_count
        self.failed_count = failed_count
        self.origin_db = origin_db_pool
        # 解析后的数据库的目标库名和表名
        self.destination_db = destination_db
        self.destination_table = destination_table

    # 按照解析表和question_pre.question表去重
    def is_archive(self, key):
        sql = "select `spider_url` from %s.%s where `spider_url` = '%s'" % (self.dumplicate_db,
                                                                            self.dumplicate_table,
                                                                            key)
        sql_parsed = "select `key` from %s.%s where `key` = '%s'" % (self.destination_db,
                                                                     self.destination_table,
                                                                     key)
        if self.origin_db.select(sql) or self.origin_db.select(sql_parsed):
            return True
        return False

    @staticmethod
    def recorrect_html(self, html):
        if not isinstance(html, str):
            raise ParseTypeError('str', type(html), 'recorrect_html\'s html')
        return html.replace('"', '\\"').replace('\'', '\'\'')

    # latex绘制
    def render_latex(self, html):
        data = {"html": html}
        r = requests.post(self.render_url, data=data)
        if r.status_code != 200:
            return ""

        content = json.loads(r.content)
        if content["meta"]["status"] != 0:
            return ""
        return content["data"]

    # origin字段转渲染后的latex字段
    def origin_to_latex(self, origin):
        latex = copy.deepcopy(origin)
        for key in latex.keys():
            if key in ['content', 'analyse', 'solution']:
                latex[key] = self.render_latex(latex[key])
            if latex['sub_question']:
                for sub in latex['sub_question']:
                    for sub_key in sub.keys():
                        if sub_key in ['content', 'analyse', 'solution']:
                            sub[sub_key] = self.render_latex(sub[sub_key])
        return latex

    def choose_ques(self, sid, eid):
        sql = "select * from %s where `id` >= %d and `id` < %d" % (self.name,
                                                                   sid,
                                                                   eid)
        return self.origin_db.select(sql)

    # 根据提供的库名，表名存储数据
    def save_item(self, question_item):
        sql = '''insert into %s.%s (`question_id`,`source`,`key`,`subject`,`grade`,`difficulty`,\
                                            `type`,`knowledge_point`,`origin`,`latex`,`html`,`extra_info`\
                                            ) values(%d, %d, '%s', %d, %d, %d, '%s', '%s', '%s','%s','%s','%s')
                                            ''' % (self.destination_db,
                                                   self.destination_table,
                                                   question_item['question_id'],
                                                   question_item['source'],
                                                   question_item['key'],
                                                   question_item['subject'],
                                                   question_item['grade'],
                                                   question_item['difficulty'],
                                                   question_item['type'],
                                                   question_item['knowledge_point'],
                                                   question_item['origin'],
                                                   question_item['latex'],
                                                   question_item['html'],
                                                   question_item['extra_info'],
                                                   )
        self.origin_db.insert_all_case(sql)

    @staticmethod
    def to_option(answer):
        chapter = ''
        for num in answer:
            chapter += chr(int(num) + 65)
        return chapter.upper()

    # origin或latex转html
    def latex_to_html(self, latex):
        main_op = []
        for opt in ([] if not latex['options'] else latex['options']):
            main_op.append(
                {
                    'value': opt['Key'],
                    'content': opt['Value']
                }
            )
        s = {'knowledge_point': '', 'paper_name': '', 'question_body': latex['content'], 'option_lst': main_op,
             'answer': latex['solution'], 'analy': latex['analyse'], 'comment': latex['comment'],
             'sub_question_lst': []}

        if latex['sub_question']:
            for sub in latex['sub_question']:
                options = []
                for op in ([] if not sub['options'] else sub['options']):
                    options.append(
                        {
                            'value': op['Key'],
                            'content': op['Value']
                        }
                    )
                sub_ques = {
                    'knowledge_point': '',
                    'paper_name': '',
                    'question_body': sub['content'],
                    'option_lst': options,
                    'answer': sub['solution'],
                    'analy': sub['analyse'],
                    'sub_question_lst': []
                }
                s['sub_question_lst'].append(sub_ques)
        q = Question(**s)
        qs = q.normialize()

        answers = self.to_option(latex['answers']) if latex['answers'] else ''

        ans_html = ''
        hint_html = ''
        options_html = ''
        if not latex['sub_question']:
            if answers:
                ans_html += '<div class="aft_question_wrapper">%s</div>' % answers
            if latex['hint']:
                hint_html += '<div class="aft_question_wrapper">%s</div>' % latex['hint']
            pattern = re.compile(r'(<table class="aft_option_wrapper" style="width: 100%;">.*?</table>)', re.I | re.S)
            options_html = re.findall(pattern, qs['question_body'])
            if options_html:
                qs['question_body'] = qs['question_body'].replace(options_html[0], '')
        elif latex['sub_question']:
            for item in latex['sub_question']:
                ans = self.to_option(item['answers'])
                if ans:
                    ans_html += '<div class="aft_sub_question_wrapper">' \
                            '<i class="aft_sub_question_value">%s.</i>' \
                            '<div class="aft_sub_question_content">%s</div>' \
                            '</div>' % (item['number'], ans)
            for item in latex['sub_question']:
                if item['hint']:
                    hint_html += '<div class="aft_sub_question_wrapper">' \
                             '<i class="aft_sub_question_value">%s.</i>' \
                             '<div class="aft_sub_question_content">%s</div>' \
                             '</div>' % (item['number'], item['hint'])
        html = {
            "formate_version": latex['formate_version'],
            "content": qs['question_body'],
            "options": options_html[0] if options_html else '',
            "answers": ans_html,
            "analyse": qs['analy'],
            "solution": qs['answer'],
            "comment": qs['comment'],
            "hint": hint_html,
            "sub_question": [],
        }
        return html

    # 去除html标签
    @staticmethod
    def extract_html(html):
        pattern = re.compile(r'<[^>]+>', re.S)
        content = pattern.sub('', html['content'])
        answers = html['analyse'] + html['solution'] + html['comment'] + html['hint']
        answers = pattern.sub('', answers)
        result = {
                "formate_version": 1,
                "content": content,
                "answers": answers,
        }
        return result

    # 数据库最大id
    @property
    def db_max_id(self):
        sql = "select max(id) from %s" % self.name
        result = self.origin_db.select(sql)
        return result[0]['max(id)']

    # 数据库最小id
    @property
    def db_min_id(self):
        sql = "select min(id) from %s" % self.name
        result = self.origin_db.select(sql)
        return result[0]['min(id)']

    def __str__(self):
        return f"{self.__class__.__name__} of {self.name}"

    def __repr__(self):
        return f"'class_name':'{self.__class__.__name__}', " \
            f"'obj_name':'{self.name}', " \
            f"'success_count':{self.success_count}," \
            f"'failed_count':{self.failed_count}"

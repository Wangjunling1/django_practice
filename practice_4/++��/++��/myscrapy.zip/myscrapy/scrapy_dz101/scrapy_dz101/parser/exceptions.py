#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019-08-16 15:34
# @Author: xiaopeng


class ParseTypeError(Exception):
    def __init__(self, correct_type, wrong_type, error_info):
        super().__init__()
        self.correct_type = correct_type
        self.wrong_type = wrong_type
        self.error_info = error_info
        self.err = f'Type of {self.error_info} is {self.wrong_type}, correct_type is {self.correct_type}'

    def __str__(self):
        return self.err


class DifficultyNotFoundError(IndexError):
    def __init__(self, error_info):
        super().__init__()
        self.err = error_info

    def __str__(self):
        return  self.err


class TypeNotFoundError(IndexError):
    def __init__(self, error_info):
        super().__init__()
        self.error_info = error_info

    def __str__(self):
        return self.error_info



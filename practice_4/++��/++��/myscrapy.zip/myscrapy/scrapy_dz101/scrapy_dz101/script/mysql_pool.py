#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/8 11:59 AM
# @Author: xiaopeng

import os
import json
import pymysql
import logging
import configparser
from DBUtils.PooledDB import PooledDB


current_path = os.path.abspath('..')
cf = configparser.ConfigParser()
cf.read('{}/script/db_config.ini'.format(current_path))
db_config = {
    'host': cf.get('mysql', 'host'),
    'port': cf.get('mysql', 'port'),
    'user': cf.get('mysql', 'user'),
    'password': cf.get('mysql', 'password'),
    'db': cf.get('mysql', 'db'),
}


class MySQLPool(object):
    host = db_config['host']
    user = db_config['user']
    port = db_config['port']
    password = db_config['password']
    db = db_config['db']
    charset = 'utf8mb4'

    pool = None
    limit_count = 4  # 最低预启动数据库连接数量

    def __init__(self):
        self.pool = PooledDB(pymysql,
                             self.limit_count,
                             host=self.host,
                             user=self.user,
                             passwd=self.password,
                             db=self.db,
                             port=int(self.port),
                             charset=self.charset,
                             use_unicode=True,
                             cursorclass=pymysql.cursors.DictCursor)

    def is_archive(self, qid):
        sql = "select * from motk_html_archive where `key`='%s'" % (qid)
        conn = self.pool.connection()
        cursor = conn.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        if result:
            logging.warning('had added:{}'.format(qid))
            cursor.close()
            conn.close()
            return True
        cursor.close()
        conn.close()
        return False

    # 查询语句
    def select(self, sql):
        conn = self.pool.connection()
        cursor = conn.cursor()
        try:
            cursor.execute(sql)
            result = cursor.fetchall()
            return result
        except Exception as err:
            logging.warning('select failed:{}'.format(err))
            return None
        finally:
            cursor.close()
            conn.close()

    # 特定情况插入
    def insert(self, item):
        sql = '''
                                          insert into `dz101_html_archive`
                                          (`key`,`source`,`url`,`content`,`extra_info`,`spider_id`,`flag`)
                                          VALUES ('%s',%d,'%s','%s','%s',%d,%d)
                                         ''' % (item['key'], item['source'],
                                                item['url'],
                                                json.dumps(item['content'], ensure_ascii=False).replace("'","\'\'"),
                                                json.dumps(item['extra_info'], ensure_ascii=False),
                                                item['spider_id'],
                                                item['flag'])

        conn = self.pool.connection()
        cursor = conn.cursor()
        try:
            cursor.execute(sql)
            conn.commit()
            logging.warning('success:{}'.format(item['key']))
        except Exception as err:
            conn.rollback()
            logging.warning('failed:{},error:{}'.format(item['key'], err))
        finally:
            cursor.close()
            conn.close()

    # 所有情况插入
    def insert_all_case(self, sql):
        conn = self.pool.connection()
        cursor = conn.cursor()
        try:
            cursor.execute(sql)
            conn.commit()
            logging.warning('success')
        except Exception as err:
            conn.rollback()
            logging.warning('failed,error:{}'.format(err))
        finally:
            cursor.close()
            conn.close()

#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/12 3:18 PM
# @Author: xiaopeng
import redis
import json
# import random
import requests
import asyncio
from aiohttp import ClientSession
from mysql_pool import MySQLPool

pool = redis.ConnectionPool(host="127.0.0.1",
                                 port=6379,
                                 max_connections=1024,
                                 decode_responses=True,
                                 )
redisconn = redis.Redis(connection_pool=pool)

# with open('ava_ip.json', 'r+') as f:
#     IP_POOLS = json.load(f)


# 给需要网络请求的函数添加代理
def add_proxy(func):
    def wapper(*args, **kwargs):
        ip = 'http://' + requests.get('http://172.16.0.99:5010/get/').text
        kwargs['proxy'] = ip
        return func(*args, **kwargs)
    return wapper


class Dz101Spider(object):
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; zh-cn; HUAWEI TAG-AL00 Build/HUAWEITAG-AL00) '
                          'AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
            'Connection': 'close',
            'Host': 'api.dz101.com',
        }
        self.req_url = 'https://api.dz101.com/v1/question/question/getPadQuestionLists'
        self.tasks = []
        self.tasks_count = 0
        # 每次启动十个协程
        self.max_coroutine_count = 10
        # 每次请求返回十道题
        self.per_ques_num = 10
        self.db = MySQLPool()

    def del_item(self, key, members):
        for member in members:
            # 删除题目id
            redisconn.srem(key, member)

    def redis_item(self):
        keys_all = redisconn.keys()
        loop = asyncio.get_event_loop()
        # 将redis中关于dz101的Set类型的key全都取出来，里面是试题id
        for key in [item for item in keys_all if item.startswith('http://www.dz101')]:
            # values = redisconn.smembers(key)
            rand_members = redisconn.srandmember(key, 10)
            # 读取redis的Set，随机题目id，请求后删除，知道Set中无值
            while rand_members:
                req_str = ''
                for member in rand_members:
                    req_str += member.replace('tqID', '') + ','

                data = {
                    'str': req_str,
                    'token': '80f2320ee5f87d4ae45a998e6202181c',
                    'mcode': 'd41d8cd98f00b204e9800998ecf8427e',
                    'sv': '3.4.0',
                    # 'sys': 1,
                    # 'edition': 1,

                }
                rand_members = redisconn.srandmember(key, self.per_ques_num)
                task = asyncio.ensure_future(self.req_data(data, key, rand_members))
                self.tasks.append(task)
                self.tasks_count += 1
                if self.tasks_count == self.max_coroutine_count:
                    print('yes')
                    loop.run_until_complete(asyncio.wait(self.tasks))
                    self.tasks = []
                    self.tasks_count = 0
            # 如果self,tasks不为空， 处理最后一次的数据
            if self.tasks:
                loop.run_until_complete(asyncio.wait(self.tasks))
                print('yes')
                self.tasks = []
                self.tasks_count = 0

    def pipe_item(self):
        pass

    @add_proxy
    async def req_data(self, data, key, members, proxy=None):
        async with ClientSession() as session:
            try:
                async with session.post(url=self.req_url,
                                        data=data,
                                        proxy=proxy,
                                        headers=self.headers) as response:
                    r = await response.json()
                    if response.status == 200:
                        for ques in r['results']:
                            item = {
                                'key': 'dz101_question_{}'.format(ques['origDocID']),
                                'source': 56,
                                'url': self.req_url,
                                'content': ques,
                                'extra_info': {
                                    'subject': ques['subject'],
                                    'grade': ques['grade'],
                                    'difficulty': ques['difficulty'],
                                },
                                'spider_id': 7062,
                                'flag': 0,
                            }
                            self.db.insert(item)
                        self.del_item(key, members)
            except Exception as e:
                print(e)
                return self.req_data(data, key, members)


if __name__ == '__main__':
    d = Dz101Spider()
    d.redis_item()

#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/8 11:59 AM
# @Author: xiaopeng
import os
import json
import configparser

current_path = os.path.abspath('.')
cf = configparser.ConfigParser()
print(current_path)
cf.read('{}/scrapy_dz101/db_config.ini'.format(current_path))
db_config = {
    'host': cf.get('mysql', 'host'),
    'port': cf.get('mysql', 'port'),
    'user': cf.get('mysql', 'user'),
    'password': cf.get('mysql', 'password'),
    'db': cf.get('mysql', 'db'),
}

with open('{}/scrapy_dz101/ava_ip.json'.format(current_path), 'r+') as f:
    IP_POOLS = json.load(f)

#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/6 6:29 PM
# @Author: xiaopeng

id_dict = {
    'czyw': 189,
    'czsx': 193,
    'czyy': 194,
    'czwl': 195,
    'czhx': 196,
    'czsw': 197,
    'czzz': 198,
    'czls': 199,
    'czdl': 200,
    'gzyw': 109,
    'gzsx': 161,
    'gzyy': 165,
    'gzwl': 166,
    'gzhx': 167,
    'gzsw': 168,
    'gzzz': 169,
    'gzls': 170,
    'gzdl': 171,
}
pid_dict = {
    'czyw': 110872,
    'czsx': 110873,
    'czyy': 110874,
    'czwl': 110875,
    'czhx': 110876,
    'czsw': 110877,
    'czzz': 110878,
    'czls': 110879,
    'czdl': 110880,
    'gzyw': 96419,
    'gzsx': 91511,
    'gzyy': 110693,
    'gzwl': 110866,
    'gzhx': 110867,
    'gzsw': 110868,
    'gzzz': 110869,
    'gzls': 110870,
    'gzdl': 110871,
}

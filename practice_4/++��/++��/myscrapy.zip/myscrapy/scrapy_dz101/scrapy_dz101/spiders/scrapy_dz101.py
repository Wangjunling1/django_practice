#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/6 6:26 PM
# @Author: xiaopeng
import time
import scrapy
import json
import redis
import os
from scrapy import Spider
from scrapy_dz101.mysql_pool import MySQLPool
from .id_mapping import id_dict, pid_dict

pool = redis.ConnectionPool(host="127.0.0.1",
                                 port=6379,
                                 max_connections=1024,
                                 decode_responses=True,
                                 )
redisconn = redis.Redis(connection_pool=pool)


class Dz101Spider(Spider):
    '''
    调用web端出题接口，获取到题目id，然后通过
    '''
    name = 'scrapy_dz101'
    allow_domain = 'dz101.com'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.quesid_url = 'http://www.dz101.com/xuesheng/lianyuce/Back_Test_Questions?' \
                          'displayName={displayName}&subject_id={subject_id}&key={key}&' \
                          'limit={limit}&difficulty={difficulty}&year&cls={cls}'

        self.format_url = 'http://www.dz101.com/xuesheng/lianyuce/Back_Data?Cls={Cls}&displayName={displayName}&id&njId'
        self.sep_type = 'ZhiShiDian'
        self.pool = redis.ConnectionPool(host="127.0.0.1",
                                         port=6379,
                                         max_connections=1024,
                                         decode_responses=True,
                                         )
        self.db_pool = MySQLPool()

        self.conn = redis.Redis(connection_pool=self.pool)

    # 解析得到的知识点，构造提交题目的请求
    def start_requests(self):
        # for id in id_dict:
        #     url = self.format_url.format(Cls=self.sep_type, displayName=id)
        #     yield scrapy.Request(url=url, meta={'id': id})
        relative_path = 'scrapy_dz101/kno_ids'
        file_list = os.listdir(relative_path)
        for file in file_list:
            full_path = '{rel_path}/{file}'.format(rel_path=relative_path,
                                                    file=file)
            name = file.split('.')[0]
            id = id_dict[name]
            if str(id) in self.conn.keys():
                continue
            with open(full_path, 'r+', encoding='utf8') as f:
                knos = json.load(f)
                self.conn.delete(id)
                for kno in knos:
                    if kno['pId'] == str(pid_dict[name]):
                        self.conn.lpush(id, json.dumps(kno))

        for key in id_dict:
            while self.conn.keys(str(id_dict[key])):
                item = json.loads(self.conn.rpop(id_dict[key]))
                url = self.quesid_url.format(displayName=key,
                                             subject_id=id_dict[key],
                                             key=item['name'],
                                             limit='50',
                                             difficulty='全部',
                                             cls='0',
                                             )
                count = 100
                while count > 0:
                    count -= 1
                    yield scrapy.Request(url=url, meta={'ques_url': url, 'count': count}, callback=self.parse, dont_filter=True)

    def parse(self, response):
        print(response.meta['count'])
        ques_divs = response.xpath('//div[@class="Problems_item TP_item"]/@id')
        ques_ids = [item.extract() for item in ques_divs]

        for ques_id in ques_ids:
            key = ques_id.replace('tqID', 'dz101_question_')
            sql = "select `spider_url` from question where `spider_url`='%s'" % key
            sql1 = "select `key` from test.dz101_html_archive where `key`='%s'" % key
            print(key)
            if self.db_pool.select(sql) or self.db_pool.select(sql1):
                print('in db')
                continue
            redisconn.sadd(response.meta['ques_url'], ques_id)

        # text = response.text
        # dicts = text.split('|')[0]
        # json_text = '[{}]'.format(dicts)
        # full_json = json.loads(json_text)
        # print(response.meta['id'])
        # with open('scrapy_dz101/kno_ids/{file}.json'.format(file=response.meta['id']), 'w+') as f:
        #     json.dump(full_json, f, ensure_ascii=False)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  9 11:49:01 2018

@author: xiaopeng
"""
import gevent
from gevent import monkey
monkey.patch_all()
import logging
import os
import requests
import json
import pymysql
import hashlib
import time
from get_info_list import SUBJ
from common import SUBJ_MAPPING


'''
功能：爬取http://www.jtyhjy.com/sts/index.jsp上的所有题目信息
使用单线程爬取，该网站请求量不多，之前尝试使用gevent协程爬取会出现sql语句超限制问题
'''
logging.basicConfig(
        level=logging.DEBUG,  # 定义输出到文件的log级别，大于此级别的都被输出
        format='%(asctime)s  %(filename)s : %(levelname)s  %(message)s',  # 定义输出log的格式
        datefmt='%Y-%m-%d %A %H:%M:%S',  # 时间
        filename=os.path.join(os.getcwd(), 'jtyhjy.log'),  # log文件名
        filemode='a+')
client = pymysql.connect(
    host='172.16.3.17',
    port=3306,
    user='user_name',  #使用自己的用户名
    passwd='password',  # 使用自己的密码
    db='html_archive',  # 数据库名
    charset='utf8'
)
db_cur = client.cursor()
class ScrapyJtyhjy(object):
    url_list = []
    findqus_url = "http://www.jtyhjy.com/sts/question_findQuestionPage.action"
    initpage_url = "http://www.jtyhjy.com/sts/initPage_initQuestionPageForKnowledge.action"
    headers = {
        'Accept':'text/plain, */*; q=0.01',
        'Accept-Encoding':'gzip, deflate',
        'Accept-Language':'zh-CN,zh;q=0.9',
        'Connection':'keep-alive',
        'Content-Length':'50',
        'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie':'jsessionid=ADBD6E27E214A731099F01C7AA68A794; taskToken=1b7af3ef479c427cba5611fbe2ca7d5f; Hm_lvt_acbe332524305cf7430995bc4404a862=1543287389,1543287400,1544436718,1544754032; Hm_lpvt_acbe332524305cf7430995bc4404a862=1544754032',
        'Host':'www.jtyhjy.com',
        'Referer':'http://www.jtyhjy.com/sts/index.jsp',
        'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
        'Origin':'http://www.jtyhjy.com',
        'X-Requested-With':'XMLHttpRequest',
        }

    def start_requests(self):
        for subj in SUBJ:
            print(subj)
            info_path = 'working/knowledges/{}_{}_{}.txt'.format(
                subj['code'],subj['schoolType'],subj['disciplineId'])
            if os.path.exists(info_path):
                try:
                    js = json.load(open(info_path))
                except:
                    pass
            else:
                data = {
                    "disciplineCode":subj['code'],
                    "disciplineType":subj['schoolType'],
                    "disciplineId":"{}".format(subj['disciplineId']),
                }
                js = requests.post(self.initpage_url,headers=self.headers,data=data).json()
                with open(info_path,'w+') as fd:
                    json.dump(js,fd,indent=4,ensure_ascii=False)

            que_type_ids = ','.join([str(j['queTypeId']) for j in js['data']['questionTypeList']])


            for kp in js['data']['knowledgeList']:
                data = {
                    'disciplineCode':subj['code'],
                    'disciplineType':subj['schoolType'],
                    'disciplineId':str(subj['disciplineId']),
                    'page':'1',
                    'flag':'3',
                    'queTypeIds':que_type_ids,
                    'knowledgeIds':str(kp['knowledgeId']),
                    'knowledgeLevel':'1',
                    'difficults': '1,2,3,4,5'
                }
                sub_headers = self.headers.copy()
                sub_headers['Referer'] = 'http://www.jtyhjy.com/sts/?disciplineCode={}&disciplineId={}&disciplineType={}&knowledgeId={}'.format(subj['code'],
                                                          subj['disciplineId'],
                                                          subj['schoolType'],
                                                          kp['knowledgeId'])

                name = '{}_{}_{}_{}_{}'.format(
                    subj['code'], subj['schoolType'],
                    subj['disciplineId'], kp['knowledgeId'], '1')

                resp = requests.post(self.findqus_url,data=data,headers=sub_headers)
                json_str = resp.json()
                qus_num = json_str['data']['questionList']['total']
                #这里设置请求的题目数量
                data['rows'] = '{}'.format(1000)
                max_page = qus_num//1000 + 2
                for i in range(max_page):
                    data['page'] = '{}'.format(i)
                    request_info = {'current_page':i,'max_page':max_page,'kno':kp['name'],'subj':subj.copy(),'url':self.findqus_url,'data':data.copy(),'headers':sub_headers}
                    self.url_list.append(request_info)


def insert_data(item):
    select_sql = "select * from jtyhjy_spider_html_archive_table_20181115 where `key` = '%s'"%(item['key'])
    db_cur.execute(select_sql)
    result = db_cur.fetchone()
    if result:
        logging.error('had added')
        return False
    insert_sql = '''
                      INSERT INTO jtyhjy_spider_html_archive_table_20181115
                      (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`flag`,`flag_str`)
                      VALUES (%d,%d,'%s','%s','%s','%s','%s',%d,'%s')
                     '''%(item['source'],item['subject'],item['html'].replace('"','\\"').replace('\'','\'\''),item['md5'],item['key'],
                          item['request_info'],item['info'],item['flag'],item['flag_str'])
    try:
        db_cur.execute(insert_sql)
        client.commit()
        return True
    except Exception as e:
        logging.error(e)
        return False

def post(req_info):
    try:
        r = requests.post(req_info['url'],data=req_info['data'],headers=req_info['headers'])
        json_str = r.json()
        #得到的数目应该与之前设定的请求数量一致，否则请求出错
        max_num = len(json_str['data']['questionList']['rows'])
        qlist = json_str['data']['questionList']['rows']
        # ig = [gevent.spawn(insert,{'i':i,'row':value,'max_num':max_num,'data': req_info['subj'], 'kno': req_info['kno']}) for i,value in enumerate(qlist)]
        # gevent.joinall(ig)
        i = 0
        for row in qlist:
            info = {'current_page':req_info['current_page'],'max_page':req_info['max_page'],'current_num': i, 'max_num': max_num, 'data': req_info['subj'], 'kno': req_info['kno']}
            item = {}
            try:
                item['subject'] = SUBJ_MAPPING[req_info['subj']['name']]
            except Exception as e:
                item['subject'] = 0
                logging.error(e)
            item['info'] = json.dumps(req_info['subj'], ensure_ascii=False)
            item['html'] = json.dumps(row,ensure_ascii=False).replace('\\n',' ').replace('\\r',' ')
            item['source'] = 78
            m2 = hashlib.md5()
            m2.update(str(row).encode('utf-8'))
            item['md5'] = m2.hexdigest()
            item['key'] = 'jtyhjy_qs_{}'.format(row['questionId'])
            item['request_info'] = ''
            item['flag'] = 0
            item['flag_str'] = ''

            if insert_data(item):
                logging.info('add success '+str(info))
                print('add success '+str(info))
            else:
                logging.info('add failed '+str(info))
                print('add failed '+str(info))
            i += 1

    except Exception as e:
        logging.error(e)


if __name__=='__main__':
    test = ScrapyJtyhjy()
    test.start_requests()
    # g = [gevent.spawn(post,req_info) for req_info in test.url_list]
    # gevent.joinall(g)
    for req_info in test.url_list:
        post(req_info)


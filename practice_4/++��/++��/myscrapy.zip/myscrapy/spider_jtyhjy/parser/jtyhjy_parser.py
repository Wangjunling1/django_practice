import logging
import json
import hashlib
import MySQLdb.cursors
import re

from afanti_tiku_lib.html.extract import get_html_element
from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.dbs.sql import insert_sql, select_sql
from afanti_tiku_lib.html.beautify_html import center_image, remove_tag
from bs4 import BeautifulSoup
from common import SUBJ_MAPPING,provinces
from afanti_tiku_lib.question_template.question_template import Question, Option

from download_pic import download_img
connect_db_offline = MySQLdb.connect(
    host='172.16.3.17',
    db="question_db_offline",
    user='user_name',
    passwd='password',
    charset='utf8',
    use_unicode=True)
offline_cursor = connect_db_offline.cursor()
HEADERS = {
        'Accept': 'image/webp,image/*,*/*;q=0.8',
        'Referer': 'http://www.jtyhjy.com/sts/',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36'
    }

def convert_str_subject_to_int(string):
    grade_dict = {
        '初中': 0,
        '高中': 20,
        '小学': 40
    }
    subject_dict = {
        '语文': 1,
        '数学': 2,
        '英语': 3,
        '物理': 5,
        '化学': 6,
        '地理': 7,
        '历史': 8,
        '生物': 9,
        '政治': 10,
        '文综': 11,
        '理综': 12,
    }
    subject = 0
    for key in grade_dict.keys():
        if key in string:
            subject = grade_dict[key]
            break
    for key in subject_dict.keys():
        if key in string:
            subject += subject_dict[key]
            break
    if subject // 2 not in [0, 2, 4]:
        subject = 0
    return subject

def sub_word_tag(text):
    #chinese font
    pattern_chinese = re.compile(r'<[^<>/]+(style\s*=\s*[\'"][^<>\'"/]+体[^<>\'"/]+[\'"])[^<>/]*?>', flags=re.I | re.U)
    text = pattern_chinese.sub('', text)
    #english font
    pattern_english = re.compile('''(<span)(\s[^<>/]*?)(lang\s*=\s*['"]EN-(?:US|GB)['"])[^<>/]*?(style\s*=\s*['"][^<>\'"]+['"])?''', flags=re.I | re.U)
    text = pattern_english.sub(lambda m: m.group(1) + m.group(2) if m.group(2).strip() else m.group(1), text)
    # MsoNormal class
    pattern = re.compile('''<p\s*?[^<>/]*?class\s*=\s*['"]MsoNormal['"][^<>/]*?>''', flags=re.I | re.U)
    del_attribute = lambda m: re.sub('''(class|align|style)\s*=\s*['"][^<>\'"]+['"]\s*''', '',  m.group(0), flags=re.U | re.I)
    text = pattern.sub(del_attribute, text)

    pattern = re.compile('''(<span\s+[^<>/]*?)(style\s*=\s*['"][^'"<>/]+(?:black|white)[^'"<>/]*?['"])([^<>/]*>)''', flags=re.I | re.U)
    text = pattern.sub(lambda m: m.group(1) + m.group(3), text)
    # convert '<span>A</span>' to 'A'
    pattern = re.compile('<span[^<>/]*?>([^<>]{,2})</span>', flags=re.I | re.U)
    text = pattern.sub(lambda m: m.group(1), text)
    return text

class Jtyhjy_Parse(object):
    def __init__(self):
        self.logger = logging.getLogger('iter')
        self.html_magic = HtmlMagic(spider_source=78, download=False, proxy=True)

    def download(self,question_item):
        for key in ['question_html','option_html','answer_all_html','jieda','fenxi','dianping']:
            if question_item[key] != '':
                soup = BeautifulSoup(question_item[key],'lxml')
                imgs = soup.find_all('img')
                if imgs:
                    print(soup)
                    # print(imgs)
                for img in imgs:
                    spider_url = question_item['spider_url']
                    image_url = img.get('src')
                    if not image_url:
                        continue
                    print(image_url)
                    image_url_md5 = hashlib.md5(image_url.encode('utf8')).hexdigest()
                    ret = download_img(78, spider_url, image_url, image_url_md5)
                    if not ret:
                        print("download error")

    def deal_one_item(self, item):
        html = item['html']
        html_id = item['html_id']
        spider_url = item['key']

        subject_dict = True and item['info'] or {}
        subject_dict = json.loads(subject_dict)
        subject_string = subject_dict.get('name', '')
        subject = convert_str_subject_to_int(subject_string)
        question_item = dict(
            spider_source = 78,
            spider_url = spider_url,
            subject=subject
        )
        question_dict = self.parse(html)
        if question_dict == {}:
            print('解析出错'+spider_url)
            return
        question_item['knowledge_point'] = question_dict['knowledge_point']
        question_item['paper_name'] = question_dict['paper_name_abbr']
        try:
            question_item['exam_city'] = [item for item in provinces if item in question_dict['paper_name_abbr']][0]
        except Exception as e:
            question_item['exam_city'] = '0'
        pattern = re.compile('\\d{4}年')
        try:
            year_match = re.search(pattern,question_dict['paper_name_abbr'])
            question_item['exam_year'] = int(year_match.group(0).replace('年', ''))
        except Exception as e:
            question_item['exam_year'] = 0

        question_dict = Question(**question_dict).normialize()
        question_item['question_html'] = question_dict['question_body']
        question_item['option_html'] = ''
        question_item['jieda'] = ''
        question_item['zhuanti'] = ''
        question_item['question_type'] = 0
        question_item['answer_all_html'] = question_dict['answer']
        question_item['fenxi'] = question_dict['analy']
        question_item['dianping'] = question_dict['comment']

        for key in ['question_html', 'option_html', 'answer_all_html',
                    'fenxi', 'dianping']:
            question_item[key] = sub_word_tag(question_item[key])
            question_item[key] = self.html_magic.bewitch(
                  question_item[key], question_item['spider_url'], spider_source=78, headers=HEADERS
            )

        try:
            sql = "select `spider_url` from jtyhjy_question_20181210 where `spider_url` = '%s'"%(spider_url)
            is_in = offline_cursor.execute(sql)
            if offline_cursor.execute(sql):
                return

            insert_sql = '''insert into jtyhjy_question_20181210 (spider_source,spider_url,knowledge_point,subject,zhuanti,exam_year,
                                    exam_city,difficulty,question_type,question_quality,paper_name,question_html,option_html,
                                    answer_all_html,jieda,fenxi,dianping,
                                    flag) values(%d,'%s','%s',%d,'%s',%d,'%s',%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s',%d)
                                    ''' % (question_item['spider_source'], question_item['spider_url'],
                                           question_item['knowledge_point'], question_item['subject'],
                                           question_item['zhuanti'], question_item['exam_year'],
                                           question_item['exam_city'], 0, question_item['question_type'],
                                           '',question_item['paper_name'],
                                           question_item['question_html'].replace('"','\\"').replace('\'','\'\''),
                                           question_item['option_html'].replace('"','\\"').replace('\'','\'\''),
                                           question_item['answer_all_html'].replace('"','\\"').replace('\'','\'\''),
                                           question_item['jieda'].replace('"','\\"').replace('\'','\'\''),
                                           question_item['fenxi'].replace('"','\\"').replace('\'','\'\''),
                                           question_item['dianping'].replace('"','\\"').replace('\'','\'\''), 0)

            # self.download(question_item)
            offline_cursor.execute(insert_sql)
            # print('存入成功'+question_item['spider_url'])
        except Exception as err:
            self.logger.warning(
                'html_id: %s. error happend when insert question: %s',
                html_id, err
            )
            raise err


    def parse(self, html):

        regex = re.compile(r'\\(?![/u"])')
        try:
            html = regex.sub(r"\\\\", html)
            question_json = json.loads(html,strict=False)
        except Exception as e:
            print(e)
            question_json = None
            return {}
        question_dict = {}
        question_dict['question_body'] = question_json.get('bodyHtmlText', '')
        question_dict['answer'] = question_json.get('answerHtmlText', '')
        question_dict['analy'] = question_json.get('analysisHtmlText', '')
        question_dict['knowledge_point'] = question_json.get('knowledgeName', '')
        question_dict['paper_name_abbr'] = question_json.get('queSource', '')
        question_dict['difficulty'] = question_json.get('difficult', '')

        return question_dict






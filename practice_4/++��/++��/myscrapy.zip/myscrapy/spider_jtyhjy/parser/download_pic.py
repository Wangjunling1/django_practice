import requests
import hashlib

def download_img(spider_source, spider_url, image_url, image_url_md5, using_proxy=True, headers=""):
    url = "http://172.16.0.100:9000/apis/v1/image/collection/"
    data = dict(
        spider_source = spider_source,
        image_url = image_url,
        image_url_md5 = image_url_md5,
        spider_url = spider_url,
        headers = headers,
        proxy = True if using_proxy else None,
    )
    print(data)

    r = requests.post(url, data=data)
    if r.status_code==200:
        print(r.json())
        return True
    else:
        return False

# if __name__=="__main__":
#     spider_url = "http://www.mofangge.com/html/qDetail/02/x6/201003/g2kux6021294.html"
#     image_url = 'http://pic19.nipic.com/20120210/7827303_221233267358_2.jpg'
#     image_url_md5 = hashlib.md5(image_url.encode('utf8')).hexdigest()
#
#     ret = download_img(8, spider_url, image_url, image_url_md5)
#     if not ret:
#         print("download error")


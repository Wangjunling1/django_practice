# -*- coding:utf8 -*-
from __future__ import unicode_literals
from gevent import monkey; monkey.patch_socket()
import gevent
import os
import logging
import configparser
import MySQLdb.cursors
import multiprocessing
import traceback
from jtyhjy_parser import Jtyhjy_Parse
from afanti_tiku_lib.html.magic import HtmlMagic

try:
    from cloghandler import ConcurrentRotatingFileHandler as RFHandler
except ImportError:
    from warnings import warn
    warn("ConcurrentLogHandler package not installed.  Using builtin log handler")
    from logging.handlers import RotatingFileHandler as RFHandler

db_config_file = os.path.join(
        os.path.expanduser('~'), '.dbinfo')
config = configparser.RawConfigParser(allow_no_value=True)
config.readfp(open(db_config_file))

connect = MySQLdb.connect(
    host='172.16.3.17',
    db='html_archive',
    user='user_name',
    passwd='password',
    charset='utf8mb4',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,
)
connect_db_offline = MySQLdb.connect(
    host='172.16.3.17',
    db="question_db_offline",
    user='user_name',
    passwd='password',
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,)
offline_cursor = connect_db_offline.cursor()
# 通过cursor执行增删查改
cursor = connect.cursor()

def sele_res(para_list):
    select_sql = 'select * from jtyhjy_spider_html_archive_table_20181214 where ' \
                 'html_id >= %d and html_id < %d'%(para_list['min_id'],para_list['max_id'])
    cursor.execute(select_sql)
    result = cursor.fetchone()
    while result:
        parser = Jtyhjy_Parse()
        parser.deal_one_item(result)
        result = cursor.fetchone()
    print(para_list)

def run(min_id,max_id,step):
    process_list = []
    for i in range(min_id,max_id,step):
        para_list = {
            'min_id':i,
            'max_id':i + step,
        }
        process_list.append(gevent.spawn(sele_res,para_list))
    gevent.joinall(process_list)

def main():
    min_id = 85850703
    max_id = 132597372
    step = 10000
    run(min_id,max_id,step)

if __name__=='__main__':
    main()

# encoding:utf-8
import pymysql

client = pymysql.connect(
            host='localhost',
            port=3306,
            user='root',  #使用自己的用户名
            passwd='Xiaopeng1997',  # 使用自己的密码
            db='test',  # 数据库名
            charset='utf8'
        )
db_cur = client.cursor()

test_text = '{\"analysisHtml\": \"http://i.jtyhjy.com/hstsnew/stsdoc//1/01/stsdoc/20150209/analysis9026409.png\", \"analysisHtmlText\": \"<div class=Section1 style=''layout-grid:15.6pt''><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>本题考查辨析语病的能力。对于病句关键要从两个方面着手：一是认真读教材与课外书籍，培养语感；二是熟悉要求掌握的六种病句类型。然后运用语法分析的手段，先将句子中的附加成分<spanlang=EN-US>(</span>定语、状语、补语<span lang=EN-US>)</span>去掉，紧缩出主干，检查主干是否有毛病；如果主干没问题，再检查局部，看修饰语和中心词之间、修饰语内部是否有毛病。<spanlang=EN-US>A</span>．“果断”褒义贬用了，应“武断”。Ｂ．“因为他”应置“不仅仅是”之后。Ｃ．“用””应改为“把”。<spanlang=EN-US><o:p></o:p></span></span></p></div>\", \"answerHtml\": \"http://i.jtyhjy.com/hstsnew/stsdoc//1/01/stsdoc/20150209/answer9026409.png\", \"answerHtmlText\": \"<div class=Section1 style=''layout-grid:15.6pt''><p class=MsoNormal style=''mso-pagination:widow-orphan''><span lang=EN-USstyle=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>D<o:p></o:p></span></p></div>\", \"bodyHtmlText\": \"<div class=Section1 style=''layout-grid:15.6pt''><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>选出没有语病的一句。<span lang=EN-US><o:p></o:p></span></span></p><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>Ａ．他这个人太果断，什么事都不愿听取群众的意见。<span lang=EN-US><o:p></o:p></span></span></p><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>Ｂ．我说赵武灵王是英雄，因为他不仅仅是筑了一条长城，更重要的是因为他敢于发布“胡服骑射”的命令。<span lang=EN-US><o:p></o:p></span></span></p><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>Ｃ．雅琪将士用不屈的斗志和协作的团队精神化作战斗力，使得劲旅申花怏怏而归。<span lang=EN-US><o:p></o:p></span></span></p><p class=MsoNormal style=''mso-pagination:widow-orphan''><span style=''font-size:11.0pt;mso-bidi-font-size:10.5pt;font-family:宋体;mso-bidi-font-family:宋体;color:black''>Ｄ．我现在还痛感有周密研究中国事情和国际事情的必要。’<span lang=EN-US><o:p></o:p></span></span></p></div>\", \"collectFlag\": \"0\", \"difficult\": \"2\", \"disciplineId\": 20, \"knowledgeId\": 2002221, \"knowledgeName\": \"辨析并修改病句\", \"queSource\": \"2014年四川省眉山市初中学业暨高中阶段教育学校招生考试\", \"queTypeId\": 70, \"questionHtml\": \"http://i.jtyhjy.com/hstsnew/stsdoc//1/01/stsdoc/20150209/body9026409.png\", \"questionId\": 9026409, \"regTime\": 1423476973000, \"updateTime\": 1423390573000, \"usageCount\": 0}'
if __name__=='__main__':
    insert_sql = "insert into test(text) value('%s')"%(test_text)
    db_cur.execute(insert_sql)
    client.commit()

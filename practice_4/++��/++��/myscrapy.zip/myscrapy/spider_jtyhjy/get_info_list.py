#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  9 11:49:40 2018

@author: xiaopeng
"""
import gevent
from gevent import monkey
monkey.patch_all()
import requests
url = "http://www.jtyhjy.com/sts/initPage_initQuestionPageForKnowledge.action"

SUBJ = [{'code': '01', 'disciplineId': 20, 'name': '初中语文', 'schoolType': '1'},
        {'code': '02', 'disciplineId': 21, 'name': '初中数学', 'schoolType': '1'},
        {'code': '03', 'disciplineId': 22, 'name': '初中英语', 'schoolType': '1'},
        {'code': '04', 'disciplineId': 23, 'name': '初中物理', 'schoolType': '1'},
        {'code': '05', 'disciplineId': 24, 'name': '初中化学', 'schoolType': '1'},
        {'code': '06', 'disciplineId': 25, 'name': '初中生物', 'schoolType': '1'},
        {'code': '07', 'disciplineId': 26, 'name': '初中政治', 'schoolType': '1'},
        {'code': '08', 'disciplineId': 27, 'name': '初中历史', 'schoolType': '1'},
        {'code': '09', 'disciplineId': 28, 'name': '初中地理', 'schoolType': '1'},
        {'code': '01', 'disciplineId': 20, 'name': '高中语文', 'schoolType': '2'},
        {'code': '02', 'disciplineId': 21, 'name': '高中数学', 'schoolType': '2'},
        {'code': '03', 'disciplineId': 22, 'name': '高中英语', 'schoolType': '2'},
        {'code': '04', 'disciplineId': 23, 'name': '高中物理', 'schoolType': '2'},
        {'code': '05', 'disciplineId': 24, 'name': '高中化学', 'schoolType': '2'},
        {'code': '06', 'disciplineId': 25, 'name': '高中生物', 'schoolType': '2'},
        {'code': '07', 'disciplineId': 26, 'name': '高中政治', 'schoolType': '2'},
        {'code': '08', 'disciplineId': 27, 'name': '高中历史', 'schoolType': '2'},
        {'code': '09', 'disciplineId': 28, 'name': '高中地理', 'schoolType': '2'},
        {'code': '10', 'disciplineId': 29, 'name': '高中文综', 'schoolType': '2'},
        {'code': '11', 'disciplineId': 50, 'name': '高中理综', 'schoolType': '2'}]

def get():
    headers = {
        'Accept':'text/plain, */*; q=0.01',
        'Accept-Encoding':'gzip, deflate',
        'Accept-Language':'zh-CN,zh;q=0.9',
        'Connection':'keep-alive',
        'Content-Length':'50',
        'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie':'jsessionid=C056309DDE6D9A9CFE59CBFC8C1693A0; taskToken=13fde7bacdce4df19640e4349fd21cda; Hm_lvt_acbe332524305cf7430995bc4404a862=1541058530; Hm_lpvt_acbe332524305cf7430995bc4404a862=1541735476',
        'Host':'www.jtyhjy.com',
        'Referer':'http://www.jtyhjy.com/sts/index.jsp',
        'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
        'Origin':'http://www.jtyhjy.com',
        'X-Requested-With':'XMLHttpRequest',
        }
    data = {
        'disciplineCode':'01',
        'disciplineType':'1',
        'disciplineId':'20',
    }

    resp = requests.post(url,data=data,headers=headers)
    print(resp.text)
    # print(disciplineList.keys())

#if __name__=='__main__':
#    get()


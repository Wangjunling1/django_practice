#!/bin/bash

set -v

uid = `ls -l . | grep run.sh | awk '{print $3}'`
mkdir -p ./logs
chown -R ${uid}:{uid} ./logs
cd src
nohup python -u zzstep_parser.py > ../logs/run.log 2>&1 &

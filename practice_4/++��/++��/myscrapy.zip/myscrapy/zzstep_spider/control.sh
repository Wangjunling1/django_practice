#!/bin/bash

proj_name=zzstep_spider

if [ ! -n "$1" ]
then
    echo "Usages: sh control.sh [start|stop|restart|status]"
    exit 0
fi

function start(){
    docker-compose -f docker/docker-compose.yml -p ${proj_name} up -d
    process_num=`docker ps | grep ${proj_name} | wc -l`
    if [ ${process_num} -gt 0 ]
    then
        echo "${proj_name} Start, ${process_num}, [OK]"
    else
        echo "${proj_name} Start [Failed]"
    fi
}

function stop(){
    docker-compose -f docker/docker-compose.yml -p ${proj_name} down
    process_num=`docker ps | grep ${proj_name} | wc -l`
    if [ ${process_num} -gt 0 ]
    then
        echo "${proj_name} Stop [Failed]"
    else
        echo "${proj_name} Stop [OK]"
    fi
}

if [ $1 = start ]
    then
        start
elif [ $1 = stop ]
    then
        stop
fi


#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/9 2:11 PM
# @Author: xiaopeng

import os
import json
from mysql_pool import MySQLPool

current_path = os.path.abspath('.')

db = MySQLPool()

# 给需要网络请求的函数添加代理


def add_proxy(func):
    def wapper(*args, **kwargs):
        ip = 'http://' + requests.get('http://172.16.0.99:5010/get/').text
        proxies = {
            'http': ip,
            'https': ip,
        }
        kwargs['proxies'] = proxies
        return func(*args, **kwargs)
    return wapper


# 检查该条数据是否存入数据库
def archive(func):
    def wapper(*args, **kwargs):
        key = args[1]['key']
        if db.is_archive(key):
            return
        return func(*args, **kwargs)
    return wapper


def add_abuyun(func):
    def wapper(*args, **kwargs):
        ip_auth = "http://H5Q6816ED0T3417D:764AE77AE14D5C27@http-dyn.abuyun.com:9020"
        proxy_auth = {
            "http": ip_auth,
            "https": ip_auth,
        }
        kwargs['proxies'] = proxy_auth
        return func(*args, **kwargs)
    return wapper


subject_mapping = {
    '语文': 1,
    '数学': 2,
    '英语': 3,
    '科学': 4,
    '物理': 5,
    '化学': 6,
    '地理': 7,
    '历史': 8,
    '生物': 9,
    '政治': 10,
}

grade_mapping = {
    '未知': 0,
    '一年级': 1,
    '二年级': 2,
    '三年级': 3,
    '四年级': 4,
    '五年级': 5,
    '六年级': 6,
    '七年级': 7,
    '八年级': 8,
    '九年级': 9,
    '高一': 10,
    '高二': 11,
    '高三': 12,
    '小学': 101,
    '初中': 102,
    '高中': 103,
}

type_mapping = {
    '单选题': 1,
    '填空题': 2,
    '问答': 3,
    '多选': 4,
}

difficulty_mapping = {
    '容易': 1,
    '较易': 3,
    '一般': 5,
    '较难': 7,
    '困难': 9
}


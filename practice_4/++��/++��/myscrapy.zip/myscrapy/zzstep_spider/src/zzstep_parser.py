#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019-08-16 15:05
# @Author: xiaopeng

import threading
import logging
import json
import re
import pymysql
from bs4 import BeautifulSoup
from exceptions import DifficultyNotFoundError, TypeNotFoundError
from parse_utils import ParseUtil
from util import (db,
                  subject_mapping,
                  grade_mapping,
                  difficulty_mapping,
                  type_mapping)


class ZzstepParser(ParseUtil):
    def __init__(self, destination_db, destination_table, pc, cc):
        # 通过父类连接需要被解析的源数据库db和表,配置在util.py文件中
        super().__init__('zzstep_html_archive', db, destination_db, destination_table)
        self.max_id = self.db_max_id
        self.min_id = self.db_min_id
        #7448020
        # 处理线程数
        self.proccess_count = pc
        # 每个线程处理id范围
        self.cross_count = cc

    def run(self):
        for i in range(self.min_id, self.max_id + 1, self.proccess_count * self.cross_count):
            start_id = i
            end_id = self.proccess_count * self.cross_count + start_id
            if end_id > self.max_id + 1:
                end_id = self.max_id + 1
            self.sub_run(start_id, end_id)

    def sub_run(self, start_id, end_id):
        threads = []
        for j in range(start_id, end_id, self.cross_count):
            s = j
            e = j + self.cross_count
            if e > self.max_id + 1:
                e = self.max_id + 1
            t = threading.Thread(target=self.parser, args=(s, e, ))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()
        logging.info('sub_run from {} to {} is end'.format(start_id, end_id))

    @staticmethod
    def draw_content(content):
        try:
            spattern = re.compile(r'<div class="shiti_ls2">(.*?)</div>', re.S | re.I)
            sub_content = re.findall(spattern, str(content))[0]
        except IndexError:
            bpattern = re.compile(r'<div class="shiti_ls">(.*?)</div>', re.S | re.I)
            sub_content = re.findall(bpattern, str(content))[0]
        cpattern = re.compile(r'(<h1>([0-9]\.)?(.*?)</h1>)', re.S | re.I)
        result = re.findall(cpattern, sub_content)
        for item in result:
            sub_content = sub_content.replace(item[0], f'<p>{item[2]}</p>')
        return sub_content

    def deal_sub_ques(self, content, type_):
        answers = []
        options = []
        comment = ""
        hint = ""
        solution = ""

        if type_ in ['单选题']:
            option_tags = content.find(name='ul').find_all(name='li')
            for option_tag in option_tags:
                option = {}
                option['Key'] = option_tag.find('span').string.strip('.')
                option_tag.find('span').extract()
                value = re.search(r'<li>(.*?)</li>', str(option_tag))
                option['Value'] = value.group(1)
                options.append(option)
            for ul in content('ul'):
                ul.extract()

            answer_label = content.find_next_sibling().find_all('div', class_='pingxi')
            try:
                pattern = re.compile(r'<div class="jiexi_content f_l">(.*?)</div>', re.S|re.I)
                daans = re.findall(pattern, str(answer_label[0]))[0].strip()
            except IndexError:
                daans = ""
            try:
                pattern1 = re.compile(r'<div class="jiexi_content f_l">(.*?)</div>', re.S|re.I)
                jiexi = re.findall(pattern1, str(answer_label[1]))[0]
            except IndexError:
                jiexi = ""
            # daans = answer_label[0].find('div', class_='jiexi_content f_l').text.strip()
            # jiexi = answer_label[1].find('div', class_='jiexi_content f_l')
            for daan in daans:
                order = ord(daan.upper()) - 65
                if order < 0 or order > 25:
                    solution = daans
                    break
                answers.append(daan)
            if not answers:
                solution = answer_label[0].find('div', class_='jiexi_content f_l')
            origin = {"content": self.draw_content(content),
                           "options": None if not options else options,
                           "answers": answers,
                           "analyse": jiexi,
                           "solution": str(solution),
                           "comment": comment,
                           "hint": hint, }
        else:
            answer_label = content.find_next_sibling().find_all('div', class_='pingxi')
            # solution = answer_label[0].find('div', class_='jiexi_content f_l')
            try:
                pattern = re.compile(r'<div class="jiexi_content f_l">(.*?)</div>', re.S|re.I)
                solution = re.findall(pattern, str(answer_label[0]))[0]
            except IndexError:
                solution = ""
            try:
                pattern1 = re.compile(r'<div class="jiexi_content f_l">(.*?)</div>', re.S|re.I)
            # jiexi = answer_label[1].find('div', class_='jiexi_content f_l')
                jiexi = re.findall(pattern1, str(answer_label[1]))[0]
            except IndexError:
                jiexi = ""
            origin = {"content": self.draw_content(content),
                           "options": None if not options else options,
                           "answers": answers,
                           "analyse": jiexi,
                           "solution": solution,
                           "comment": comment,
                           "hint": hint, }
        return origin

    def deal_no_sub_ques(self, type_, question):
        soup = BeautifulSoup(question['content'], 'html.parser')
        # 大题干
        big_content = soup.find(name='div', class_='shiti_ls')

        for tag in big_content('span'):
            if tag.text == '资料':
                tag.extract()
        # bpattern = re.compile(r'<div class="shiti_ls">(.*?)</div>', re.S|re.I)
        # content = re.findall(bpattern, str(big_content))[0]
        # 小题干
        small_contents = soup.find_all(name='div', class_='shiti_ls2')
        # 非多题的单选题，多选题
        if not small_contents:
            origin = {"formate_version": 1, }
            origin.update(self.deal_sub_ques(big_content, type_))
            origin.update({"sub_question": []})
        elif small_contents:
            origin = {"formate_version": 1,
                      "content": self.draw_content(str(big_content)),
                      "options": None,
                      "answers": [],
                      "analyse": "",
                      "solution": "",
                      "comment": "",
                      "hint": "", }
            sub_question = []
            i = 1
            for content in small_contents:
                result = {"number": i}
                result.update(self.deal_sub_ques(content, type_))
                sub_question.append(result)
                i += 1
            origin['sub_question'] = sub_question

        return origin
        # elif type_ not in ['单选题', '多选题'] and not small_content:
        #     pass

    # 针对不同的spider_source进行不同的解析
    def parser(self, s, e):
        # 参数为起始id,结束id和要解析的表名
        questions = self.choose_ques(s, e)
        if not questions:
            return
        for question in questions:
            # if self.is_archive(question['key']):
            #     print('had added:{}'.format(question['key']))
            #     continue
            logging.info('this is a new data:{}'.format(question['key']))
            extra_info = json.loads(question['extra_info'])
            try:
                difficulty = re.findall(r'<span>难度：(.*?)</span>', question['content'])[0]
            except IndexError:
                err = DifficultyNotFoundError('Can not find the difficulty of {}'.format(question['key']))
                logging.error(err)
            try:
                type_ = re.findall(r'<span>题型：(.*?)</span>', question['content'])[0]
            except IndexError:
                err = TypeNotFoundError('Can not find the type of {}'.format(question['key']))
                logging.error(err)

            knowledge_point = []
            origin = self.deal_no_sub_ques(type_, question)
            latex = self.origin_to_latex(origin)
            html = self.latex_to_html(origin)
            item = {
                'question_id': 0,
                'source': question['source'],
                'key': question['key'],
                'subject': subject_mapping.get(extra_info['subject'], 0),
                'grade': grade_mapping.get(extra_info['grade'], 0),
                'difficulty': difficulty_mapping.get(difficulty, 0),
                'type': type_mapping.get(type_, 0),
                'knowledge_point': knowledge_point,
                'origin': origin,
                'latex': latex,
                'html': html,
                'extra_info': extra_info,
            }
            # print(json.dumps(item['origin'], ensure_ascii=False))
            for key in ['extra_info', 'knowledge_point', 'origin', 'latex', 'html']:
                item[key] = pymysql.escape_string(json.dumps(item[key], ensure_ascii=False))
            try:
                self.save_item(item)
                print(item['key'])
            except Exception as e:
                raise e


if __name__ == '__main__':
    # 目标数据库，解析表，线程数，单个线程处理id个数
    z = ZzstepParser('test', 'zzstep_parsed_question', 10, 10000)
    z.run()



#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/9 12:24 PM
# @Author: xiaopeng

import redis
import time
import re
import requests
import threading
from pyquery import PyQuery
from util import *


sub_dict = {
    # '小学语文': 'yuwenzj_xx',
    # '小学数学': 'shuxuezj_xx',
    # '小学英语': 'yingyuzj_xx',
    # '小学科学': 'kexue_xx',
    # '初中语文': 'yuwen',
    # '初中数学': 'shuxue',
    # '初中英语': 'english',
    # '初中物理': 'wuli',
    # '初中化学': 'huaxue',
    # '初中政治': 'zhengzhi',
    '初中历史': 'lishi',
    '初中生物': 'shengwu',
    '初中地理': 'dili',
    '初中道德与法治': 'daodeyufazhi',
    '高中语文': 'yuwenzj_gz',
    '高中数学': 'shuxuezj_gz',
    '高中英语': 'yingyuzj_gz',
    '高中物理': 'wulizj_gz',
    '高中化学': 'huaxuezj_gz',
    '高中生物': 'shengwuzj_gz',
    '高中政治': 'zhengzhizj_gz',
    '高中历史': 'lishizj_gz',
    '高中地理': 'dilizj_gz',
}

reverse_dict = {v : k for k, v in sub_dict.items()}


def singleton(cls):
    instance = {}

    def inner():
        print(instance)
        if cls not in instance:
            instance[cls] = cls()
        return instance[cls]
    return inner


# @singleton
class ZzstepSpider(object):
    spider_url = 'http://www.zzstep.com/exam/index.php?s=/zujuan/selectqst/sub/{sub}/p/{page}.html'

    def __init__(self, subject):
        self.subject = subject
        self.start_url = self.spider_url.format(sub=subject, page=1)
        self.pool = redis.ConnectionPool(host="127.0.0.1",
                                         port=6379,
                                         max_connections=1024,
                                         decode_responses=True,
                                         )
        self.db_pool = db
        self.redisconn = redis.Redis(connection_pool=self.pool)
        cookief = open('cookies.txt', 'r+')
        self.headers = {
            'Cookie': 'Hm_lvt_5d656a0b54535a39b1d88c84eff1725b=1565321983; UM_distinctid=16c7475f57c55f-0e6efa2c3c77e6-37637c02-13c680-16c7475f57dad1; CNZZDATA1000517170=2121521025-1565321716-http%253A%252F%252Fgit.lejent.cn%252F%7C1565321716; Hm_lvt_e22ffa3ceb40ebd886ecaaa1c24eb75d=1565321983; looyu_id=e8a8deb64b14ac3d13ed61447c8900b2_20002564%3A1; looyu_20002564=v%3Ae8a8deb64b14ac3d13ed61447c8900b2%2Cref%3Ahttp%253A//git.lejent.cn/%2Cr%3A%2Cmon%3Ahttp%3A//m9109.looyu.com/monitor%2Cp0%3Ahttp%253A//www.zzstep.com/; PHPSESSID=99b81utteskiia0ejcqk63gmd1; pp_PP_Auth=8b0d0e0f9k6h6o9r6d9m6e7z6c6c9h6e6j6j9t9h6j6h9s6f6q6i6q6j9h6d6i9r6m9k9f6f9h6m9h6j6f6f6h9o7z9j6q6j9p6p6w9r8t6x6y0d8b8h0b; cdb_cookietime=2592000; cdb_compound=74829W%2F8DCs3W1jsYsroWgU6p41o%2BM1hkuy5%2Bj2O0uzQ3yIE06ZA1qxVZ5G6L1h2ooie%2FyUYKT1O2Hwp6a7KKT2Ekk1g%2Bgkg4xuuGzqv1sE; cdb_auth=8TYlNPiF6boV7PL99LOdUzl8azkfcMtiWxa01j%2Fw%2BSYHWhxZnJQ5b24ha%2FXT3WZx1w; Hm_lvt_9ae1d642b9883edd826f2ab064acca42=1565322860; syncuyan=pO7QOXgRI7lG8EdC%2FDTa47aC%2BsFmc24TD%2BDLh%2F%2F7y7BU9n%2FzlPOBVTrr%2FeVNhJylQVL29MzX4Xp%2B0skxcayYllHt95Knhcu%2BqriIHfNKVvpp7vTUBtsDoEweGx8KFRqJFGACfPvYoz%2Bg%2FJeZuYDX8mwYpEWHNGkkcsKVZa6phNGquIgd80pW%2BjVhbSNzySpSdRmiCLFpYeEv5NUc%2BB9S2HcIMTDqZ3mmz17FzvvrSrmF%2B5RetX1t%2FVBtBsEEjZpo; bdshare_firstime=1565322870461; _99_mon=%5B0%2C0%2C0%5D; Hm_lpvt_e22ffa3ceb40ebd886ecaaa1c24eb75d=1565322951; cdb_sid=Pq7Qns; Hm_lpvt_5d656a0b54535a39b1d88c84eff1725b=1565323220; Hm_lpvt_9ae1d642b9883edd826f2ab064acca42=1565323220',
            'User-Agent': 'Mozilla/5.0 (Macintosh; '
                          'Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko)'
                          ' Chrome/75.0.3770.142 Safari/537.36',
            'Host': 'www.zzstep.com',
            'Origin': 'http://www.zzstep.com',
            'Referer': 'http://www.zzstep.com/exam/index.php',
            'Connection': 'close'
        }
        # 初始化爬取的页码，redis中读取断点
        if self.redisconn.keys(self.subject):
            page_status = self.redisconn.get(self.subject).split('/')
            self.sum_page = int(page_status[1])
            self.start_page = int(page_status[0])
        else:
            self.sum_page = self.get_sum_page()
            self.start_page = 1

    # @add_proxy
    def get_sum_page(self, proxies=None):
        resp = requests.get(self.start_url, headers=self.headers, proxies=proxies)
        _element = PyQuery(resp.text)
        page_text = _element('#page').text()
        pattern = re.compile(r'\d+/\d+')
        result = re.match(pattern, page_text)
        return int(result.group(0).split('/')[1])

    def req_data(self):
        for page_num in range(self.start_page + 1, self.sum_page + 1):
            print('current_subject:{},start_page:{},end_page:{}'.format(
                self.subject,
                page_num,
                self.sum_page,
            ))
            self.req_page(page_num)

    # @add_abuyun
    def req_page(self, page_num, proxies=None):
        current_url = self.spider_url.format(sub=self.subject, page=page_num)
        print(current_url)
        res = requests.get(current_url, headers=self.headers, proxies=proxies)
        self.redisconn.set(self.subject, '{}/{}'.format(page_num, self.sum_page))
        if res.status_code == 200:
            try:
                shitis = PyQuery(res.text)('.zj_shiti')
                for shiti in shitis.items():
                    key = 'zzstep_qs_{}'.format(shiti('.zj_caozuo').attr('qstid'))
                    grade = reverse_dict[self.subject][:2]
                    sub1 = reverse_dict[self.subject][2:]
                    item = {
                        'key': key,
                        'source': 69,
                        'url': current_url,
                        'content': str(shiti),
                        'extra_info': {'grade': grade, 'subject': sub1},
                        'spider_id': 7062,
                        'flag': 0,
                    }
                    self.pipeitem(item)
                print('success page:{},{}'.format(self.subject, page_num))
            except Exception as e:
                self.redisconn.lpush('failed_item', '{}:{}, error:{}'.format(self.subject, page_num, e))
        else:
            print('retry:{},{}'.format(self.subject, page_num))
            return self.req_page(page_num)
            # self.redisconn.lpush('failed_item', '{}:{}'.format(self.subject, page_num))

    @archive
    def pipeitem(self, item):
        db.insert(item)


if __name__ == '__main__':
    threads = []
    for sub in sub_dict:
        z = ZzstepSpider(sub_dict[sub])
        t = threading.Thread(target=z.req_data)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    # z = ZzstepSpider(sub_dict['小学语文'])
    # item = {
    #     'key': 'test'
    # }
    # z.pipeitem(item)

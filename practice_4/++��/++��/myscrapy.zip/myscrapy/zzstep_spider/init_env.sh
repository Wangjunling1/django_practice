#!/bin/bash

#set -v

venv_file='./venv'

if [ -d $venv_file ]
then
    echo "${venv_file} is here"
else
    python_path=`which python3`
    echo $python_path
    virtualenv -p ${python_path} --no-site-packages venv
fi

pip install -r requriment.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
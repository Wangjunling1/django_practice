# -*- coding: utf-8 -*-
import os
import sys
import logging
import pymysql
from lxml import etree
import re
from deal_tag import deal_tag, deal_spec_subject
from collections import OrderedDict


LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                    filename='parser.log', filemode='a')

conn = pymysql.connect(host='172.16.3.17', user='afanti_dw', passwd='afanti_dw_04', db='question_pre',
                            port=3306, charset="gbk", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)

conn2 = pymysql.connect(host='172.16.0.100', user='root', passwd='123', db='hanyu_gaolaoshi',
                            port=13309, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
cur = conn.cursor()
cur2 = conn2.cursor()


def parser_html(html):
    demo = etree.HTML(html)
    result = demo.xpath("//div[@class='con_content']/p/text()")
    if result:
        return result
    else:
        result = demo.xpath("//div[@class='con_content']//text()")
        return result


def get_pure_text(html):
    result = []
    if isinstance(html, list):
        for i in html:
            result.append(i.strip().replace('\u3000',''))
        result1 = ' '.join(result)
    else:
        result1 = html.strip().replace('\u3000','')
    return result1


def get_html():
    first_num = 0
    limit_num = 1000
    while True:
        sql = "select * from {0} limit {1}, {2}".format('sucai_essay_html2', first_num, limit_num)

        cur.execute(sql)
        datas = cur.fetchall()
        if not datas:
            break

        for data in datas:
            html0 = parser_html(data['html'])
            html = '\n'.join(html0)
            pure_text = get_pure_text(html0)

            title = data['title']
            html = html.replace('\'', '').replace('\"', '')
            pure_text = pure_text.replace('\'', '').replace('\"', '')
            # html2db(data['spider_url'], title, html, data['keyword'], deal_spec_subject(data['title']), data['flag'],
            #         pure_text)

            try:
                html2db(data['spider_url'], title, html, data['keyword'], deal_spec_subject(data['title']), data['flag'], pure_text)
            except:
                logging.info('存储失败%s' % data['spider_url'])
                continue
        first_num += limit_num




def html2db(spider_url, title, html, keyword, spec_subject, flag, pure_text):

    item = {}
    item['spider_url'] = spider_url
    item['title'] = title
    item['html'] = html
    item['keyword'] = keyword
    item['spec_subject'] = spec_subject
    item['flag'] = flag
    item['pure_text'] = pure_text



    # print(pure_text)

    insert_sql = """insert into sucai_essay_html_parser (spider_url,title,html,keyword,spec_subject,flag,pure_text)VALUES("%s","%s","%s","%s","%s","%s","%s")""" \
                 % (item['spider_url'], item['title'], pymysql.escape_string(item['html']), item['keyword'], item['spec_subject'],
                    item['flag'], item['pure_text'])
    cur2.execute(insert_sql)
    conn2.commit()
    # logging.info(item['spider_url'])
    # logging.info('success')


if __name__ == '__main__':
    get_html()
    print('parse_Over')

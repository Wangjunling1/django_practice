def deal_tag(url):
    tag = []

    # zuowen
    if 'chengyu' in url:
        tag.append('成语')
    if 'zheli' in url:
        tag.append('哲理')
    if 'lunju' in url:
        tag.append('时事论据')
    if 'diangu' in url:
        tag.append('历史典故')
    if 'duanxinqf' in url:
        tag.append('短信祝福')
    if 'heka' in url:
        tag.append('贺卡')
    if 'kaochangsucaibao' in url:
        tag.append('考场素材')
    if 'yilunsucai' in url:
        tag.append('议论素材')
    if 'zcg' in url:
        tag.append('主持稿')
    if 'ganen' in url:
        tag.append('感恩故事')
    if 'tqmx' in url:
        tag.append('天气描写')
    if 'xqmx' in url:
        tag.append('心情描写')



    if 'haocihaoju' in url:
        tag.append('好词好句')
    if 'waimao' in url:
        tag.append('人物外貌')
    if 'ldj' in url:
        tag.append('劳动节')
    if 'qmj' in url:
        tag.append('清明节')
    if 'fuqin' in url:
        tag.append('父亲')
    if 'xiatian' in url:
        tag.append('夏天')
    if 'qiutian' in url:
        tag.append('秋天')
    # if 'chuntian' in url:
    #     tag.append('春天')
    if 'dongtian' in url:
        tag.append('冬天')
    if 'fengjing' in url:
        tag.append('风景')
    if 'zhiwu' in url:
        tag.append('植物')
    if 'youqing' in url:
        tag.append('友情')
    if 'qinggan' in url:
        tag.append('情感')
    if 'dongwu' in url:
        tag.append('动物')
    if 'xuexi' in url:
        tag.append('学习')
    if 'mama' in url:
        tag.append('妈妈')
    if 'laoshi' in url:
        tag.append('老师')
    if 'mqj' in url:
        tag.append('母亲节')
    if 'qnj' in url:
        tag.append('青年节')

    if 'duanluo' in url:
        tag.append('优美段落')
    if 'renwu' in url:
        tag.append('人物')
    if 'shengming' in url:
        tag.append('生命')
    if 'jieri' in url:
        tag.append('节日')
    # if 'lizhi' in url:
    #     tag.append('励志')
    if 'tongxue' in url:
        tag.append('同学')
    if 'qinqing' in url:
        tag.append('亲情')
    if 'jingse' in url:
        tag.append('景色')
    if 'shijian' in url:
        tag.append('时间')
    if 'dushu' in url:
        tag.append('读书')
    # if 'ganen' in url:
    #     tag.append('感恩')
    # if 'zhiwu' in url:
    #     tag.append('植物')
    if 'xiaoyuan' in url:
        tag.append('校园')


    if 'mingyan' in url:
        tag.append('名言警句')
    # if 'dushu' in url:
    #     tag.append('读书')
    if 'lizhi' in url:
        tag.append('励志')
    if 'chengzhang' in url:
        tag.append('成长')
    if 'aiguo' in url:
        tag.append('爱国')
    if 'zhongguo' in url:
        tag.append('中国')
    if 'guowai' in url:
        tag.append('国外')
    if 'gudai' in url:
        tag.append('古代')
    if 'xiandai' in url:
        tag.append('现代')
    if 'rensheng' in url:
        tag.append('人生')
    if 'aiqing' in url:
        tag.append('爱情')
    # if 'xuexi' in url:
    #     tag.append('学习名言')
    if 'chenggong' in url:
        tag.append('成功')
    if 'zixin' in url:
        tag.append('自信')
    if 'qingchun' in url:
        tag.append('青春')
    if 'chuangxin' in url:
        tag.append('创新')
    if 'daode' in url:
        tag.append('道德')
    # if 'lixiang' in url:
    #     tag.append('理想')
    if 'jiejian' in url:
        tag.append('节俭')
    if 'zhizhuo' in url:
        tag.append('执着')


    if 'mingren' in url:
        tag.append('名人故事')
    # if 'dushugushi' in url:
    #     tag.append('读书故事')
    # if 'lizhigushi' in url:
    #     tag.append('励志故事')
    # if 'aiguogushi' in url:
    #     tag.append('爱国故事')
    # if 'chengzhanggs' in url:
    #     tag.append('成长故事')
    # if 'gudaigushi' in url:
    #     tag.append('古代故事')
    if 'jindaigushi' in url:
        tag.append('近代故事')
    # if 'xiandaigushi' in url:
    #     tag.append('现代故事')
    if 'waiguogushi' in url:
        tag.append('外国故事')
    if 'shuxuejiags' in url:
        tag.append('数学家')
    if 'wuligs' in url:
        tag.append('物理学家')
    if 'faminggs' in url:
        tag.append('发明家')
    if 'zhexuegs' in url:
        tag.append('哲学家')
    if 'jiaoyusg' in url:
        tag.append('教育家')
    if 'wenxuegs' in url:
        tag.append('文学家')
    if 'huajiags' in url:
        tag.append('画家')
    if 'qiyegs' in url:
        tag.append('企业家')
    if 'tiyugs' in url:
        tag.append('体育明星')
    if 'dianyinggs' in url:
        tag.append('电影明星')
    if 'zhengzhigs' in url:
        tag.append('政治家')
    if 'jingjigs' in url:
        tag.append('经济学家')



    # ppzuowen
    if 'ciyu' in url:
        tag.append('词语')
    if 'haojuzidaquan' in url:
        tag.append('优美句子')
    # if 'youmeiduanluo' in url:
    #     tag.append('优美段落')
    if 'biyuju' in url:
        tag.append('比喻句')
    if 'paibiju' in url:
        tag.append('排比句')
    if 'nirenju' in url:
        tag.append('拟人句')
    if 'zaoju' in url:
        tag.append('造句')

    tag = list(set(tag))

    if len(tag) == 0:
        tag.append('其他')

    return ';'.join(tag)

def deal_spec_subject(title):
    if '小学' in title:
        spec_subject = 1
    elif '中考' in title:
        spec_subject = 2
    elif '高考' in title:
        spec_subject = 3
    else:
        spec_subject = 0
    return spec_subject







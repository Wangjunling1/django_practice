scp export/* work@hanyu01:/home/work/hanyu/home/hanyu/hanyu_static/zuowen_xml
scp export/* work@hanyu02:/home/work/hanyu/home/hanyu/hanyu_static/zuowen_xml
scp sucai_zuowen_list.txt work@hanyu01:/home/work/hanyu/home/hanyu/hanyu_static/zuowen_xml
scp sucai_zuowen_list.txt work@hanyu02:/home/work/hanyu/home/hanyu/hanyu_static/zuowen_xml

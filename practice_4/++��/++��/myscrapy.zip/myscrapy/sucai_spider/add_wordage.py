# -*- coding: utf-8 -*-

import pymysql

conn2 = pymysql.connect(host='172.16.0.100', user='root', passwd='123', db='hanyu_gaolaoshi',
                            port=13309, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
cur2 = conn2.cursor()

def deal_wordage(text):
    return len(text)

def change_wordage(url, num):
    sql = "update sucai_essay_html_parser set wordage='{0}' where spider_url='{1}'".format(num, url)
    cur2.execute(sql)
    conn2.commit()

def add_wordage():
    sql = "select pure_text,spider_url from sucai_essay_html_parser where flag='0'"

    cur2.execute(sql)
    datas = cur2.fetchall()
    for data in datas:
        change_wordage(data['spider_url'], deal_wordage(data['pure_text']))


if __name__ == '__main__':
    add_wordage()

# -*- coding: utf-8 -*-
import requests
import os
import sys
import logging
import pymysql
import random
from lxml import etree
from adsl_server.proxy import Proxy
_package = os.path.dirname(os.path.abspath(__file__))
sys.path.append(_package)
from deal_tag import deal_tag, deal_spec_subject

_proxy = Proxy(server_ids=list(range(1,5)))

LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                    filename='ppzuowen.log', filemode='a')

class ppzuowen():
    def __init__(self):
        self.headers = {
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6,zh-TW;q=0.4',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            }
        # self.server_id = random.randint(0, 5)
        # self.proxies = {'https': 'http://' + _proxy.get(server_id=self.server_id, port=9992)}

        self.conn = pymysql.connect(host='172.16.3.17', user='afanti_dw', passwd='afanti_dw_04', db='question_pre',
                               port=3306, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
        self.cur = self.conn.cursor()
        self.url_root_list = ['https://www.ppzuowen.com/sucai/chengyuciyu/',
                              'https://www.ppzuowen.com/sucai/haojuzidaquan/',
                              'https://www.ppzuowen.com/sucai/youmeiduanluo/',
                              'https://www.ppzuowen.com/sucai/biyuju/biyuju/',
                              'https://www.ppzuowen.com/sucai/biyuju/paibiju/',
                              'https://www.ppzuowen.com/sucai/biyuju/nirenju/',
                              'https://www.ppzuowen.com/sucai/biyuju/zaoju/',
                              'https://www.ppzuowen.com/sucai/haocihaoju/'
                              ]
    def get_next_page_url(self, url):
        url_list = []
        url_root = url
        while True:
            url_list.append(url)
            # r = requests.get(url, headers=self.headers, proxies=self.proxies)
            r = requests.get(url, headers=self.headers)
            r.encoding = 'gbk'
            demo = etree.HTML(r.text)
            try:
                next_page = demo.xpath("//ul[@class='pagelist']/li/a[text()='下一页']/@href")
                url = url_root + next_page[0]
            except:
                url_list.append(url)
                break
        return list(set(url_list))

    def get_per_url(self, url):
        r = requests.get(url, headers=self.headers)
        r.encoding = 'gbk'
        demo = etree.HTML(r.text)
        html_url_list = demo.xpath("//ul[@class='specialList']/li/a/@href")
        html_title_list = demo.xpath("//ul[@class='specialList']/li/a/text()")

        return html_url_list, html_title_list



    def get_html(self, url):
        r = requests.get('https://www.ppzuowen.com' + url, headers=self.headers)
        r.encoding = 'gbk'
        return r.text

    def html2db(self, url, html, title, key):

        item = {}
        item['spider_url'] = url
        item['title'] = title
        item['html'] = html
        item['keyword'] = key
        item['spec_subject'] = deal_spec_subject(title)
        item['flag'] = 0
        item['pure_text'] = ''

        insert_sql = """insert into sucai_ppessay_html5 (spider_url,title,html,keyword,spec_subject,flag,pure_text)VALUES("%s","%s","%s","%s","%s","%s","%s")""" \
                     % (item['spider_url'], item['title'], pymysql.escape_string(item['html']), item['keyword'], item['spec_subject'],
                        item['flag'], item['pure_text'])
        self.cur.execute(insert_sql)
        self.conn.commit()

    def run(self):
        for root_url in self.url_root_list:
            keyword = deal_tag(root_url)
            try:
                next_page_list = self.get_next_page_url(root_url)
            except:
                logging.info('连接失败0')
                continue

            for per_page_url in next_page_list:
                try:
                    per_url_list,per_url_title = self.get_per_url(per_page_url)
                except:
                    logging.info('连接失败1')
                    continue
                for i,j in zip(per_url_list, per_url_title):
                    try:
                        html = self.get_html(i)
                    except:
                        logging.info('连接失败2')
                        continue
                    try:
                        self.html2db('https://www.ppzuowen.com' + i, html, j, keyword)
                    except:
                        logging.info('存储失败%s' % i)
            print('爬取完成%s' % root_url)




spider = ppzuowen()
spider.run()
print('pp_Over')
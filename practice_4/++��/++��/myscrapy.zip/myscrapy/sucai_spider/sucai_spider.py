# -*- coding: utf-8 -*-
import requests
import os
import sys
import logging
import pymysql
import random
from lxml import etree
_package = os.path.dirname(os.path.abspath(__file__))
sys.path.append(_package)
from adsl_server.proxy import Proxy
from deal_tag import deal_tag, deal_spec_subject
_proxy = Proxy(server_ids=list(range(1,5)))


LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                    filename='zuowensucai.log', filemode='a')
proxies_list = [{'http': 'http://183.129.11.84:9990'}, {'http': 'http://180.109.145.239:9990'}, {'http': 'http://123.180.68.210:9990'}]


class sucai_spider():

    def __init__(self):
        self.headers = {
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6,zh-TW;q=0.4',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            }
        # self.server_id = random.randint(0, 5)
        # self.proxies = {'https': 'http://' + _proxy.get(server_id=self.server_id, port=9992)}
        self.conn = pymysql.connect(host='172.16.3.17', user='afanti_dw', passwd='afanti_dw_04', db='question_pre',
                               port=3306, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
        self.cur = self.conn.cursor()
        self.url_a = ['http://www.zuowen.com/sucai/haocihaoju/', 'http://www.zuowen.com/sucai/duanluo/',
                      'http://www.zuowen.com/sucai/mingyan/', 'http://www.zuowen.com/sucai/mingren/'
                      ]
        self.url_b = ['http://www.zuowen.com/sucai/chengyu/', 'http://www.zuowen.com/sucai/zheli/',
                      'http://www.zuowen.com/sucai/lunju/', 'http://www.zuowen.com/sucai/diangu/',
                      'http://www.zuowen.com/sucai/duanxinqf/', 'http://www.zuowen.com/sucai/heka/',
                      'http://www.zuowen.com/sucai/kaochangsucaibao/','http://www.zuowen.com/sucai/yilunsucai/',
                      'http://www.zuowen.com/sucai/zcg/',
                      'http://www.zuowen.com/sucai/ganen/', 'http://www.zuowen.com/sucai/tqmx/',
                      'http://www.zuowen.com/sucai/xqmx/']

    def run(self):
        for url in self.url_b:
            # 所有页面的url
            try:
                url_list = list(set(self.get_url_list_b(url)))
            except:
                logging.info('连接失败b0')
                continue
            keyword = deal_tag(url)
            for i in url_list:
                # 单个页面的所有作文url和title
                try:
                    url_b,url_title_b = self.get_html_url_b(i)
                except:
                    logging.info('连接失败b1')
                    continue

                for j,k in zip(url_b,url_title_b):
                    try:
                        html_b = self.get_html_b(j)
                    except:
                        logging.info('连接失败b3 %s' % j)
                        continue
                    try:
                        self.html2db(j, html_b, k, keyword)
                    except:
                        logging.info(j)
            print('%s下载完成' % url)

        for url in self.url_a:
            url_list_a1 = self.get_url_list_a1(url)

            for url1 in url_list_a1:
                keyword = deal_tag(url1)
                url_list_a2 = list(set(self.get_url_list_a2(url1)))
                for html_url in url_list_a2:
                    url_a, url_title_a = self.get_html_url_a(html_url)

                    for j,k in zip(url_a, url_title_a):
                        html_a = self.get_html_a(j)
                        try:
                            self.html2db(j, html_a, k, keyword)
                        except:
                            logging.info(j)
                print('%s下载完成' % url1)

    def get_url_list_a1(self, url):

        r = requests.get(url, headers=self.headers, timeout=10)
        r.encoding = 'gbk'
        demo = etree.HTML(r.text)
        url_list = demo.xpath("//div[@class='cs-demand']//a[@target='_blank']/@href")

        return url_list

    def get_url_list_a2(self, url):
        url_list = []
        while True:
            url_list.append(url)
            r = requests.get(url, headers=self.headers, timeout=10)
            r.encoding = 'gbk'
            demo = etree.HTML(r.text)
            try:
                next_page = demo.xpath("//a[text()='下一页']/@href")
                url = next_page[0]
            except:
                url_list.append(url)
                break
        return url_list


    def get_html_a(self, url):
        r = requests.get(url, headers=self.headers, timeout=10)
        r.encoding = 'gbk'
        return r.text

    def get_html_url_a(self, url):
        r = requests.get(url, headers=self.headers, timeout=10)
        r.encoding = 'gbk'
        demo = etree.HTML(r.text)
        html_url_list = demo.xpath("//div[@class='artbox_l']/div[@class='artbox_l_t']/a/@href")
        html_title_list = demo.xpath("//div[@class='artbox_l']/div[@class='artbox_l_t']/a/text()")

        return html_url_list,html_title_list


    def get_url_list_b(self, url):
        url_list = []
        while True:
            url_list.append(url)
            r = requests.get(url, headers=self.headers, timeout=10)
            r.encoding = 'gbk'
            demo = etree.HTML(r.text)
            try:
                next_page = demo.xpath("//a[text()='下一页']/@href")
                url = next_page[0]
            except:
                url_list.append(url)
                break
        return url_list

    def get_html_b(self, url):
        r = requests.get(url, headers=self.headers, timeout=10)
        r.encoding = 'gbk'
        return r.text

    # 获取单个作文的url与title
    def get_html_url_b(self, url):
        r = requests.get(url, headers=self.headers, timeout=10)
        r.encoding = 'gbk'
        demo = etree.HTML(r.text)
        html_url_list = demo.xpath("//div[@class='artbox_l']/div[@class='artbox_l_t']/a/@href")
        html_title_list = demo.xpath("//div[@class='artbox_l']/div[@class='artbox_l_t']/a/text()")

        return html_url_list,html_title_list


    def html2db(self, url, html, title, key):

        item = {}
        item['spider_url'] = url
        item['title'] = title
        item['html'] = html
        item['keyword'] = key
        item['spec_subject'] = deal_spec_subject(title)
        item['flag'] = 0
        item['pure_text'] = ''

        insert_sql = """insert into sucai_essay_html5 (spider_url,title,html,keyword,spec_subject,flag,pure_text)VALUES("%s","%s","%s","%s","%s","%s","%s")""" \
                     % (item['spider_url'], item['title'], pymysql.escape_string(item['html']), item['keyword'], item['spec_subject'],
                        item['flag'], item['pure_text'])
        self.cur.execute(insert_sql)
        self.conn.commit()
        # logging.info(item['spider_url'])
        # logging.info('success')


spider = sucai_spider()
spider.run()
print('sucai_Over')

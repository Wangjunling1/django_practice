import os
import re
import json
import math
import logging
import pymysql
from w3lib.html import remove_tags
import pymysql.cursors
from collections import OrderedDict
from etcd.client import Client
from zuowen_xml_lib.deal_phrase_lib import (
    to_xml_file,
    removeXml,
)

LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                                filename='zuowen_xml.log', filemode='a')

_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(_DIR, 'config')
OUTPUT = _DIR + '/export/'

conn = pymysql.connect(host='172.16.3.17', user='afanti_dw', passwd='afanti_dw_04', db='question_pre',
                            port=3306, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
cur = conn.cursor()
# conn2 = pymysql.connect(host='172.16.0.100', user='root', passwd='123', db='hanyu_gaolaoshi',
#                             port=13309, charset="utf8", use_unicode=True, cursorclass=pymysql.cursors.DictCursor)
# cur2 = conn2.cursor()


def deal_school(num):
    if num == 0:
        return ''
    elif num == 1:
        return '小学'
    elif num == 2:
        return '初中'
    else:
        return '高中'


def getXML():

    first_num = 0
    limit_num = 4000

    while True:
        sql = "select * from {0} where flag='0' limit {1}, {2}".format('sucai_essay', first_num, limit_num)
        cur.execute(sql)
        datas = cur.fetchall()

        if not datas:
            break

        xml_data = OrderedDict()
        xml_data['DOCUMENT'] = OrderedDict()

        new_list = []
        for data in datas:
            data_dict = OrderedDict()
            essay_id = data['zid']
            data_dict['key'] = essay_id

            data_dict['display'] = OrderedDict()
            data_dict['display']['title'] = data['title']
            # 待定
            data_dict['display']['url'] = 'http://zuowen.afanti100.com/choose.html?main_type=素材作文'
            # 待定
            data_dict['display']['pcurl'] = 'http://zuowen.afanti100.com/choose.html?main_type=素材作文'

            data_dict['display']['detail'] = data['pure_text'][:300].strip()
            # 待定
            data_dict['display']['link'] = 'http://zuowen.afanti100.com/zuowen.html?id=%s&main_type=素材作文' % essay_id
            # 待定
            data_dict['display']['pclink'] = 'http://zuowen.afanti100.com/zuowen.html?id=%s&main_type=素材作文' % essay_id
            data_dict['display']['source'] = '阿凡题作文'
            data_dict['display']['school'] = deal_school(data['spec_subject'])
            data_dict['display']['tag'] = data['keyword'].replace('考场素材','考场')

            data_dict['display']['showname'] = '阿凡题'
            data_dict['display']['showurl'] = 'http://zuowen.afanti100.com'

            new_list.append(data_dict)

        xml_data['DOCUMENT']['item'] = new_list
        to_xml_file(
            xml_data=xml_data,
            filename=OUTPUT + 'zuowensucai_{}.xml'.format(math.ceil(first_num / limit_num)),
            encoding='utf-8'
        )

        first_num += limit_num


if __name__ == '__main__':
    removeXml(OUTPUT)
    getXML()
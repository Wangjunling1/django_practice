
from scrapy.cmdline import execute

execute(['scrapy','crawl','weilai', '-s', 'JOBDIR=crawls/weilai1122-1'])

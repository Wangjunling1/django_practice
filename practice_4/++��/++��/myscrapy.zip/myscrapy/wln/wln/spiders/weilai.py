# -*- coding: utf-8 -*-
from scrapy.linkextractors import LinkExtractor
from wln.items import WlnItem
from .common import SUBJ_TO_RSUBJ
import scrapy
import json
import datetime
import logging
import copy
import requests
import hashlib
import re

Header = {
    "Cookie": "PHPSESSID=f5dcfslvlkrbuia7l9snfbilp9; SubjectId=0; wln_user_USER=13051168817; wln_user_UID=236724; wln_user_CODE=375336779593a062226271353741eb73",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",
    "X-Requested-With": "XMLHttpRequest",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",

}

logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)

class WeilaiSpider(scrapy.Spider):

    name = 'weilai'
    start_urls = ['https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/12',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/13',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/14',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/15',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/16',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/17',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/18',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/19',
                'https://www.wln100.com/Doc/Doc/show/grade/0/area/0/tid/0/times/0/year/0/sid/20']
    count = 0



    def __init__(self):
        fh = logging.FileHandler('weilainao.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    
    def EscapeString(self, string):
        string = string.replace('\'','\'\'').replace('"','\\"')
        return string
    """
    def parse(self, response):
        css_list = ['a.area']
        for i in css_list:
            le = LinkExtractor(restrict_css = i)
            #logger.error(i)
            for link in le.extract_links(response)[1:]:
                yield scrapy.Request(url = link.url, callback = self.parse_final_page, dont_filter=True)
                #logger.error("[Area_Finish]已爬取完{}".format(link.text))"""

    def parse(self, response):
        try:
            page_num_html = response.xpath('//div[@class="page-box"]/a/@href').extract()[-1]
            num = re.findall(r'p/(.*?)/', page_num_html)[0]
            for i in range(1, int(num)+1):
                url = response.url+'/p/'+str(i)
                yield scrapy.Request(url = url, callback = self.parse_test,dont_filter = True,
                                        meta = {'origin_url':url})
        except Exception as e:
            logger.error('{} 没有最后一页 ,'.format(response.url))



    def parse_test(self, response):
        #logger.error(response.url)
        meta = copy.copy(response.meta)
        try:
            subject_key = re.findall(r'sid/[0-2][0-9]', response.url)[0]
            meta['subject'] = SUBJ_TO_RSUBJ[subject_key]
        except Exception as e:
            logger.error(e)
        le = LinkExtractor(restrict_css = 'td.sjtit')
        for link in le.extract_links(response):
            yield scrapy.Request(link.url, callback = self.parse_num, meta = meta)



    def parse_num(self,response):

        meta = copy.copy(response.meta)
        docname = response.xpath("//h1[@id='docname']/text()").extract_first()
        num = response.xpath("//span[@class='test-attr']/text()").extract()
        meta['docname'] = docname
        for i in num:
            if i != ' ':
                num = str(i).strip()
                meta['num'] = num
                url = "https://www.wln100.com/Test/"+str(num)+".html"
                yield scrapy.Request(url, callback = self.parse_detail, meta = meta)
                

    def parse_detail(self, response): 
        
        if response.status == 200:

            meta = copy.copy(response.meta)
            items = WlnItem()
            items['origin_url'] = meta['origin_url']
            items['source'] = 52
            items['docname'] = meta['docname']
            items['subject'] = meta['subject']
            items['key'] = "wln100_qs_"+ meta['num']
            items['info'] = ''
            items['request_info'] = {"method":"GET", 'url': 'https://www.wln100.com/Test/1103710.html',
                    "method2":"POST", 'url2':'https://www.wln100.com/Test/TestPreview/getOneTestById.html'}


            html = response.url

            question = [self.EscapeString(i) for i in response.xpath('//div[@class="test-item-body TD-body f-roman"]/p').extract()]
            question_type = response.xpath('//div[@class="TD-head clearfix"]/p[@class="left"]/text()').extract_first()
            difficuly = len(response.xpath('//a[@class="staryellow"]').extract())
            knowledge_point = response.xpath('//div[@class="answer-context f-roman"]/text()').extract_first()
            if knowledge_point:
                knowledge_point = self.EscapeString(knowledge_point)
            else:
                knowledge_point = ''
            items['record_time'] = datetime.datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S')

            answer_url = 'https://www.wln100.com/Test/TestPreview/getOneTestById.html'
            formdata = {
                "id": str(meta['num']),
                "width": "500",
                "s": "0.7045812284290378",
            }
            try:
                hide_info = requests.post(answer_url, data=formdata, headers=Header)
                hide_info = json.loads(hide_info.content.decode())
            except:
                logger.error("爬取 {} 失败，原因是json解析错误失效。 ".format(response.url))
            try:
                analytic = self.EscapeString(hide_info['data'][1][0][0]['analytic'])
                answer = self.EscapeString(hide_info['data'][1][0][0]['answer'])
                remark = self.EscapeString(hide_info['data'][1][0][0]['remark'])
                items['html'] = {'html':html,'question':question, 
                                'quesiton_type':question_type, 'difficuly':difficuly, 
                                'knowledge_point':knowledge_point, 'analytic':analytic,
                                'answer':answer, 'remark': remark}
                m2 = hashlib.md5()
                m2.update(str(items['html']).encode('utf-8'))
                items['md5'] = m2.hexdigest()
                items['flag'] = 0
                items['flag_str'] = ''
                yield items

            except Exception as e:
                #logger.error("爬取 {} 失败， 原因是cookies失效。".format(
                    #response.url))
                self.count += 1
                if self.count <= 5:
                    #print(self.count)
                    logger.error("正在尝试重新访问{},访问次数为{}".format(response.url, self.count))
                    scrapy.Request(response.url, callback = self.parse_detail, 
                                        meta = meta)
                else:
                    self.count = 0
                    #print(self.count)
                    logger.error("访问{}失败".format(response.url))

        else:
            #logger.error('爬取{} 失败 cookie失效 {}'.format(response.url, response.status))
            self.count += 1
            if self.count > 5:
                logger.error('爬取{} 失败，状态码是 {}。'.format(response.url, response.status))
            yield scrapy.Request(response.url, callback = self.parse_detail, 
                                                meta = meta)




        

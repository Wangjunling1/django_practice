# coding: utf-8

with open ("/users/wangkaixi/desktop/weilainao.txt") as f:
    qq = f.read().decode()

print(qq)
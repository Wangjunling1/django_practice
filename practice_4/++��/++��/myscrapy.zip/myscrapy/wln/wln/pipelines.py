# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from wln.spiders.weilai import logger
import json
import pymysql

class WlnPipeline(object):

    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  #使用自己的用户名
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        select_sql = 'select * from wln100_html_archive_2018_11_17 where `key` = "%s"'%item['key']
        self.db_cur.execute(select_sql)
        result = self.db_cur.fetchone()
        if result:
            #logger.error('[error:已有该题目{}]'.format(item['key']))
            return

        insert_sql = '''
                      INSERT INTO wln100_html_archive_2018_11_17
                      (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`record_time`,`flag`,`flag_str`,`docname`,`origin_url`)
                      VALUES (%d,%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')
                     '''%(item['source'],item['subject'],json.dumps(item['html'],ensure_ascii=False),item['md5'],item['key'],
                          json.dumps(item['request_info']),item['info'],item['record_time'],item['flag'],item['flag_str'],
                          item['docname'],item['origin_url'])
        #print(insert_sql)
        try:
            self.db_cur.execute(insert_sql)
            self.client.commit()
            logger.error("发现了一个新节点  {}".format(item['key']))
        except Exception as e:
            logger.error('[Pipeline][插入语句出现错误 , 语句是{}。]'.format(insert_sql))

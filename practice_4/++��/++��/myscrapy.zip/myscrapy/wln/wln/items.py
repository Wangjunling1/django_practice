# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

from scrapy import Item, Field


class WlnItem(Item):

    html_id = Field()
    source = Field()
    subject = Field()
    html = Field()
    md5 = Field()
    key = Field()
    request_info = Field()
    info = Field()
    record_time = Field()
    flag = Field()
    flag_str = Field()  
    docname = Field() 
    origin_url = Field()

from scrapy.cmdline import execute

execute(['scrapy','crawl','scrapy_91taoke'])
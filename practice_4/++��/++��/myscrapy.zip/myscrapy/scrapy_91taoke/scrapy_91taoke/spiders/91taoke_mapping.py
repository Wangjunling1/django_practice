#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 12 11:14:17 2018

@author: xiaopeng
"""

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import json
def get_mapping():
    info_list_file = open("/Users/xiaopeng/Desktop/info_list.txt",'w')
    info_list_file.truncate()
    info_list_file.close()
    driver = webdriver.Chrome("/Users/xiaopeng/Downloads/chromedriver")
    driver.get("http://91taoke.com/Juanzi/")
    singleclick = driver.find_element_by_xpath('//*[@id="scrollTop"]/div/div[1]/span/a')
    ActionChains(driver).click(singleclick).perform()
    
    grade = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[1]")
    gradedd = grade.find_elements_by_tag_name("dd")
    for i in range(len(gradedd)):
        #点击学段标签
        item = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[1]"+"/dd["+str(i+1)+"]")
        gradename = item.text
        ActionChains(driver).click(item).perform()
        
        subject = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[2]")
        subjectdd = subject.find_elements_by_tag_name("dd")
        for i in range(len(subjectdd)):
            item = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[2]"+"/dd["+str(i+1)+"]")
            #点击学科标签
            subjectname = item.text
            ActionChains(driver).click(item).perform()
            
            version = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[3]")
            versiondd = version.find_elements_by_tag_name("dd")
            for i in range(len(versiondd)):
                item = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[3]"+"/dd["+str(i+1)+"]")
                #点击版本标签
                versionname = item.text
                ActionChains(driver).click(item).perform()
                mode = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[4]")
                modedd = mode.find_elements_by_tag_name("dd")
                for i in range(len(modedd)):
                    info = {}
                    item = driver.find_element_by_xpath("//*[@id='scrollTop']/div/div[1]/span/div/dl[4]"+"/dd["+str(i+1)+"]")
                    #点击模块标签
                    modename = item.text
                    ActionChains(driver).click(item).perform()                  
                    url = driver.current_url
                    url_id = url.split("/")[-1]
                    info['id'] = url_id
                    info['version_name'] = versionname + " " + modename
                    info['subject_name'] = subjectname
                    info['grade'] = gradename
                    print(info)
                    
                    info_list_file = open("/Users/xiaopeng/Desktop/info_list.txt",'a+')
                    info_list_file.write(str(info)+"\n")
                    
                    print("当前的url是{0}".format(url))
                    singleclick = driver.find_element_by_xpath('//*[@id="scrollTop"]/div/div[1]/span/a')
                    ActionChains(driver).click(singleclick).perform()


    
if __name__ == "__main__":
    get_mapping()
    
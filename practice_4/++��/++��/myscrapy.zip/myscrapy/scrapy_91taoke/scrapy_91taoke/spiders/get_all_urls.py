import requests
import re
import time
import logging
from scrapy_91taoke.adsl_server.proxy import Proxy
# from scrapy_91taoke.user_agent_lib.user_agent import UserAgent
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException

driver = webdriver.PhantomJS("scrapy_91taoke/spiders/phantomjs")
base_url = "http://91taoke.com/Juanzi/index/id/"

def get_question(html_string):
    mod = re.search(r'data-id="(\d+)"', html_string)
    if not mod:
        return None

    qid = mod.group(1)
    qs = {
        'key': '91taoke_qs_{}'.format(qid),
        'html': html_string
    }
    return qs

def get_page_num(id):
    # user_agent = UserAgent()
    # headers = {
    #     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    #     'Accept-Encoding': 'gzip, deflate, sdch',
    #     'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6,zh-TW;q=0.4',
    #     'Upgrade-Insecure-Requests': '1',
    #     'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36',
    # }
    # headers['User-Agent'] = user_agent.get()
    whole_url = base_url+id
    print(whole_url)
    try:
        driver.get(whole_url)
        WebDriverWait(driver,20).until(EC.visibility_of_element_located((By.LINK_TEXT,"下一页")))
    except Exception as e:
        print(e)
        logging.error('[get_page_num][error]: {}'.format(e))
        pass
        # return get_page_num(id)

    html_string = driver.page_source
    mod = re.search(r'条记录 1/(\d+) 页', html_string)
    try:
        page_num = mod.group(1)
    except:
        page_num = 0
        pass
    return page_num

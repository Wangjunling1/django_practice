import scrapy
import os
import hashlib
import requests
import urllib
import urllib.parse
import logging
import json
from .get_all_urls import *
from bs4 import BeautifulSoup
from afanti_tiku_lib.html.extract import get_html_element

class MySpider(scrapy.Spider):
    '''
    功能：爬取91淘课网上面所有的题的html,存入数据库
    '''
    name = 'scrapy_91taoke'
    allowed_domains = ["91taoke.com"]
    start_urls = ["http://www.91taoke.com/"]
    def __init__(self):
        pass
    def parse(self,response):

        info_file = open("scrapy_91taoke/spiders/info_list.txt", "r")
        info_content = info_file.read()
        info_list = json.loads(info_content)
        for info in info_list:
            print(info)
            page_num = get_page_num(info['id'])
            for i in range(int(page_num)):
                spider_url = "http://www.91taoke.com/Juanzi/ajaxlist?id={}&zjid=&tixing=0&nandu=0&search=&leixing=&gaosan_diqu=0&gaosan_nian=0&p={}&xuekename={}&gaosan_nian_id="\
                .format(info['id'],i+1,info['subject_name'])
                yield scrapy.Request(spider_url,meta={'info':info,'url':spider_url},callback=self.parse_detali)
        driver.quit()
        os.system('killall phantomjs')

    def parse_detali(self,response):
        print(response.meta['url'])
        html_string = response.text
        soup = BeautifulSoup(html_string,'lxml')
        qs_list = []
        first_single_qus = soup.find('div',attrs={'class':'questInfoBox clearfix'})
        all_single_qus = first_single_qus.find_next_siblings('div',attrs={'class':'questInfoBox clearfix'})

        multi_main = soup.find_all(name='div',attrs={'style':'font-size:14px; color:#000;'})
        multi_qus = soup.find_all(name='div',attrs={'style':'overflow-x:hidden; overflow-y:auto; clear:both;'})
        result = first_single_qus.find('div', attrs={'class': 'questInfo xhr_questInfo'})
        if not result:
            qs = get_question(str(first_single_qus))
            qs_list.append(qs)
        for item in all_single_qus:
            qs = get_question(str(item))
            qs_list.append(qs)

        if len(multi_main)==len(multi_qus):
            for i in range(len(multi_main)):
                main_questInfoBox = multi_main[i].select('div[class="questInfoBox clearfix"]')
                qus_questInfoBox = multi_qus[i].select('div[class="questInfoBox clearfix"]')
                questInfoTitle = multi_qus[i].select('p[class="questInfoTitle xhr_questInfoTitle"]')
                qs_str = ''
                for item in main_questInfoBox:
                    qs_str += str(item)
                for item in qus_questInfoBox:
                    qs_str += str(item)
                for item in questInfoTitle:
                    qs_str += str(item)

                qs = get_question(qs_str)
                qs_list.append(qs)
        print(len(qs_list))
        for item in qs_list:
            m2 = hashlib.md5()
            m2.update(item['html'].encode('utf-8'))
            item['md5'] = m2.hexdigest()
            item['info'] = response.meta['info']
            yield item
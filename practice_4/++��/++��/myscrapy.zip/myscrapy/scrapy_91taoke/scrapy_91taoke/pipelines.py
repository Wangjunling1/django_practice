# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from . import settings
import re
import json
import pymysql
import logging

class Scrapy91TaokePipeline(object):
    def __init__(self):
        # 连接数据库
        self.connect = pymysql.connect(
            host=settings.MYSQL_HOST,
            db=settings.MYSQL_DBNAME,
            user=settings.MYSQL_USER,
            passwd=settings.MYSQL_PASSWD,
            charset='utf8',
            use_unicode=True)

        # 通过cursor执行增删查改
        self.cursor = self.connect.cursor()
    def process_item(self, item, spider):
        try:
            item['html'] = pymysql.escape_string(item['html'])
            insert_sql = '''
                        INSERT INTO `html_archive`.`91taoke_spider_html_archive_table_copy1`(`source`, `subject`, `html`, `md5`, `key`, `request_info`, `info`)
                        VALUES(25,0,'%s','%s','%s','',\"%s\");
                        '''%(item['html'],item['md5'],item['key'],item['info'])
            # select_sql = "select * from `html_archive`.`91taoke_spider_html_archive_table` where key='%s'"%(item['key'])
            # self.cursor.execute(select_sql)
            # match_qus = self.cursor.fetchall()
            # if len(match_qus) >= 1:
            #     logging.warn("[process_item][info]:已经有这道题")
            #     return
            self.cursor.execute(insert_sql)
            self.connect.commit()
        except Exception as e:
            pass
            # logging.error("[process_item][error]:{}".format(e))
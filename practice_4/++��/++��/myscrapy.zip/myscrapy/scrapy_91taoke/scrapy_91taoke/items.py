# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class Scrapy91TaokeItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    # 爬取的目标网页url
    source = scrapy.Filed()
    # 学科名
    subject = scrapy.Filed()
    html = scrapy.Filed()
    md5 = scrapy.Filed()
    key = scrapy.Filed()
    request_info = scrapy.Filed()
    info = scrapy.Filed()



import logging
import json
import MySQLdb.cursors
import re
from scrapy_91taoke import settings
from afanti_tiku_lib.html.extract import get_html_element
from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.dbs.sql import insert_sql, select_sql
from afanti_tiku_lib.html.beautify_html import center_image, remove_tag
from bs4 import BeautifulSoup

OPTIONS = dict((k, v) for k, v in enumerate('abcdefghijklmnopqrstuvwxyz'))
DIFF = {
'基础题': 30,
'中档题': 60,
'较难题': 90,
}
SUBJECT = {
    '语文':1,
    '数学':2,
    '英语':3,
    '物理':5,
    '化学':6,
    '生物':9,
    '地理':7,
    '政治':10,
    '历史':8,
    '通用技术':11,
    '信息技术':12,
}
# 连接数据库
connect = MySQLdb.connect(
    host=settings.MYSQL_HOST,
    db=settings.MYSQL_DBNAME,
    user=settings.MYSQL_USER,
    passwd=settings.MYSQL_PASSWD,
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,
)

connect_db_offline = MySQLdb.connect(
    host=settings.MYSQL_HOST,
    db="question_db_offline",
    user=settings.MYSQL_USER,
    passwd=settings.MYSQL_PASSWD,
    charset='utf8',
    use_unicode=True)
# 通过cursor执行增删查改
cursor = connect.cursor()
offline_cursor = connect_db_offline.cursor()

class Scrapy_91Taoke_Parse(object):
    def __init__(self,archive_image=False, download=False):
        self.html_magic = HtmlMagic(25, archive_image=archive_image,
                                    download=download, beautify=False)


    def parse(self,url, html_string, info, aft_subj_id):
        cols = dict()
        is_mqs = is_multi_qus(html_string)
        if is_mqs:
            question_html, option_html = get_multi_question(html_string)
        else:
            question_html, option_html = get_question(html_string)
        question_html = self.html_magic.bewitch(question_html,spider_url=url)
        cols['question_html'] = question_html
        if option_html:
            option_html = self.html_magic.bewitch(option_html,spider_url=url)
            option_html = center_image(option_html)
        cols['option_html'] = option_html

        if is_mqs:
            answer_all_html, jieda, cols['knowledge_point'],cols['difficulty']  = get_multi_answers(html_string)
        else:
            answer_all_html, jieda, cols['knowledge_point'],cols['difficulty']  = get_answers(html_string)

        answer_all_html = self.html_magic.bewitch(answer_all_html,
                                                  spider_url=url)
        cols['answer_all_html'] = center_image(answer_all_html)
        jieda = self.html_magic.bewitch(jieda, spider_url=url)
        cols['jieda'] = center_image(jieda)

        # cols['difficulty'] = difficulty
        #
        # cols['knowledge_point'] = kp

        cols['version'] = 0
        cols['version_name'] = info['version_name']

        cols['fenxi'] = ''
        cols['exam_year'] = 0
        cols['exam_city'] = ''
        cols['spider_url'] = url
        cols['subject'] = SUBJECT[aft_subj_id]
        cols['zhuanti'] = ''
        cols['dianping'] = ''
        cols['spider_source'] = 57
        cols['question_type'] = 0
        cols['question_quality'] = 0

        # print('科目')
        # print(cols['subject'])
        # print('题目')
        # print(cols['question_html'])
        # print('选项')
        # print(cols['option_html'])
        # print('答案')
        # print(cols['answer_all_html'])
        # print('解析')
        # print(cols['jieda'])
        # print('难度')
        # print(cols['difficulty'])
        # print('知识点')
        # print(cols['knowledge_point'])
        # print('版本')
        # print(cols['version_name'])
        # print('标识号')
        # print(cols['spider_url'])
        # print('\n\n\n\n')
        return cols


scrapy_91taoke_parse = Scrapy_91Taoke_Parse()

def main():
    sql = "select * from 91taoke_spider_html_archive_table_copy1 where html_id > 0"
    cursor.execute(sql)
    result = cursor.fetchone()
    while result is not None:
        is_in = offline_cursor.execute("select * from 91taoke_question_20180911 where spider_url='%s'"%result['key'])
        if is_in:
            result = cursor.fetchone()
            continue
        qus_data = scrapy_91taoke_parse.parse(result['key'],result['html'],eval(result['info']),eval(result['info'])['subject_name'])
        insert_sql = '''insert into 91taoke_question_20180911 (spider_source,spider_url,knowledge_point,subject,zhuanti,exam_year,
                        exam_city,difficulty,version,version_name,question_type,question_quality,question_html,option_html,
                        answer_all_html,jieda,fenxi,dianping,
                        flag) values(%d,'%s','%s',%d,'%s',%d,'%s',%d,%d,'%s',%d,%d,'%s','%s','%s','%s','%s','%s',%d)
                        '''%(qus_data['spider_source'],qus_data['spider_url'],qus_data['knowledge_point'],qus_data['subject'],qus_data['zhuanti']
                             ,qus_data['exam_year'],qus_data['exam_city'],qus_data['difficulty'],qus_data['version'],qus_data['version_name'],
                             qus_data['question_type'],qus_data['question_quality'],qus_data['question_html'],qus_data['option_html'],qus_data['answer_all_html'],
                             qus_data['jieda'],qus_data['fenxi'],qus_data['dianping'],0)

        try:
            offline_cursor.execute(insert_sql)
            connect_db_offline.commit()
        except:
            # print("已经有记录")
            pass
        result = cursor.fetchone()
    cursor.close()
    offline_cursor.close()
    connect.close()
    connect_db_offline.close()
def get_question(html_string):
    qs = get_html_element('div class="questInfo">\s+<a ', html_string,
                          regex=True, with_tag=False, limit=1)[0]

    # options = get_html_element('<ol>', qs, with_tag=False)
    soup = BeautifulSoup(qs,'html.parser')
    options = soup.find(name='ol')
    option_html = ''
    if options:
        option_items = get_html_element('<li style="width: 50%;float: left">',str(options), with_tag=False)
        if not option_items:
            option_items = get_html_element('<li>', str(options), with_tag=False)
        # option_items = options.find_all(name='li',attrs={'style':True})
        if option_items:
            option_html = make_option(option_items)
    # if len(options) == 1:
    #     opts = get_html_element('<li>', options[0], with_tag=False)
    #     option_html = make_option(opts)

    qs = qs.replace(str(options),'')
    return qs.strip(), option_html.strip()

def get_multi_question(html_string):
    chucks = get_html_element('<div class="questInfoBox clearfix"',
                              html_string, with_tag=False)
    qs_body = get_html_element('<div class="questInfo xhr_questInfo"',
                               chucks[0], with_tag=False, limit=1)[0]

    sub_qss = [get_question(chuck) for chuck in chucks[1:]]
    for sub_qs in sub_qss:
        qs_body += '<p>{}</p>'.format(''.join(sub_qs))
    return qs_body.strip(), ''



def is_multi_qus(html_string):
    soup = BeautifulSoup(html_string,'html.parser')
    xhr_qusinfo = soup.find(name='div',attrs={'class':'questInfo xhr_questInfo'})
    if xhr_qusinfo:
        return True
    else:
        return False

def make_option(options):
    tr_t = '<tr><td class="aft_option" data="{}">{}</td></tr>'
    option = '<table class="aft_option_wrapper" style="width: 100%;"><tbody class="measureRoot">{}</tbody></table>'.format(
        ''.join([tr_t.format(OPTIONS[o], v) for o, v in enumerate(options)]))
    return option
def center_image(html_string):
    imgs = get_html_element('<img', html_string, only_tag=True, flags=re.I)
    for img in imgs:
        try:
            src = re.search(r"""src\s*=\s*["'][^"'<>]+?["']""", img, flags=re.I).group()
        except Exception:
            continue

        w = ''
        mod = re.search(r'\W(width\s*(:|=)\s*[^<>]+?)(;|\s|/|>)', img, flags=re.I)
        if mod:
            w = mod.group(1)
            w = re.sub(r'\s*:\s*', '=', w, 1)
            if '"' not in w and '\'' not in w:
                w = w.replace('=', '="', 1) + '"'

        h = ''
        mod = re.search(r'\W(height\s*(:|=)\s*[^<>]+?)(;|\s|/|>)', img, flags=re.I)
        if mod:
            h = mod.group(1)
            h = re.sub(r'\s*:\s*', '=', h, 1)
            if '"' not in h and '\'' not in h:
                h = h.replace('=', '="', 1) + '"'

        style = ' '.join((src, w, h)).strip()
        new_img = '<img %s style="vertical-align: middle;">' % style
        html_string = html_string.replace(img, new_img)

    return html_string

def get_multi_answers(html_string):
    # chucks = get_html_element((
    #     dict(e='<div class="result"', with_tag=False),
    #     dict(e='<table>', with_tag=False, limit=1),
    #     dict(e='<td ', with_tag=False),
    # ), html_string)
    soup = BeautifulSoup(html_string,'html.parser')
    result_div = soup.find_all(name='div',attrs={'class':'result'})
    sub_quss = []
    for item in result_div:
        trs = item.find_all(name='tr')
        tds = []
        for tr in trs:
            sub_tds = tr.find_all(name='td')
            for item in sub_tds:
                content = get_html_element('<td ',str(item),with_tag=False)
                tds.extend(content)
        sub_quss.append(tds)

    #答案
    # anss = chucks[1:len(chucks):10]
    # anss = [chucks[i+1] for i in [i for i,x in enumerate(chucks) if x == "【答\xa0\xa0\xa0案】"]]
    #分析
    # fenxis = chucks[3:len(chucks):10]
    # fenxis = [chucks[i+1] for i in [i for i,x in enumerate(chucks) if x == "【解\xa0\xa0\xa0析】"]]
    #知识点
    # kps = [chucks[i+1] for i in [i for i,x in enumerate(chucks) if x == "【知识点】"]]
    kps = []
    #难易度
    nanyidu = []
    # nanyidu = [chucks[i+1] for i in [i for i,x in enumerate(chucks) if x == "【难易度】"]]
    answer_all_html = ''
    i = 1
    for sub_qus in sub_quss:
        try:
            ans = sub_qus[1+sub_qus.index('【答\xa0\xa0\xa0案】')]
        except:
            ans = ''
        try:
            fenxi = sub_qus[1+sub_qus.index('【解\xa0\xa0\xa0析】')]
        except:
            fenxi = ''
        try:
            kp = sub_qus[1+sub_qus.index('【知识点】')]
            kps.append(kp)
        except:
            kp = ''
        if sub_qus[1+sub_qus.index('【难易度】')]:
            nanyidu.append(sub_qus[1+sub_qus.index('【难易度】')])
        answer_all_html += '<p>{}. {}<br>{}</p>'.format(
            i, ans.strip().lstrip('<p>').rstrip('</p>'),
            '解析: {}{}'.format(
                fenxi.strip().lstrip('<p>').rstrip('</p>'),
                ('<br>知识点：{}'.format(kp.strip()), '')[kp.strip() == '']))
        i += 1
    sum = 0
    for i in nanyidu:
        sum += DIFF[i.strip()]
    return answer_all_html, '',';'.join(kps),round(sum/len(nanyidu))

def get_answers(html_string):
    chucks = get_html_element((
        dict(e='<div class="result"', with_tag=False),
        dict(e='<table>', with_tag=False, limit=1),
        dict(e='<td ', with_tag=False),
    ), html_string)

    try:
        ans = chucks[chucks.index('【答\xa0\xa0\xa0案】')+1]
    except:
        ans = ''
    try:
        fenxi = chucks[chucks.index('【解\xa0\xa0\xa0析】')+1]
    except:
        fenxi = ''
    try:
        kps = chucks[chucks.index('【知识点】')+1]
    except:
        kps = ''
    try:
        nanyidu = chucks[chucks.index('【难易度】')+1]
        nandu = DIFF[nanyidu.strip()]
    except:
        nandu = 0

    return ans.strip(), fenxi.strip(),kps,nandu

if __name__=='__main__':
    main()

# -*- coding: utf-8 -*-

import re

from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.html.beautify_html import center_image, remove_tag
from afanti_tiku_lib.html.extract import get_html_element


OPTIONS = dict((k, v) for k, v in enumerate('abcdefghijklmnopqrstuvwxyz'))
DIFF = {
'基础题': 30,
'中档题': 60,
'较难题': 90,
}


class Taoke91QuestionParser(object):

    def __init__(self, archive_image=False, download=False):
        self.html_magic = HtmlMagic(25, archive_image=archive_image,
                                    download=download, beautify=False)

    def parse(self, url, html_string, info, aft_subj_id):

        cols = dict()

        # 检测是否是多题 (如：完形填空)
        is_mqs = is_multi_qs(html_string)

        if is_mqs:
            question_html, option_html = get_multi_question(html_string)
        else:
            question_html, option_html = get_question(html_string)

        question_html = self.html_magic.bewitch(question_html, spider_url=url)
        # question_html = fix_any(question_html)
        cols['question_html'] = center_image(question_html)

        if option_html:
            option_html = self.html_magic.bewitch(option_html, spider_url=url)
            # option_html = fix_any(option_html)
            option_html = center_image(option_html)
        cols['option_html'] = option_html

        ################################################################

        if is_mqs:
            answer_all_html, jieda = get_multi_answers(html_string)
        else:
            answer_all_html, jieda = get_answers(html_string)

        answer_all_html = self.html_magic.bewitch(answer_all_html,
                                                  spider_url=url)
        # answer_all_html = fix_any(answer_all_html)
        cols['answer_all_html'] = center_image(answer_all_html)

        jieda = self.html_magic.bewitch(jieda, spider_url=url)
        # jieda = fix_any(jieda)
        cols['jieda'] = center_image(jieda)

        ################################################################

        difficulty = get_difficulty(html_string)
        cols['difficulty'] = difficulty

        ################################################################

        kp = get_kp(html_string)
        cols['knowledge_point'] = kp

        ################################################################

        cols['version'] = 0
        cols['version_name'] = info['version_name']

        ################################################################

        cols['fenxi'] = ''
        cols['exam_year'] = 0
        cols['exam_city'] = ''
        cols['spider_url'] = url
        cols['subject'] = aft_subj_id
        cols['zhuanti'] = ''
        cols['dianping'] = ''
        cols['spider_source'] = 57
        cols['question_type'] = 0
        cols['question_quality'] = 0

        return cols


def is_multi_qs(html_string):
    n = 0
    index = 0
    while True:
        if n > 1:
            return True

        index = html_string.find('<span>编号：', index)

        if index == -1 and n < 2:
            return False

        index += 7
        n += 1


def get_question(html_string):
    qs = get_html_element('div class="questInfo">\s+<a ', html_string,
                          regex=True, with_tag=False, limit=1)[0]

    options = get_html_element('<ol>', qs, with_tag=False)
    if len(options) == 1:
        opts = get_html_element('<li>', options[0], with_tag=False)
        option_html = make_option(opts)
    else:
        option_html = ''

    if option_html:
        qs = remove_tag('<ol>', qs, all=True)

    return qs.strip().lstrip('<p>').rstrip('</p>'), option_html.strip()


def get_multi_question(html_string):
    chucks = get_html_element('<div class="questInfoBox clearfix"',
                              html_string, with_tag=False)
    qs_body = get_html_element('<div class="questInfo xhr_questInfo"',
                               chucks[0], with_tag=False, limit=1)[0]

    sub_qss = [get_question(chuck) for chuck in chucks[1:]]
    for sub_qs in sub_qss:
        qs_body += '<p>{}</p>'.format(''.join(sub_qs))

    return qs_body.strip(), ''


def get_answers(html_string):
    chucks = get_html_element((
        dict(e='<div class="result"', with_tag=False),
        dict(e='<table>', with_tag=False, limit=1),
        dict(e='<td ', with_tag=False),
    ), html_string)

    ans = chucks[1]
    fenxi = chucks[3]

    return ans.strip(), fenxi.strip()


def get_multi_answers(html_string):
    chucks = get_html_element((
        dict(e='<div class="result"', with_tag=False),
        dict(e='<table>', with_tag=False, limit=1),
        dict(e='<td ', with_tag=False),
    ), html_string)

    anss = chucks[1:len(chucks):4]
    fenxis = chucks[3:len(chucks):4]
    kps = re.findall(r'<span>知识点：(.*?)</span>', html_string)

    answer_all_html = ''
    for i, (ans, fx, kp) in enumerate(zip(anss, fenxis, kps), 1):
        answer_all_html += '<p>({}). {}<br>{}</p>'.format(
            i, ans.strip().lstrip('<p>').rstrip('</p>'),
            '解析: {}{}'.format(
                fx.strip().lstrip('<p>').rstrip('</p>'),
                ('<br>知识点：{}'.format(kp.strip()), '')[kp.strip() == '']))

    return answer_all_html, ''


def get_difficulty(html_string):
    mod = re.search(r'<span>难易度：(.+?)</span>', html_string)
    if not mod:
        return 0

    return DIFF.get(mod.group(1), 0)


def get_kp(html_string):
    kps = re.findall(r'<span>知识点：(.*?)</span>', html_string)
    if not kps:
        return ''

    kps = [kp for kp in set(kps) if kp]

    kp = ''
    while True:
        kp = ';'.join(kps)
        if len(kp.encode('utf8')) > 512:
            kps.pop()
        else:
            return kp


def make_option(options):
    tr_t = '<tr><td class="aft_option" data="{}">{}</td></tr>'
    option = '<table class="aft_option_wrapper" style="width: 100%;"><tbody class="measureRoot">{}</tbody></table>'.format(
        ''.join([tr_t.format(OPTIONS[o], v.lstrip('<p>').rstrip('</p>')) for o, v in enumerate(options)]))
    return option


def fix_any(html_string):
    return html_string
from gevent import monkey; monkey.patch_socket()
from bs4 import BeautifulSoup
import gevent
import MySQLdb.cursors
import requests
import hashlib

connect_db_offline = MySQLdb.connect(
    host='172.16.3.17',
    db="question_db_offline",
    user='user_name',
    passwd='password',
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,)
offline_cursor = connect_db_offline.cursor()

connect = MySQLdb.connect(
    host='172.16.3.17',
    db="html_archive",
    user='user_name',
    passwd='password',
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,)

offline_cursor = connect_db_offline.cursor()
cursor = connect.cursor()
def download_img(spider_source, spider_url, image_url, image_url_md5, using_proxy=True, headers=""):
    url = "http://172.16.0.100:9000/apis/v1/image/collection/"
    data = dict(
        spider_source = spider_source,
        image_url = image_url,
        image_url_md5 = image_url_md5,
        spider_url = spider_url,
        headers = headers,
        proxy = True if using_proxy else None,
    )
    # print(data)

    r = requests.post(url, data=data)
    if r.status_code==200:
        # print(r.json())
        return True
    else:
        return False

def parse_pic(para_list):
    select_sql = 'select spider_url from common_question_20181211 where question_id >= %d and question_id < %d'\
                        % (para_list['min_id'], para_list['max_id'])
    offline_cursor.execute(select_sql)
    results = offline_cursor.fetchall()
    for result in results:
        spider_id = result['spider_url'].split('_')[-1]
        spider_url = '91taoke_qs_{}'.format(spider_id)
        select_sql = "select `html`,`key` from 91taoke_spider_html_archive_table_copy1 where `key` = '%s' "%(spider_url)
        cursor.execute(select_sql)
        res_qus = cursor.fetchone()

        soup = BeautifulSoup(res_qus['html'], 'lxml')
        imgs = soup.find_all(name='img')
        for img in imgs:
            img_url = img.get('src')
            if 'http' not in img_url:
                img_url = 'http://91taoke.com{}'.format(img_url)
            image_url_md5 = hashlib.md5(img_url.encode('utf8')).hexdigest()
            ret = download_img(25, result['spider_url'], img_url, image_url_md5)
            if not ret:
                print("download error")
    print(para_list)
if __name__ == '__main__':
    # test()

    m_id = 6229437
        #6229437
    step = 10000
    # 15049730
    for j in range(38,63):
        process_lst = []
        for i in range(j*100000,100000*(j+1),step):
            min_id = i
            max_id = i + step
            para_list = {
                'min_id':min_id,
                'max_id':max_id,
            }
            process_lst.append(gevent.spawn(parse_pic,para_list))
        gevent.joinall(process_lst)
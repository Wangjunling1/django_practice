# Python3.5
# -*- coding: utf-8 -*-
import hashlib
import re
import json
import urllib
import string
import traceback
import pymysql
import html.parser
from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.utils.get_pure_text import get_pure_text as gpt
from afanti_tiku_lib.dbs.mysql_pool import CommonMysql
from afanti_tiku_lib.dbs.sql import select_sql
from afanti_tiku_lib.dbs.execute import execute

OPTION_DICT = {i: k for i, k in enumerate(string.ascii_uppercase)}

# mysql = CommonMysql('html_archive')
# mysql_conn = mysql.connection()
client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  # 使用自己的用户名
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8',
            cursorclass=pymysql.cursors.DictCursor,
        )
db_cur = client.cursor()
class DaoXueHaoQuestionParser(object):
    def __init__(self, archive_image=False, download=False):
        # self.html_magic = HtmlMagic(58, archive_image=True, download=True, beautify=False)
        self.html_magic = HtmlMagic(58, archive_image=False, download=False, beautify=False)
        self.html_string = ''
        self.qs_string = ''
        self.info_string = ''
        self.subj_id = 0
        self.url = ''
        self.grade_id = 0
        self.book_name = ''

    def get_chuck(self, elem):
        return None

    def init(self, html_string, url, subj_id, paper_url=''):
        html_string = json.loads(html_string,strict=False)

        book_name = html_string['bookmarkId']
        book_id = html_string['bookmarkId']
        grade = html_string['grade']
        sids = html_string['sids']
        qs_string = html_string['source']
        subject = html_string['subject']
        status = html_string['status']

        self.html_string = html_string
        self.qs_string = qs_string
        self.info_string = ''
        self.subj_id = int(subject)
        self.sid = int(sids)
        self.grade_id = int(grade)
        self.book_name = book_name

        self.book_id = book_id
        self.status = status

    def find_imgstring(self,html_string):
        # data:image/png;b
        pattern = re.compile(r'<img.*?src="(data:image/[a-zA-Z0-9]{1,5};base64,(.*?))"', re.S)
        items = re.findall(pattern, html_string)
        for item in items:
            yield item[0],item[1]

    def calc_md5(self,imgstring):
        return hashlib.md5(imgstring.encode('utf-8')).hexdigest()

    def pre_deal_image(self, html_string):
        def deal_latex(html_string):
            pattern = re.compile(r"""(<img.*?["']{1}(http://gallery.fbcontent.cn.*?latex=.*?)["']{1}.*?>)""",  re.I | re.S | re.DOTALL)  
            results = pattern.findall(html_string)
            for result in results:
                repl = result[0]
                result = re.search(r'\$\$(.*?)\$\$',urllib.parse.unquote(result[1]))
                if result:
                    html_string = html_string.replace(repl, '''<span class="afanti-latex">\( {} \)</span>'''.format(result.group(1)))
        
            return html_string
            
        def _sub_replace(matched):
            url_base = 'http://dxhquestimgs.daoxuehao.com/' 
            
            img_h5 = matched.group('img_h5')
            pattern = re.compile(r"""<img.*?src=["']{1}(.*?)["']{1}.*?>""",  re.I | re.S | re.DOTALL)    
            result = re.search(pattern, img_h5)
            img_url = result.group(1)
            if img_url.startswith('http'):
                if 'latex=' in img_url:
                    img_h5 = deal_latex(img_h5)
            elif img_url.startswith('file') or img_url.startswith('about') or img_url.startswith('pictures') or img_url.startswith('data'):
                pass
            else:
                new_img_url = url_base + img_url.lstrip('/')
                img_h5 = img_h5.replace(img_url, new_img_url)
            
            return img_h5

        pattern = re.compile(r"""(?P<img_h5><img.*?src=["']{1}.*?["']{1}.*?>)""", re.I | re.S | re.DOTALL)
        return re.sub(pattern, _sub_replace, html_string)

    # 剔除问题中的首张图片，首张图片是题目的图片版本
    def remove_first_img(self, question_html):
        pattern =re.compile(r'(.*?)(<img.*?/>).*?page-break-after', flags=re.I|re.S|re.DOTALL)
        r=pattern.search(question_html)
        if r is not None and gpt(r.group(1),parser='htmlparser').strip() == '':
            #print(r.group(2))
            return re.sub(re.escape(r.group(2)),'',question_html)
        else:
            return question_html

    def save_base64_to_png(self,html_string):
        import base64
        for replace_str, imgstring in self.find_imgstring(html_string):

            if imgstring=='undefined':
                continue
            missing_padding = 4 - len(imgstring) % 4
            if missing_padding:
                imgstring_padding = imgstring
                imgstring_padding += '=' * missing_padding
                imgdata = base64.b64decode(imgstring_padding)
            else:
                imgdata = base64.b64decode(imgstring)

            md5 = self.calc_md5(replace_str)
            with open('image/%s.png' % md5, 'wb') as f:
#                print('image/%s.png' % md5)
                f.write(imgdata)

#            print replace_str
#            print '-'*100
#            print md5
#            html_string = html_string.replace(replace_str, md5)
#            http://dxhquestimgs.daoxuehao.com/questImg/Attachments/lftimgs/b2/e0/51/82/d51fda27.png
#        return html_string.replace('/questImg/','http://dxhquestimgs.daoxuehao.com/questImg/').replace('/Attachments/','http://dxhquestimgs.daoxuehao.com/Attachments/')


    def parse(self, html_string, url, subj_id=0, paper_url=''):
        self.init(html_string, url, subj_id, paper_url='')
        cols = dict()

        question_html, exam_year, exam_city = self.get_question_html()
        try:
            question_html = self.remove_first_img(question_html)
            cols['question_html'] = self.pre_deal_image(question_html)
            #print(cols['question_html'])
        except Exception as e:
            print(traceback.print_exc())
            print('error: %s'%str(e))

        if exam_year:
            cols['exam_year'] = exam_year
            cols['exam_city'] = exam_city
        else:
            cols['exam_year'] = 0
            cols['exam_city'] = ''

        option_html, ans = self.get_option_html()
        cols['option_html'] = self.pre_deal_image(option_html)
        cols['answer_all_html'] = self.pre_deal_image(ans)

        fenxi = self.get_fenxi()
        cols['fenxi'] = self.pre_deal_image(fenxi)

        jieda = self.get_jieda()
        cols['jieda'] = self.pre_deal_image(jieda)

        dianping = self.get_dianping()
        cols['dianping'] = self.pre_deal_image(dianping)

        zhuanti = self.get_zhuanti()
        cols['zhuanti'] = zhuanti


#        paper_url_t = self.get_paper()
#        cols['paper_url'] = (paper_url_t or paper_url)

        int_df, str_df = self.get_difficulty()
        cols['difficulty'] = int_df

        kps = self.get_knowledge_point()
        cols['knowledge_point'] = kps

        cols['sid'] = self.sid
        cols['subject'] = self.subj_id
        cols['spider_source'] = 58
        cols['question_type'] = 0
        cols['question_quality'] = 0
        cols['spider_url'] = url

        # 多出来的字段
        cols['grade'] = self.grade_id
        cols['book_id'] = self.book_id
        cols['book_name'] = self.book_name
        cols['str_difficulty'] = str_df
        cols['relate_qs_url1'], cols['relate_qs_url2'] = self.get_relate_qs_url()

    #   下载图片
    #    '''
        try:
            cols['question_html'] = self.html_magic.bewitch(cols['question_html'],url)
        except Exception as e:
            print(traceback.print_exc())

        cols['option_html'] = self.html_magic.bewitch(cols['option_html'],url)
        cols['answer_all_html'] = self.html_magic.bewitch(cols['answer_all_html'],url)
        cols['fenxi'] = self.html_magic.bewitch(cols['fenxi'],url)
        cols['jieda'] = self.html_magic.bewitch(cols['jieda'],url)
        cols['dianping'] = self.html_magic.bewitch(cols['dianping'],url)
    #   '''
        self.save_base64_to_png(question_html)
        self.save_base64_to_png(option_html)
        self.save_base64_to_png(ans)
        self.save_base64_to_png(fenxi)
        self.save_base64_to_png(jieda)
        self.save_base64_to_png(dianping)

        cols['status'] = self.status
        return cols

    def get_relate_qs_url(self):
        url_list = []
        for practice in self.qs_string['practice']:
            url_list.append(int(practice['sid']))
        if len(url_list) == 2:
            relate_qs_url1 = url_list[0]
            relate_qs_url2 = url_list[1]
        elif len(url_list) == 1:
            relate_qs_url1 = url_list[0]
            relate_qs_url2 = 0
        elif len(url_list) == 0:
            relate_qs_url1 = 0
            relate_qs_url2 = 0
        else:
            relate_qs_url1 = -1
            relate_qs_url2 = -1

        return relate_qs_url1, relate_qs_url2

    def get_knowledge_point(self):
        list_kp = []
        for k in self.qs_string["knowledges"]:
            list_kp.append(k['name'])
        kps = ';'.join(list_kp)
        return kps

    def get_question_html(self):
        chuck = self.qs_string['question']
        chuck = re.sub(r'(\\t|\\n)', r' ', chuck)
        chuck = re.sub(r'<u>(&nbsp).*?</u>', r'<u> </u>', chuck).replace('&nbsp;', ' ')
        exam_year = ''
        exam_city = ''
        return chuck, exam_year, exam_city

    def get_option_html(self):
        option_html = ''
        answer_all_html = self.qs_string['answer']
        answer_all_html = re.sub(r'(\\t|\\n)', r' ', answer_all_html)
        answer_all_html = re.sub(r'<u>(&nbsp;).*?</u>', r'<u> </u>', answer_all_html)
        answer_all_html = answer_all_html.replace('&nbsp;', ' ')
        return option_html, answer_all_html

    def get_fenxi(self):
        chuck = self.qs_string['hint'].replace('\n', '')
        chuck = re.sub(r'(\\t|\\n)', r' ', chuck)
        chuck = re.sub(r'<u>(&nbsp;).*?</u>', r'<u> </u>', chuck).replace('&nbsp;', ' ')
        return chuck

    def get_jieda(self):
        chuck = self.qs_string['think']
        chuck = re.sub(r'(\\t|\\n)', r' ', chuck)
        chuck = re.sub(r'<u>(&nbsp;).*?</u>', r'<u> </u>', chuck).replace('&nbsp;', ' ')
        return chuck

    def get_dianping(self):
        return ''

    def get_zhenti(self):
        return ''

    def get_difficulty(self):
        str_df = self.qs_string['diff']
        int_df = 0
        return int_df, str_df

    def get_zhuanti(self):
        return ''

    def get_paper(self):
        pass

    def get_exam_info(self):
        pass

def get_mysql_connection():
    global mysql
    global mysql_conn
    try:
        if mysql_conn.ping() is False:
            mysql_conn = mysql.connection()
        return mysql_conn
    except Exception:
        mysql_conn = mysql.connection()
        return mysql_conn


if __name__ == '__main__':
    # mysql_conn = get_mysql_connection()
    # sql = select_sql('daoxuehao_spider_html_archive_table_20181226',('key','html'),condition='where key = daoxuehao_qs_00004038')
    # rows = execute(mysql_conn,sql)
    # print(len(rows))

    test = DaoXueHaoQuestionParser()
    select_sql = "select * from daoxuehao_spider_html_archive_table_20181226 limit 20,10"
    db_cur.execute(select_sql)
    result = db_cur.fetchone()
    while result:
        test = DaoXueHaoQuestionParser()
        cols = test.parse(result['html'],result['key'])
        print(json.dumps(cols,ensure_ascii=False))
        result = db_cur.fetchone()





#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 13 13:53:47 2018

@author: xiaopeng
"""

import requests
from util import make_mac_addr,get_signature

host = "https://dxhslb.daoxuehao.com/"
url = host + "/LFT-GuidanceLearn/bookcontent/v2.0/getPageTopicList?id=66391&pageLabel=&pageNum=7"
login_url = host + "LFT-GuidanceLearn/user/v2.0/grantLogin?token=18810133730&uid=&source=phone&nickName=18810133730&macAddress={}&version=v3.2"

def test():
    # openQuestion?dxh =
    url = 'https://dxhslb.daoxuehao.com/LFT-GuidanceLearn/quest/v2.0/openQuestion?dxh=S1676755'
    link = url.split('?')[1].replace('=', '').replace('&', '')
    # link = 'userIdb7hMYDUs0uQhbhmq2eLQ7A==dxhS2659798'
    print(link)
    headers = {
        'token': 'a702635b57cdc3d97003d83734c76508',
        'openId': get_signature(link, '6c25cd9ff3c6582855589bd90d5a6c38'),
        'signature': '7a520c711901573ef8418980c7e2477c',
        # get_signature('10010001','6c25cd9ff3c6582855589bd90d5a6c38')
        'call-type': 'android',
        'Connection': 'Keep-Alive',
        'User-Agent': 'DXH/2.0.1 (com.52lft.DXH; build:82; iOS 12.0.1) Alamofire/4.7.3',
    }
    print(headers)
    print(get_signature(link, 'a702635b57cdc3d97003d83734c76508'))
    result = requests.get(url, headers=headers)
    print(result.text)

test()

from afanti_tiku_lib.utils import md5_string

MAGIC_STR = 'fa084ed7b02b52e6cd8b49edeb82f7f6'

def get_signature(link, token):
    s = link + get_enc_token(token) + MAGIC_STR
    r = md5_string(s)
    return r


def get_enc_token(token):
    res = ''
    n = sum([int(i, 16) for i in [token[i * 4:i * 4 + 4] for i in range(len(token) // 4)]])
    s = str(n)

    for i in range(len(s)):
        p = ord(s[i]) - 48  # ord(s[i]) - ord('0')
        q = token[p]
        res += q

    return res


def make_mac_addr(pnum):
    md5 = md5_string(pnum + '#i got you#')
    return ':'.join([md5[i * 2: i * 2 + 2] for i in range(6)])
import requests
import logging

from util import make_mac_addr
from collections import deque
from afanti_tiku_lib.utils import md5_string


LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                    filename='working/runtime_error.log', filemode='a')

logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)
# 创建一个handler，用于写入日志文件
fh = logging.FileHandler('daoxuehao.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

USER_FILE = 'working/qq_ids'
login_url = 'https://dxhslb.daoxuehao.com/LFT-GuidanceLearn/user/v2.0/grantLogin?' \
            'token={0}&uid=&source=QQ&nickName={1}&' \
            'macAddress={2}&version=v3.3'
MAX_PHONE_SIZE = 100
user_names = deque()
for i, name in enumerate(open(USER_FILE)):
    if i > MAX_PHONE_SIZE:
        break
    name = name.strip()
    if name.strip():
        user_names.append(name)

BASIC_HEADERS = {
    'versionName': '6.2.1',
    'Accept-Encoding': 'gzip',
    'call-type': 'android',
    'user-agent': 'okhttp/3.8.0',
    'Connection': 'Keep-Alive',
}

def get_one_user():
    #得到一个qq_id，并将该id放到列表尾部
    user_name = user_names.popleft()
    user_names.append(user_name)
    print(user_names)
    return user_name

def login(user):
    headers = {
        'token': '',
        'openId': '',
        'signature': '',
    }
    headers.update(BASIC_HEADERS)
    mac_addr = make_mac_addr(user)
    token = md5_string(user + 'qq_dxh')

    url = login_url.format(token, user, mac_addr)
    print(url)
    login_result = requests.get(login_url)
    back_json = login_result.json()
    try:
        openid = back_json['openId']
        token = back_json['token']
        logger.info('relogin:[{},{},{}]'.format(user, openid, token))
    except Exception as e:
        logger.error('error:{}'.format(e))
        print('登录失败')

    return openid, token



import requests
import pymysql
import logging
import uvloop
import hashlib
import json
import base64
import asyncio
import aiohttp
import async_timeout
from login import login, get_one_user, logger
from util import get_signature
from aiohttp.client_exceptions import ClientHttpProxyError


LOGGING_FORMAT = '%(asctime)-15s:%(levelname)s: %(message)s'
logging.basicConfig(format=LOGGING_FORMAT, level=logging.INFO,
                    filename='working/runtime_error.log', filemode='a')



#代理
proxies = {
    'http':'http://H5Q6816ED0T3417D:764AE77AE14D5C27@http-dyn.abuyun.com:9020',
    'https':'http://H5Q6816ED0T3417D:764AE77AE14D5C27@http-dyn.abuyun.com:9020'
}
url = 'https://dxhslb.daoxuehao.com/LFT-GuidanceLearn/quest/v2.0/openQuestion?dxh={}'
base_headers = {
    'call-type': 'android',
    'Accept-Encoding': 'gzip',
    'Connection': 'Keep-Alive',
    'user-agent': 'okhttp/3.5.0',
    }
fail_file = 'working/fail_list'
#最大并发量
MAX_REQ_SIZE = 1000
class DaoxuehaoSpider():
    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  # 使用自己的用户名
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'
        )
        self.db_cur = self.client.cursor()
        self.openid, self.token = login(get_one_user())
        print(self.openid, self.token)
        self.fail_list = []
    def get_books(self,bid=0):
        headers = {
            'token': self.token,
            'openid': self.openid,
            'signature': get_signature('dxh00931780', self.token),
        }
        headers.update(base_headers)
        is_login = requests.get(url.format('00931780'),headers=headers,proxies=proxies)
        if is_login.json()['success'] == False:
            print('进行重新登录')
            print(is_login.json())

            self.openid,self.token = login(get_one_user())
        bid = str(bid).zfill(4)

        for m in range(0, 5000, MAX_REQ_SIZE):
            loop = uvloop.new_event_loop()
            asyncio.set_event_loop(loop)
            session = aiohttp.ClientSession(loop=loop)
            tasks = []
            for qid in range(m, m + MAX_REQ_SIZE):
                qid = str(qid).zfill(4)
                item_id = bid + qid
                tbid = 'dxh{}'.format(item_id)
                # print(signature)
                if self.is_archived(item_id):
                    logger.info('is_archived:{}'.format(item_id))
                    continue
                tasks.append(self.get_questions(session, tbid))
            loop.run_until_complete(asyncio.gather(*tasks))
            loop.close()

    async def get_questions(self, session, tbid):
        item = {}
        signature = get_signature(tbid, self.token)
        headers = {
            'token': self.token,
            'openid': self.openid,
            'signature': signature,
        }
        headers.update(base_headers)
        qid = tbid.replace('dxh', '')
        try:
            with async_timeout.timeout(10):
                async with session.get(url.format(qid),
                                       headers=headers,proxy = proxies['http']) as resp:
                    json_text = await resp.text()
                    if json.loads(json_text)['message'] == '没找对应的题目信息':
                        logger.info('has no question:{}'.format(qid))
                    elif json.loads(json_text)['success'] == False:
                        logger.info('success false:{}'.format(json_text))
                        return
                    item['html'] = json_text
                    item['source'] = 58
                    item['subject'] = 0
                    m2 = hashlib.md5()
                    m2.update(json_text.encode('utf8'))
                    item['md5'] = m2.hexdigest()
                    item['key'] = "daoxuehao_qs_{}".format(qid)
                    info = {"qid":qid}
                    item['info'] = info
                    request_info = {
                        "info":info,
                        "max_retry":0,
                        "timeout":10,
                        "method":"GET",
                        "params":None,
                        "data":None,
                        "headers":headers,
                        "cookies":None,
                        "url":url.format(qid),
                        "proxy":proxies['http'],
                    }
                    item['request_info'] = request_info
                    # print(item)
                    try:
                        logger.info('add success:{}'.format(item['key']))
                    except Exception as e:
                        logger.error('insert error:{}'.format(str(e)))
        except ClientHttpProxyError as e:
            await self.get_questions(session, tbid)
        except Exception as e:
            self.fail_list.append(tbid)
            logger.error('add failed id:{},{}'.format(tbid,str(e)))
            return

    async def get_questions1(self, session, tbid):
        item = {}
        signature = get_signature(tbid, self.token)
        headers = {
            'token': self.token,
            'openid': self.openid,
            'signature': signature,
        }
        headers.update(base_headers)
        qid = tbid.replace('dxh', '')
        next_qids = []
        try:
            with async_timeout.timeout(200):
                async with session.get(url.format(qid),
                                       headers=headers,proxy = proxies['http']) as resp:
                    json_text = await resp.text()
                    if json.loads(json_text)['message'] == '没找对应的题目信息':
                        print('没有找到',qid)
                    if json.loads(json_text)['errorcode'] == 0:
                        # print('有题目',qid)
                        item['html'] = json_text
                        item['source'] = 58
                        item['subject'] = 0
                        m2 = hashlib.md5()
                        m2.update(json_text.encode('utf8'))
                        item['md5'] = m2.hexdigest()
                        item['key'] = "daoxuehao_qs_{}".format(qid)
                        info = {"qid":qid}
                        item['info'] = info
                        request_info = {
                            "info":info,
                            "max_retry":0,
                            "timeout":10,
                            "method":"GET",
                            "params":None,
                            "data":None,
                            "headers":headers,
                            "cookies":None,
                            "url":url.format(qid),
                            "proxy":proxies['http'],
                        }
                        item['request_info'] = request_info
                        # try:
                        #     self.save_item(item)
                        #     logger.info('add success:{}'.format(item['key']))
                        # except Exception as e:
                        #     logger.error('insert error:{}'.format(str(e)))
                        # print('lstrip',qid.lstrip('0'))
                        if int(str(int(qid.lstrip('0')))[:-2]) == int(str(int(qid.lstrip('0'))+1)[:-2]):
                            next_qid = '{:0>8}'.format(int(qid.lstrip('0'))+1)
                            if int(next_qid) == int(str(int(next_qid))[:-2])*100+99:
                                await self.get_questions1(session, 'dxh{}'.format(next_qid))
                                return
                            next_qids.append(next_qid)
                    print(qid)
                    for next_qid in next_qids:
                        if self.is_archived(next_qid):
                            logger.info('is_archived:{}'.format(next_qid))
                            continue
                        await self.get_questions1(session, 'dxh{}'.format(next_qid))

        except ClientHttpProxyError as e:
            await self.get_questions1(session, tbid)
        except Exception as e:
            await self.get_questions1(session, tbid)
            # self.fail_list.append(tbid)
            logger.error('retry id:{},{}'.format(tbid,str(e)))

    def is_archived(self,item_id):
        key = 'daoxuehao_qs_{}'.format(item_id)
        select_sql = "select `key` from daoxuehao_spider_html_archive_table where `key` = '%s'"%(key)
        self.db_cur.execute(select_sql)
        result = self.db_cur.fetchone()
        if result:
            return True
        return False

    def save_item(self, item):
        # replace('\'', '\'\'').replace('"', '\\"')
        insert_sql = '''
                      insert into daoxuehao_spider_html_archive_table_20181226
                      (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`flag`,`flag_str`)
                      VALUES (%d,%d,'%s','%s','%s','%s','%s',%d,'%s')
                     '''%(item['source'],item['subject'],item['html'].replace('\'', '\'\'').replace('"', '\\"'),item['md5'],item['key'],
                          json.dumps(item['request_info'],ensure_ascii=False),json.dumps(item['info'],ensure_ascii=False),0,"")
        self.db_cur.execute(insert_sql)
        self.client.commit()


    def get_books1(self):
        loop = uvloop.new_event_loop()
        asyncio.set_event_loop(loop)
        session = aiohttp.ClientSession(loop=loop)
        tasks = []
        for i in range(180,181):
            qid = '{:0>6}'.format(i) + '00'
            tbid = 'dxh{}'.format(qid)
            tasks.append(self.get_questions1(session, tbid))
        loop.run_until_complete(asyncio.gather(*tasks))
        loop.close()

    def main(self):
        self.get_books()

if __name__ == '__main__':
    test = DaoxuehaoSpider()
    test.main()
    print(test.fail_list)
    # fail_file = open('working/fail_list', 'w+')
    # fail_file.write(str(test.fail_list))
# -*- coding: utf-8 -*-
from anoah.items import AnoahItem
import scrapy
import json
import datetime
import hashlib
import time
import re


class AnoahSpider(scrapy.Spider):
    name = 'ANOAH'
    html_id = 0

    def start_requests(self):
        questions = AnoahItem()
        # 最后一页题目书在question:2469108
        for i in range(0, 246):
            url = url = "http://www.anoah.com/api_cache/?q=json/Qti/get&info={%22param%22:{%22qid%22:%22question:"+str(
                i)+"%22,%22dataType%22:1}}"
            yield scrapy.Request(url=url, callback=self.parse)


    def parse(self, response):
        # sleep防止抓取速度过快
        # time.sleep(0.1)
        questions = AnoahItem()
        jsDict = json.loads(response.text)
        if len(jsDict) != 0:

            self.html_id += 1
            questions['key'] = str(response)[5:-1]
            questions['html_id'] = int(self.html_id)
            questions['source'] = 75
            questions['subject'] = 0
            questions['source_id'] = re.findall(
                r'.*?question:(.*?)%.*?', str(response))[0]
            questions['html'] = response.text
            m2 = hashlib.md5()
            m2.update(response.text.encode('utf-8'))
            questions['md5'] = m2.hexdigest()
            questions['question_type'] = int(jsDict['qtypeId'])
            questions['record_time'] = datetime.datetime.now().strftime(
                '%Y-%m-%d %H:%M:%S')
            questions['request_info'] = str(
                {'GET ': '/1/ HTTP/1.1', 'Host': 'www.anoah.com'})
            questions['qtype'] = 0
            questions['info'] = ''
            questions['flag_str'] = ''

            if int(str(response)[1:4]) != 200:
                questions['flag'] = 1
            else:
                questions['flag'] = None

            print('-'*50)
            print("完成第%d条数据摘取" % self.html_id)
            yield questions



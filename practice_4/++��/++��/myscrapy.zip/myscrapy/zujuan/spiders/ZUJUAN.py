# -*- coding: utf-8 -*-
from .common import DATA
from zujuan.items import ZujuanItem
import scrapy
import copy
import re
import logging
import hashlib
import datetime
import copy

logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)


class ZujuanSpider(scrapy.Spider):
    name = 'ZUJUAN'
    #allowed_domains = ['zujuan.com']
    #start_urls = ['http://zujuan.com/']
    #basic_url = "http://zujuan.xkw.com/xxyw/zj"

    def __init__(self):
        fh = logging.FileHandler('zujuancz.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    @staticmethod
    def EscapeString(string):
        string = string.replace('\'','\\\'').replace('\"','\\\"')
        return string

    def start_requests(self):
        for item in DATA:
            for hm in item['html']:
                for num in range(hm[0], hm[1]):
                    yield scrapy.Request(item['url']+str(num)+'/o0', callback = self.parse, meta = {'subject':item['title']})
    
    def parse(self, response):

        meta = copy.copy(response.meta)
        page_info = response.xpath("//div[@id='pagelistbox']/div/span/text()").extract_first()
        #print(page_info)
        page = int(re.findall(r'共(.*?)页', page_info)[0])
        #print(page)
        for num in range(1, page+1):
            url = response.url+'p'+str(num)
            #print(url)
            yield scrapy.Request(url, callback = self.parsedetail, meta = {'subject':meta['subject']})
    
    def parsedetail(self, response):
        meta = copy.copy(response.meta)
        #print("12334325346356")
        item = ZujuanItem()
        item['subject'] = meta['subject']
        item['source'] = 996
        item['answer'] = ''
        item['remark'] = ''
        item['analytic'] = ''
        item['html'] = response.url
        item['book_name'] = response.xpath('//span[@id="gradeDiv_show"]/text()').extract_first()
        item['version_name'] = response.xpath('//span[@id="textBookDiv_show"]/text()').extract_first()
        item['chapter_name'] = response.xpath('//div[@id="crumbCanvas"]/a/text()').extract()[-1]
        item['record_time'] = datetime.datetime.now().strftime(
                    '%Y-%m-%d %H:%M:%S')
        for question in response.css('div.quesbox.question'):
            item['question'] = self.EscapeString(question.css('div.quesdiv.question-inner div.quesbody.question-text').extract()[0])
            m2 = hashlib.md5()
            m2.update(str(item['question']+item['chapter_name']).encode('utf-8'))
            item['md5'] = m2.hexdigest()
    
            item['key'] = question.css('div.quesbox.question::attr(id)').extract()[0]
            info_box = question.css('div.operate-box.operate div span::text').extract()
            item['difficulty'] = re.findall(r'难度系数：(.*)', info_box[0])[0]
            item['used_times'] = re.findall(r'使用：(.*)次', info_box[1])[0]
            item['que_type'] = re.findall(r'题型：(.*)', info_box[2])[0]
            item['update_time'] = re.findall(r'更新：(.*)', info_box[3])[0]
            #print(item)
            yield item

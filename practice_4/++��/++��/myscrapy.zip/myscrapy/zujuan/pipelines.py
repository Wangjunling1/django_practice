# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


from zujuan.spiders.ZUJUAN import logger
import json
import pymysql

class ZujuanPipeline(object):

    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  #使用自己的用户名 
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8' 
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        select_sql = 'select * from zujuan_html_archive_20181219 where `key` = "{}" and `chapter_name` = "{}" and `subject` = "{}" '.format(
                                            item['key'], item['chapter_name'], item['subject'])
        self.db_cur.execute(select_sql)
        result = self.db_cur.fetchone()
        if result:
            #logger.error(result)
            #logger.error(result)
            logger.error('[error:已有该题目{}在{}中]'.format(item['key'], item['chapter_name']))
            return

        insert_sql = '''
                      INSERT INTO zujuan_html_archive_20181219
                      (`source`,`subject`,`html`,`md5`,`key`,`version_name`,`book_name`,`chapter_name`,`record_time`,`difficulty`,`used_times`,`que_type`,`update_time`,
                        `answer`, `remark`, `analytic`, `question`)
                      VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',"%s")
                     '''%(item['source'],item['subject'],item['html'],item['md5'],item['key'],item['version_name'], item['book_name'],
                          item['chapter_name'],item['record_time'],item['difficulty'],item['used_times'],
                          item['que_type'],item['update_time'],item['answer'],item['remark'],item['analytic'],
                          item['question'])
        #print(insert_sql)
        try:
            self.db_cur.execute(insert_sql)
            self.client.commit()
            #logger.error("发现了一个新节点  {}".format(item['key']))
        except Exception as e:
            logger.error('[Pipeline][插入语句出现错误 , 语句是{}。]'.format(e))

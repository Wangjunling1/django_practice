# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

from scrapy import Item, Field


class ZujuanItem(Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    used_times = Field()
    difficulty = Field()
    que_type = Field()
    update_time = Field()
    html = Field()
    question = Field()
    subject = Field()
    book_name = Field()
    chapter_name = Field()
    version_name = Field()
    source = Field()
    answer = Field()
    remark = Field()
    analytic = Field()
    html = Field()
    record_time = Field()
    md5 = Field()
    key = Field()
    






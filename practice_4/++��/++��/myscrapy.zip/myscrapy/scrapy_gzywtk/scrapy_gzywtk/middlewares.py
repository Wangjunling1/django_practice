# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/spider-middleware.html

import requests
import random
from scrapy import signals
from .settings import USER_AGENT_LIST


class ScrapyGzywtkSpiderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, dict or Item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Response, dict
        # or Item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class ScrapyGzywtkDownloaderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        request.meta['proxy'] = 'http://' + requests.get('http://172.16.0.99:5010/get/').text
        rand_use = random.choice(USER_AGENT_LIST)
        if rand_use:
            request.headers['User-Agent'] = rand_use
        request.headers['Cookie'] = 'ASP.NET_SessionId=q2e3awhkhevs30wh0wghveen; Hm_lvt_608ab3c368d79f4abacdb0aea85d97db=1565678576; __RequestVerificationToken=fqDkB9i7u4dnEaVACZPnuZql9dNn92XXBd0yaG3hPrU5Ez7yA9uJSHdZVWM051Olu1Vxdbw42oyxeAZwIiimieXRWu-e9EXvkP0QzM-YDlLa-OnRm7qUxJnqXAFhd4Xtt6v28OYOsy7zOI0sSwmpeA2; .ASPXAUTH=B8D9469D17B0A6FC6C038E5CFABA6D2F02C3C070347A0634505367E1DE185493ADF6D27F50DC4BCAC5AB0D4503216D40DBF16F89E09748355751BEAADEB2C5BBBB1C2EAA7DD75CE6DE0915AF04C1D0CEC78B87A0C7362E4E5AB134466546A8281D19CBB7BFA5A119666AE7564A12366DD905B8E8EABAA1593BEF65FBCBBE82F2BF7C2853FE661128E899A945DCA09394; Hm_lpvt_608ab3c368d79f4abacdb0aea85d97db=1565754482'
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)

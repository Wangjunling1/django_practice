# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from .mysql_pool import MySQLPool

db = MySQLPool()


class ScrapyGzywtkPipeline(object):
    def process_item(self, item, spider):
        if db.is_archive(item['key']):
            return
        db.insert(item)

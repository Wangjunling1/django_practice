# -*- coding: utf-8 -*-
import logging
import scrapy
import re
from scrapy_gzywtk.items import ScrapyGzywtkItem

logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)


class GzywtkSpiderSpider(scrapy.Spider):
    name = 'gzywtk_spider'
    allowed_domains = ['gzywtk.com']
    start_urls = ['http://www.gzywtk.com/kaodian/']

    def __init__(self):
        self.base_url = 'http://www.gzywtk.com'
        fh = logging.FileHandler('gzywtk.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    def parse(self, response):
        lis = response.xpath("//ul[@class='menu']/li")[2:]
        for li in lis:
            whole_url = self.base_url + li.xpath('./a/@href').extract()[0]
            menu_type = li.xpath('./a/text()').extract()[0]
            meta = {
                'menu_type': menu_type,
                'menu_url': whole_url,
            }
            yield scrapy.Request(url=whole_url,
                                 meta=meta,
                                 callback=self.parse_page,
                                 dont_filter=True,
                                 )

    def parse_page(self, response):
        meta = response.meta.copy()
        page_text = response.xpath("//div[@class='datapager']/text()").extract()[0]
        page = re.findall(r'\d+', page_text)[0]
        for i in range(1, int(page) + 1):
            logger.info(f"request:{meta['menu_url']}?p={i}")
            yield scrapy.Request(url=f"{meta['menu_url']}?p={i}",
                                 meta=meta,
                                 callback=self.parse_one_page,
                                 dont_filter=True,
                                 )

    def parse_one_page(self, response):
        meta = response.meta.copy()
        lis = response.xpath("//ul[@id='typelist']/li")
        for li in lis:
            detail_url = self.base_url + li.xpath("./div[@class='litop']/a/@href").extract()[0]
            meta['page_url'] = response.url
            meta['detail_url'] = detail_url
            logger.info('request:{}'.format(detail_url))
            yield scrapy.Request(url=detail_url, meta=meta, callback=self.parse_ques, dont_filter=True)

    def parse_ques(self, response):
        item = ScrapyGzywtkItem()
        main_container = response.xpath("//div[@class='mbox_bot']").extract()[0]
        item['key'] = 'gzywtk_qs_' + response.url.split('/')[-1].split('.')[0]
        item['source'] = 68
        item['url'] = response.url
        item['content'] = main_container
        item['extra_info'] = {
            'menu_type': response.meta['menu_type'],
            'menu_url': response.meta['menu_url'],
            'page_url': response.meta['page_url'],
        }
        logger.info('get:{}'.format(item['key']))
        item['spider_id'] = 7062
        item['flag'] = 0
        yield item





#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time: 2019/8/13 4:50 PM
# @Author: xiaopeng
from scrapy.cmdline import execute

execute(['scrapy',
         'crawl',
         'gzywtk_spider']
        )

#scrapy crawl scrapy_xiangpi -s JOBDIR=job_info/001
from selenium import webdriver


def get_info():
    # url = "http://4s.quyixian.com/SEC/"
    # driver = webdriver.PhantomJS('./phantomjs')
    # driver.get(url)
    # book_list = driver.find_element_by_id("seca-cls-child")
    #
    # book_info_list = []
    # spans = book_list.find_elements_by_tag_name('span')
    # print(len(spans))
    # for span in spans:
    #     name = span.get_attribute("data-name")
    #     id = span.get_attribute("data-id")
    #     parent = span.get_attribute("data-parent")
    #     module = span.get_attribute("data-module")
    #     child = span.get_attribute("data-child")
    #     item_dict = {'id':id,'name':name,'parent':parent,'module':module,'child':child}
    #     book_info_list.append(item_dict)
    # f = open("info.txt","w+")
    # f.write(str(book_info_list))
    # f.close()
    f = open("info.txt", "r+")
    text = f.read()
    child_info_list = eval(text)
    book_mapping = {}
    book_info0 = [item for item in child_info_list if item['child'] != '0' and item['parent'] == '0']
    for book0 in book_info0:
        book_info1 = [item for item in child_info_list if item['parent'] == book0['id']]
        for book1 in book_info1:
            book_info2 = [item for item in child_info_list if item['parent'] == book1['id']]
            for book2 in book_info2:
                book_info3 = [item for item in child_info_list if item['parent'] == book2['id']]

                for book3 in book_info3:
                    if book3['child'] == '0':
                        new_item = {}
                        new_item[book0['module']] = book0['name']
                        new_item[book1['module']] = book1['name']
                        new_item[book2['module']] = book2['name']
                        new_item[book3['module']] = book3['name']
                        book_mapping[book3['id']] = new_item
                    else:
                        book_info4 = [item for item in child_info_list if item['parent'] == book3['id']]
                        for book4 in book_info4:
                            if book4['child'] == '0':
                                new_item = {}
                                new_item[book0['module']] = book0['name']
                                new_item[book1['module']] = book1['name']
                                new_item[book2['module']] = book2['name']
                                new_item[book3['module']] = book3['name']
                                new_item[book4['module']] = book4['name']
                                book_mapping[book4['id']] = new_item

                            else:
                                book_info5 = [item for item in child_info_list if item['parent'] == book4['id']]
                                for book5 in book_info5:
                                    if book5['child'] == '0':
                                        new_item = {}
                                        new_item[book0['module']] = book0['name']
                                        new_item[book1['module']] = book1['name']
                                        new_item[book2['module']] = book2['name']
                                        new_item[book3['module']] = book3['name']
                                        new_item[book4['module']] = book4['name']
                                        new_item[book5['module']] = book5['name']
                                        book_mapping[book5['id']] = new_item

    quyixian = open("quyixian_book_info.txt", "w+")
    quyixian.write(str(book_mapping))


if __name__ == '__main__':
    get_info()
# -*- coding: utf-8 -*-
#key = "https://www.wln100.com/Test/1106629.html"
import sys
import re
import json
import pymysql
import hashlib
import requests
sys.path.append("/home/wangkaixi/afanti_tiku_lib")
from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.html.beautify_html import center_image
from afanti_tiku_lib.html.beautify_html import remove_tag
from afanti_tiku_lib.question_template.question_template import Question
from bs4 import BeautifulSoup
import logging


MYSQL_HOST = '172.16.3.17'
MYSQL_DBNAME = 'html_archive'
MYSQL_USER = 'afanti_dw'
MYSQL_PASSWD = 'afanti_dw_04'

# 连接数据库
connect = pymysql.connect(
    host=MYSQL_HOST,
    db=MYSQL_DBNAME,
    user=MYSQL_USER,
    passwd=MYSQL_PASSWD,
    charset='utf8',
    use_unicode=True,
    cursorclass=pymysql.cursors.DictCursor,
)

connect_db_offline = pymysql.connect(
    host=MYSQL_HOST,
    db="question_db_offline",
    user=MYSQL_USER,
    passwd=MYSQL_PASSWD,
    charset='utf8',
    use_unicode=True)
# 通过cursor执行增删查改
cursor = connect.cursor()
offline_cursor = connect_db_offline.cursor()


logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)



class QyxQuestionParser(object):

    def __init__(self, archive_image=False, download=False):
        self.html_magic = HtmlMagic(52, archive_image=archive_image,
                                    download=download, beautify=False)
        fh = logging.FileHandler('parse.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    

    def parse(self, qs):
        #qs['html'] = qs['html'].replace("<img src=\"","<img src=\'").replace(
        #"png\"","png\'").replace("style=\"","style=\'").replace("middle;\"","middle;\'")
        #print(qs['html'])
        qs_json = {}
        #qs['info'] = qs['info'].replace("src=\"",'src=\'').replace("png\"","png\'").replace("style=\"",'style=\'').replace("middle;\"","middle;\'")
        qs_json['paper_name'] = re.findall(r'"name": "(.*?)",', qs['info'])[0]
        qs_json['answer'] = re.findall(r'"ans": "(.*?)",', qs['info'])[0]
        qs_json['analy'] = re.findall(r'"ana": "(.*?)"}', qs['info'])[0]
        qs_json['question_body'] = qs['html']
        qs_json['option_lst'] = get_option(qs['html'])

        
        
        #print("*"*1000)
        q = Question(**qs_json)
        #print("*"*1000)
        qs_json = q.normialize()
        #print("*"*1000)
        ####################################
        #print(qs_json)
        cols = dict()
        key = qs['key']
        #print("*"*1000)
        get_img(key, qs_json['question_body'])

        question_html = self.html_magic.bewitch(qs_json['question_body'],
                                                    spider_url=key)
        print("*"*1000)

        question_html = fix_any(question_html)
        question_html = center_image(question_html)
        cols['question_html'] = EscapeString(question_html)
        key = re.findall(r'"url":(.*?)}', qs['request_info'])[0]

        ####################################
        get_img(key, qs_json['answer'])
        answer_all_html = self.html_magic.bewitch(qs_json['answer'],
                                            spider_url=key)
        answer_all_html = fix_any(answer_all_html)
        answer_all_html = center_image(answer_all_html)
        cols['answer_all_html'] = EscapeString(answer_all_html)
        #################################### 
        get_img(key, qs_json['analy'])
        fenxi = self.html_magic.bewitch(qs_json['analy'],spider_url=key)
        fenxi = fix_any(fenxi)
        fenxi = center_image(fenxi)
        cols['fenxi'] = EscapeString(fenxi)
        ####################################    
        cols['jieda'] = ''
        cols['dianping'] = ''
        cols['spider_source'] = 10
        cols['spider_url'] = qs['key']
        #cols['knowledge_point'] = html_json['knowledge_point']
        cols['zhuanti'] = 0
        cols['exam_year'] = get_exam_year(qs_json['paper_name'])
        cols['exam_city'] = get_exam_city(qs_json['paper_name'])
        cols['paper_name'] = qs_json['paper_name']
        #cols['subject'] = qs['subject']
        cols['option_html'] = ''
        cols['question_id'] = qs['html_id']
        #print(cols)
        #print(cols)
        return cols

        

def fix_any(html_string):
    html_string = re.sub(r'_{6,}', '______', html_string)
    html_string = html_string.replace('<p>无</p>', '')
    html_string = html_string.replace(r"\u3000","_")
    return html_string


def get_option(html_string):
    html_string = re.findall(r'<td width="25%">(.*?)</td>', html_string)
    #html_string = [EscapeString(i) for i in html_string]
    ol = [i.split(".") for i in html_string]
    #print(ol)
    option_lst = []
    for i in ol:
        option_dict = {}
        option_dict['value'] = i[0]
        option_dict['content'] = i[1]
        option_lst.append(option_dict) 
    #print(option_lst)
    return option_lst

def get_exam_year(html_string):
    year_regex =   re.findall(r'20[0-2][2-9]',html_string)
    if year_regex:
        return year_regex[0]
    else:
        return 0

def get_exam_city(html_string):
    city_regex = re.findall(
        r'北京|上海|天津|重庆|黑龙江|吉林|辽宁|山东|山西|陕西|河北|河南|湖北|湖南|海南|江苏|江西|广东|广西|云南|贵州|四川|内蒙古|宁夏|甘肃|青海|西藏|新疆|安徽|浙江|福建|香港|台湾|澳门|全国',html_string)
    if city_regex:
        return city_regex[0]
    else:
        return 0
    
def get_img(key, html_string):
    soup = BeautifulSoup(html_string, 'lxml')
    img_list = soup.find_all('img')
    img_list = [img.get('src') for img in img_list]
    for image_url in img_list:
        image_url_md5 = hashlib.md5(image_url.encode('utf8')).hexdigest()
        download_img(52, key, image_url, image_url_md5)

def download_img(spider_source, spider_url, image_url, image_url_md5, using_proxy=True, headers=""):
    url = "http://172.16.0.100:9000/apis/v1/image/collection/"
    data = dict(
        spider_source = spider_source,
        image_url = image_url,
        image_url_md5 = image_url_md5,
        spider_url = spider_url,
        headers = headers,
        proxy = True if using_proxy else None,
    )
    #print(data)

    r = requests.post(url, data=data)
    if r.status_code==200:
        #print(r.json())
        return True
    else:
        return False

def EscapeString(string):
    string = string.replace('\'','\\\'').replace('\"','\\\"')
    return string


    

def main():
    qyx = QyxQuestionParser()
    start_num = 0
    limit_num = 1000
    while start_num < 1142650:
        sql = "select * from qyx_book_html_archive_table_20181116 limit {},{}".format(start_num, limit_num)
        #qyx = QyxQuestionParser()
        #print(sql)
        cursor.execute(sql)
        results = cursor.fetchall()
        #print(results)
        if results:
            for result in results:
                try:
                    qus_data = qyx.parse(result)
                    print(qus_data)
                    insert_sql = '''insert into quyixian_question_20181206 (question_id, spider_source,spider_url,zhuanti,exam_year,
                            exam_city,paper_name,question_html,
                            answer_all_html,jieda,fenxi,dianping,option_html
                            ) values('%s',%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')
                            '''%(qus_data['question_id'],qus_data['spider_source'],qus_data['spider_url'],qus_data['zhuanti'],
                                 qus_data['exam_year'],qus_data['exam_city'],qus_data['paper_name'],
                                 qus_data['question_html'],qus_data['answer_all_html'],qus_data['jieda'],
                                 qus_data['fenxi'],qus_data['dianping'],qus_data['option_html'])
                    offline_cursor.execute(insert_sql)
                    connect_db_offline.commit()
                except Exception as e:
                    print("pass")
                    pass
 
        logger.error(start_num)
        start_num += limit_num
    cursor.close()
    offline_cursor.close()
    connect.close()
    connect_db_offline.close()



        

    


if __name__ == "__main__":
    main()




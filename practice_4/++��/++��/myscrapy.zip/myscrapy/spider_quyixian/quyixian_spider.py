import asyncio
import requests
import time
import json
import os
import hashlib
import aiohttp
import logging
import pymysql

from common import quyixian_book_info,added_dict

logging.basicConfig(
        level=logging.DEBUG,  # 定义输出到文件的log级别，大于此级别的都被输出
        format='%(asctime)s  %(filename)s : %(levelname)s  %(message)s',  # 定义输出log的格式
        datefmt='%Y-%m-%d %A %H:%M:%S',  # 时间
        filename=os.path.join(os.getcwd(), 'quyixian.log'),  # log文件名
        filemode='a+')

all_qus = "http://4s.quyixian.com/SEC/?act=mng_sear&bookid={}&page=0"
ans_url = "http://4s.quyixian.com/SEC/?act=mng_ans&qid={}"

headers = {
        'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Encoding':'gzip, deflate',
        'Accept-Language':'zh-CN,zh;q=0.9',
        'Cache-Control':'max-age=0',
        'Connection':'keep-alive',
        'Cookie': 'Hm_lvt_6dc1db5946cd709d578724542b296438=1542106064,1542106077,1542247904,1542247909; Tuser=1D2ACE014338600EB3A7CD40019AAF63C6B14FC2CFDC2682C2D3D9B5ED6C13D839C3470FD9EC2C851F3ED4165AC9F591; Hm_lpvt_6dc1db5946cd709d578724542b296438=1542274658',
        'Host': '4s.quyixian.com',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
}
client = pymysql.connect(
    host='172.16.3.17',
    port=3306,
    user='afanti_dw',  #使用自己的用户名
    passwd='afanti_dw_04',  # 使用自己的密码
    db='html_archive',  # 数据库名
    charset='utf8'
)
db_cur = client.cursor()

def insert_data(item):
    select_sql = "select * from qyx_book_html_archive_table_20181116 where `key` = '%s'"%(item['key'])
    db_cur.execute(select_sql)
    result = db_cur.fetchone()
    if result:
        logging.error('had added {}'.format(item['key']))
        return False
    insert_sql = '''
                          INSERT INTO qyx_book_html_archive_table_20181116
                          (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`flag`,`flag_str`)
                          VALUES (%d,%d,'%s','%s','%s','%s','%s',%d,'%s')
                         ''' % (
    item['source'], item['subject'], item['html'].replace('"', '\\"').replace('\'', '\'\''), item['md5'], item['key'],
    json.dumps(item['request_info'],ensure_ascii=False), item['info'], item['flag'], item['flag_str'])
    try:
        pass
        #db_cur.execute(insert_sql)
        client.commit()
        return True
    except Exception as e:
        logging.error('add failed {}'.format(e))
        return False
async def requests_meantime_dont_wait(bid):
    url = all_qus.format(bid)
    #print(url)
    async with aiohttp.ClientSession() as session:
        async with session.get(url,headers=headers) as resp:
            logging.info('{} {}'.format(url,resp.status))
            print(url)
            text = await resp.text()
            text_dict = eval(text)
            #print(text_dict)
            qus_list = text_dict['List']
            qus_num =   text_dict['Qcount']
            for i,val in enumerate(qus_list):
                #print(val)
                async with session.get(ans_url.format(val['QuestionID']), headers=headers) as ans_resp:
                    print(ans_url.format(val['QuestionID']))
                    log_info = {'current_num':i+1,'mode_max_num':qus_num,'bid':bid,'name':added_dict[bid]}
                    text = await ans_resp.text()
                    ans_dict = eval(text)[0]
                    info = {'page':val['page'],'num':val['n'],'name':added_dict[bid],'ans':ans_dict}
                    m2 = hashlib.md5()
                    m2.update(val['question'].encode('utf8'))
                    item = {}
                    item['source'] = 10
                    item['subject'] = 0
                    item['html'] = val['question']
                    item['key'] = 'quyixian_qs_{}'.format(val['QuestionID'])
                    item['info'] = json.dumps(info,ensure_ascii=False)
                    item['md5'] = m2.hexdigest()
                    item['request_info'] = {"method": "GET", "url": url}
                    item['flag'] = 0
                    item['flag_str'] = ''
                    #print(item)
                    if insert_data(item):
                        logging.info(log_info)


async def fast_requsts(info_list):
    # start = time.time()
    await asyncio.wait([requests_meantime_dont_wait(bid) for bid in info_list])
    # end = time.time()
    # print("Complete in {} seconds".format(end - start))



if __name__=='__main__':
    #控制并发量，一次请求20个网页
    size = 20
    info_list = list(added_dict.keys())[:5]
    for i in range(0,len(info_list),size):
        new_list = info_list[i:i+size]
        loop = asyncio.get_event_loop()
        loop.run_until_complete(fast_requsts(new_list))
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 26 15:06:59 2018

@author: xiaopeng
"""
'''
    功能:quyixian_book_info表示所有书本信息，added_list为已添加题目的bid,在执行脚本的时候
    先爬取已添加的bid存入common，之后添加题目时可以忽略已添加题目。
'''
import gevent
from gevent import monkey; monkey.patch_all()
import requests
from common import quyixian_book_info,added_dict
from bs4 import BeautifulSoup

add_url = "http://4s.quyixian.com/SEC/?act=add_save"
del_url = "http://4s.quyixian.com/SEC/?act=mng_del"
base_url = "http://4s.quyixian.com/SEC/?act=addq&cid={}"
page_base_url = "http://4s.quyixian.com/SEC/?act=add_pageofbook&bid={}"
qus_base_url= "http://4s.quyixian.com/SEC/?act=add_questionofpage&bid={}&page={}"
ids = []
headers = {
    'Cookie': 'Hm_lvt_6dc1db5946cd709d578724542b296438=1540520791,1541057520; Tuser=1D2ACE014338600EB3A7CD40019AAF63C6B14FC2CFDC2682C2D3D9B5ED6C13D839C3470FD9EC2C851F3ED4165AC9F591; Hm_lpvt_6dc1db5946cd709d578724542b296438=1542077949',
    'Host': '4s.quyixian.com',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
    'Referer': 'http://4s.quyixian.com/SEC/?act=addq',
}

def add_qus(id):

    data = {
        'ids': id,
    }
    resp = requests.post(add_url, data=data, headers=headers)
    print('add '+resp.text+' questions')

def get_ids(url_list,parent_url):
    ids = []
    for url in url_list:
        try:
            r = requests.get(url)
            qus_list = eval(r.text)
            id = [item['ID'] for item in qus_list]
            ids.extend(id)
        except Exception as e:
            print('failed with '+url)
            print(e)
    if ids:
        try:
            add_qus(ids)
            print(parent_url+' success')

        except Exception as e:
            print(parent_url+' failed')
def get(url):
    response = requests.get(url)
    page_list = eval(response.text)

    qus_url = [qus_base_url.format(url.split('=')[-1], i) for i in page_list]
    get_ids(qus_url,url)


if __name__ == '__main__':
    #获取已添加的bid
    # resp = requests.get('http://4s.quyixian.com/UC/SEC.aspx?action=list&stage=2',headers=headers)
    # soup = BeautifulSoup(resp.text,'lxml')
    # table = soup.find('table',attrs={'class':'uc-wrong'})
    # trs = table.find_all('tr')
    # added_dict = {}
    # for tr in trs:
    #     tds = tr.find_all('td')
    #     name = tds[0].getText()
    #     bid = tds[2].find('a')['href'].split('=')[-1]
    #     added_dict[bid] = name
    # print(added_dict)

    #page_url_list中存入未添加的题目的page_url
    page_url_list = []
    for item in list(quyixian_book_info.keys()):
        url = base_url.format(item)
        response = requests.get(url)
        soup = BeautifulSoup(response.text,'lxml')
        main = soup.find_all(name='label',attrs={'class':'gg-left gg-pd-lr-2e gg-bold gg-pointer gg-hv-opa-8'})
        for i in main:
            # 该书的模块名
            label = i.getText()
            # 通过bid获取每本书页码信息
            bid = i.attrs['data-id']
            page_url = page_base_url.format(bid)
            print(page_url)

            if bid not in list(added_dict.keys()):
                page_url_list.append(page_url)
            else:
                #print('已经添加')
                continue
    print(page_url_list)
    # g1 = [gevent.spawn(get, url) for url in page_url_list]
    # gevent.joinall(g1)

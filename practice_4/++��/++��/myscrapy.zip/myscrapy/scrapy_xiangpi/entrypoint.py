from scrapy.cmdline import execute

execute(['scrapy','crawl','scrapy_xiangpi','-s','JOBDIR=job_info/001'])

#scrapy crawl scrapy_xiangpi -s JOBDIR=job_info/001
# -*- coding: utf-8 -*-

# Scrapy settings for scrapy_xiangpi project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'scrapy_xiangpi'

SPIDER_MODULES = ['scrapy_xiangpi.spiders']
NEWSPIDER_MODULE = 'scrapy_xiangpi.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'scrapy_xiangpi (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
#CONCURRENT_REQUESTS = 32

# Configure a delay for requests for the same website (default: 0)
# See https://doc.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
#DOWNLOAD_DELAY = 3
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
DEFAULT_REQUEST_HEADERS = {
    "Cookie":"Hm_lpvt_c4cfed328496de6ee2169915c965ce3d=1543285371;Hm_lvt_c4cfed328496de6ee2169915c965ce3d=1542856167,1542856181,1542856274,1543285371;CNZZDATA1257100452=2100515960-1543280541-%7C1543280541;xp=t=86d0332a48494b7d9e5739d7d96602fd&uid=bff4b7da99f7af&sid=bff7&ut=1&rn=bfd6b6f790d6a7ecbfcf99c2&nn=bfd6b6f790d6a7ecbfcf99c2&sn=&ci=bff7&cn=&g=&edt=&lct=-8586583215151106049;pgv_pvid=6838158270;__qc_wId=341;UM_distinctid=16752f9cdecc5b-0dfe038fc-2e213b73-c0000-16752f9cded55d"
}

# Enable or disable spider middlewares
# See https://doc.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'scrapy_xiangpi.middlewares.ScrapyXiangpiSpiderMiddleware': 543,
#}
RETRY_HTTP_CODES = [429, 500, 503, 504, 400, 403, 404, 408]
RETRY_TIMES = 100
# Enable or disable downloader middlewares
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
DOWNLOADER_MIDDLEWARES = {
    'scrapy_xiangpi.middlewares.ScrapyXiangpiDownloaderMiddleware': 543,
    'scrapy_xiangpi.middlewares.ProxyMiddleware': 125,
}

# Enable or disable extensions
# See https://doc.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://doc.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
   'scrapy_xiangpi.pipelines.ScrapyXiangpiPipeline': 300,
}

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'

LOG_FILE = "mySpider.log"
LOG_LEVEL = "WARNING"
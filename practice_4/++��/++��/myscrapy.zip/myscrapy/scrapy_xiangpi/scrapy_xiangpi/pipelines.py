# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
import pymysql
from scrapy_xiangpi.spiders.xiangpi_spider import logger
from pymysql import escape_string


#将试题信息存入数据库
class ScrapyXiangpiPipeline(object):
    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  #使用自己的用户名
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        select_sql = 'select * from xiangpi_page_html_archive_1122 where `key` = "%s"'%item['key']
        self.db_cur.execute(select_sql)
        result = self.db_cur.fetchone()
        if result:
            logger.error('[ScrapyXiangpiPipeline][error:had added {}]'.format(item['key']))
            return

        insert_sql = '''
                      INSERT INTO xiangpi_page_html_archive_1122
                      (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`flag`,`flag_str`,`ans_ana`)
                      VALUES (%d,%d,'%s','%s','%s','%s','%s',%d,'%s','%s')
                     '''%(item['source'],item['subject'],item['html'].replace('\'','\'\'').replace('"','\\"'),item['md5'],item['key'],
                          json.dumps(item['request_info'],ensure_ascii=False),json.dumps(item['info'],ensure_ascii=False),item['flag'],
                          item['flag_str'],item['ans_ana'].replace('\'','\'\'').replace('"','\\"'))
        try:
            self.db_cur.execute(insert_sql)
            self.client.commit()
        except Exception as e:
            logger.error('[ScrapyXiangpiPipeline][error:{}]'.format(e))


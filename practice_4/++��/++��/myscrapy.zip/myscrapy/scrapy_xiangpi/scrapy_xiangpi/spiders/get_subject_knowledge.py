import requests
import os
import json
from .common import *
headers = {
    "Cookie":"UM_distinctid=166c433b536394-0baa0be77971d9-346c780e-13c680-166c433b5372c7; __qc_wId=596; pgv_pvid=2609786098; Hm_lvt_c4cfed328496de6ee2169915c965ce3d=1541039015; __qc__k=TC_MK=45F09DFA57D36F7ED46A3D9F382F67C8; __BAIDU_STATE_END__=yes; __tins__19477653=%7B%22sid%22%3A%201542353863285%2C%20%22vd%22%3A%201%2C%20%22expires%22%3A%201542355663285%7D; __51cke__=; __51laig__=1; Hm_lpvt_c4cfed328496de6ee2169915c965ce3d=1542359108; zj_edusubj=2%2C7; xp=t=507a2cf00faa448ba53244e4884620f9&uid=602b6805462870&sid=6028&ut=1&rn=600969284f0978336010461d&nn=600969284f0978336010461d&sn=&ci=6028&cn=&g=&edt=&lct=-8586592474331610209; CNZZDATA1257100452=90742242-1540886452-%7C1542309978",
    "Referer":"http://www.xiangpi.com/zujuan/1",
    'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
    'Host':'www.xiangpi.com',
}
url = "http://www.xiangpi.com/Ashx/TestCombination/BCOrKPCombination.ashx"
def get_knowledges():
    for grade in GRADE_MAPPING:
        for subj in SUBJ_MAPPING:
            info_path = "knowledges/{}_{}.txt".format(GRADE_MAPPING[grade],SUBJ_MAPPING[subj])
            if os.path.exists(info_path):
                try:
                    js = json.load(open(info_path,'wb'))
                except:
                    pass
            else:
                data = {
                    'action':'leftKPTreeParentData',
                    'edu':GRADE_MAPPING[grade],
                    'subject':SUBJ_MAPPING[subj],
                }
                resp = requests.post(url,headers = headers,data=data)
                try:
                    kno_dict = resp.json()['DataList']
                    no_child_list = [item for item in kno_dict if item['IsHaveChild']==False]

                    with open(info_path,'w+') as fd:
                        json.dump(no_child_list,fd,indent=4,ensure_ascii=False)
                except Exception as e:
                    print(e)
if __name__=='__main__':
    get_knowledges()
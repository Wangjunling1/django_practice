import scrapy
import json
import copy
import time
import hashlib
import logging
import requests
from .common import SUBJ_MAPPING,GRADE_MAPPING
from scrapy_xiangpi.items import XiangpiQusItem
from scrapy_xiangpi.settings import DEFAULT_REQUEST_HEADERS
from .get_cookies import get_cookies
logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)

class MySpider(scrapy.Spider):
    '''
    功能：爬取91淘课网上面所有的题的html,存入数据库
    '''
    name = 'scrapy_xiangpi'
    allowed_domains = ["xiangpi.com"]
    #pageindex 页码
    #status 接口类型
    #educationlevel 年级
    #chaptersubject 科目id
    #knowledgeorchapter 知识点id
    start_urls = []
    ans_url = "http://www.xiangpi.com/Ashx/TestCombiViewHandle.ashx?educationlevel={}&chaptersubject={}&testid={}&status=3"
    base_url = "http://www.xiangpi.com/Ashx/TestListFilterMbCollectionHandle.ashx?pageindex={}&status=1&educationlevel={}&chaptersubject={}&knowledgeorchapter={}"

    def __init__(self):
        # 初始化日志格式
        fh = logging.FileHandler('xiangpi.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        # try:
        #     get_cookies()
        #     logger.info('[parse_ans]login success')
        #     print(DEFAULT_REQUEST_HEADERS)
        # except Exception as e:
        #     logger.error('[parse_ans][error:get_cookies_failed {}]'.format(e))

    def start_requests(self):
        for educationlevel in GRADE_MAPPING:
            for chaptersubject in SUBJ_MAPPING:
                gra = GRADE_MAPPING[educationlevel]
                sub = SUBJ_MAPPING[chaptersubject]
                path = "scrapy_xiangpi/spiders/knowledges/{}_{}.txt".format(gra,sub)
                with open(path,'rb+') as r:
                    knowledge_points = json.load(r)
                    for kno in knowledge_points[:1]:
                        subj_name = educationlevel + chaptersubject
                        url = self.base_url.format(1,gra,sub,kno['NodeId'])
                        yield scrapy.Request(url=url,meta={'url':url,'gra':gra,'sub':sub,
                                                           'kno_name':kno['NodeName'],
                                                           'kno_id':kno['NodeId'],'name':subj_name},callback=self.parse)

    # {"method": "GET", "url": "http://4s.quyixian.com/SEC/?act=mng_sear&bookid=990&page=0"}
    def parse(self,response):
        meta = copy.copy(response.meta)
        resp_dict = json.loads(response.body)
        if resp_dict['PageTotalCount']%10 == 0:
            page_num = resp_dict['PageTotalCount']//10
        else:
            page_num = resp_dict['PageTotalCount']//10+1
        for i in range(1,2):#int(page_num)+1
            url = self.base_url.format(i,meta['gra'],meta['sub'],meta['kno_id'])
            meta['current_page'] = i
            meta['max_page'] = page_num
            meta['current_url'] = url
            yield scrapy.Request(url=url, meta=meta, callback=self.parse_detail,dont_filter=True)

    def parse_detail(self,response):
        print(response.meta['url'])
        meta = copy.copy(response.meta)
        json_dict = json.loads(response.body)
        return_datas = json_dict['ReturnData']
        for data in return_datas:
            d = data['d']   #唯一id
            tt = data['tt']  #题型
            td = data['td']  #题目id
            qus_html = data['th']  #题目
            pt = data['pt']   #来源
            request_info = {"method": "GET", "url":meta['url']}

            log_info = {'gra':meta['gra'],'sub':meta['sub'],'kno_name':meta['kno_name'],'name':meta['name'],
                        'current_page':meta['current_page'],'max_page':meta['max_page'],'current_url':meta['current_url']}
            logger.info('[parse_detail]{}'.format(log_info).encode('utf8'))
            item = XiangpiQusItem()
            item['source'] = 80
            item['subject'] = 0
            item['html'] = qus_html
            m2 = hashlib.md5()
            m2.update(qus_html.encode('utf8'))
            item['md5'] = m2.hexdigest()
            item['key'] = d
            info = {'chapter':meta['kno_name'],'qus_type':tt,'qus_id':td,'qus_origin':pt,'subj':meta['name']}
            item['request_info'] = request_info
            item['info'] = info
            item['flag'] = 0
            item['flag_str'] = ''
            meta['item'] = item
            ans_whole_url = self.ans_url.format(meta['gra'], meta['sub'], d)
            yield scrapy.Request(ans_whole_url,meta=meta,callback=self.parse_ans,dont_filter=True)

    def parse_ans(self,response):
        resp_dict = json.loads(response.body)
        ans = resp_dict['ReturnData']['u']
        ana = resp_dict['ReturnData']['v']
        item = response.meta['item']
        item['ans_ana'] = json.dumps({'ans': ans, 'ana': ana}, ensure_ascii=False)
        if '登录' in item['ans_ana']:
            print(item)
            logger.info('[parse_ans]need login')
            return
        else:
            print(item)
            # yield item





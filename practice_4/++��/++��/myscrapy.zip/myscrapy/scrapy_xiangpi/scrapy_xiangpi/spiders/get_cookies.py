import time
from selenium import webdriver
from scrapy_xiangpi.settings import DEFAULT_REQUEST_HEADERS
from selenium.webdriver.common.keys import Keys
from functools import reduce
def get_cookies():
    login_url = "http://www.xiangpi.com/login"
    driver = webdriver.PhantomJS("/Users/xiaopeng/Downloads/phantomjs-2.1.1-macosx/bin/phantomjs")
    driver.get(login_url)
    source = driver.page_source
    user_name_ele = driver.find_element_by_xpath('//*[@id="LoginName"]')
    user_name_ele.send_keys("18810133730")
    time.sleep(1)
    pwd_ele = driver.find_element_by_xpath('//*[@id="Password"]')
    pwd_ele.send_keys("Xiaopeng1997")
    time.sleep(1)
    login_ele = driver.find_element_by_xpath('//*[@id="SubmitLogin"]')
    login_ele.send_keys(Keys.ENTER)
    time.sleep(1)
    if driver.current_url != login_url:
        print("登录成功")
    list_cookies = driver.get_cookies()
    cookies = ['%s=%s'%(item['name'],item['value']) for item in list_cookies]
    result = reduce(lambda x,y : x+';'+y,cookies)
    print(result)

get_cookies()

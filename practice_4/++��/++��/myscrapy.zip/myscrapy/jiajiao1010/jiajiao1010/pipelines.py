# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
import pymysql
from jiajiao1010.spiders.jj1010 import logger
from pymysql import escape_string


#将试题信息存入数据库
class ScrapyJiajiaoPipeline(object):
    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='user_name',  #使用自己的用户名
            passwd='password',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        select_sql = 'select * from 1010jiajiao_spider_html_archive_table_20181107 where md5 = "%s"'%item['md5']
        self.db_cur.execute(select_sql)
        result = self.db_cur.fetchone()
        if result:
            logger.error('[ScrapyJiajiaoPipeline][error:已有该题目{}]'.format(item['md5']))
            return

        insert_sql = '''
                      INSERT INTO 1010jiajiao_spider_html_archive_table_20181107
                      (`source`,`subject`,`html`,`md5`,`key`,`request_info`,`info`,`flag`,`flag_str`)
                      VALUES (%d,%d,'%s','%s','%s','%s','%s',%d,'%s')
                     '''%(item['source'],item['subject'],item['html'].replace('\'','\'\'').replace('"','\\"'),item['md5'],item['key'],
                          item['request_info'],json.dumps(item['info'],ensure_ascii=False),item['flag'],item['flag_str'])
        try:
            self.db_cur.execute(insert_sql)
            self.client.commit()
        except Exception as e:
            print(item['html'])
            logger.error('[ScrapyJiajiaoPipeline][error:{}]'.format(e))

class writeSQL(object):

    def __init__(self):
        self.client = pymysql.connect(
            host='172.16.3.17',
            port=3306,
            user='afanti_dw',  #使用自己的用户名 
            passwd='afanti_dw_04',  # 使用自己的密码
            db='html_archive',  # 数据库名
            charset='utf8'   
        )
        self.db_cur = self.client.cursor()


    def process_item(self,item,spider):
        values = (
        item['html_id'], 
        item['source'], 
        item['subject'], 
        item['html'], 
        item['md5'], 
        item['key'],
        item['request_info'],
        item['info'],
        item['record_time'],
        item['flag'],
        item['flag_str'],
        item['book_id'],

        )
        sql = 'INSERT INTO 1010jiajiao_spider_html_archive_table_1105 VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)' 
        self.db_cur.execute(sql, values)
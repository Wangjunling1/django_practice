# -*- coding: utf-8 -*-
from gevent import monkey; monkey.patch_socket()
import gevent
import logging
import json
from pyquery import PyQuery
import MySQLdb.cursors
from afanti_tiku_lib.dbs.mysql_pool import CommonMysql
from afanti_tiku_lib.dbs.execute import execute
from afanti_tiku_lib.dbs.sql import insert_sql, select_sql
from jiajiao1010.parse.jiajiao1010_parse import Jiajiao1010Parser

MAX_PROCESS_COUNT = 10
logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('jiajiao_parse.log')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

# 连接数据库
connect2 = MySQLdb.connect(
    host="172.16.3.17",
    db="question_pre",
    user="afanti_dw",
    passwd="afanti_dw_04",
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,
)
# 通过cursor执行增删查改
connect = MySQLdb.connect(
    host='172.16.3.17',
    db='html_archive',
    user='afanti_dw',
    passwd='afanti_dw_04',
    charset='utf8mb4',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,
)
connect_db_offline = MySQLdb.connect(
    host='172.16.3.17',
    db="question_db_offline",
    user='afanti_dw',
    passwd='afanti_dw_04',
    charset='utf8',
    use_unicode=True,
    cursorclass=MySQLdb.cursors.DictCursor,)

offline_cursor = connect_db_offline.cursor()
# 通过cursor执行增删查改
cursor = connect.cursor()
cursor2 = connect2.cursor()
parser = Jiajiao1010Parser(download=False)

def record_questions(rows):
    mysql_conn = get_mysql_connection()

    for row in rows:
        html_string = row[1]
        spider_url = row[2]
        info = json.loads(row[3])

        logging.info(spider_url)

        if is_archived(spider_url):
            continue

        try:
            cols = parser.parse(html_string, spider_url, info)
        except Exception as err:
            logging.error('[parser.parse] {}, {}'.format(err, spider_url))
            continue

        if not cols:
            continue

        # print(json.dumps(cols, indent=4, ensure_ascii=False))


        sql, vals = insert_sql('question_db_offline.1010jiajiao_question_20161115',
                               cols, ignore=True)
        execute(mysql_conn, sql, values=vals)


def get_mysql_connection():
    global mysql
    global mysql_conn

    try:
        if mysql_conn.ping() is False:
            mysql_conn = mysql.connection()
        return mysql_conn
    except Exception:
        mysql_conn = mysql.connection()
        return mysql_conn


def is_archived(spider_url):
    mysql_conn = get_mysql_connection()

    sql = select_sql('question_db_offline.1010jiajiao_question_20161115',
                     ('question_id',),
                     condition='where spider_url = "{}"'.format(spider_url))

    rs = execute(mysql_conn, sql)
    if rs:
        return True
    else:
        return False


def main():
    mysql_conn = get_mysql_connection()

    max_id = 0
    while True:
        sql = select_sql('1010jiajiao_spider_html_archive_table',
                         ('html_id', 'html', 'key', 'info'),
                         condition='where html_id > {} order by html_id limit 1000'.format(max_id))

        rows = execute(mysql_conn, sql)
        if not rows:
            break

        record_questions(rows)

        max_id = rows[-1][0]

    logging.info('# over')

def deal_with_label(html):
    html = html.replace('<h1 class="q-tigan">','<p>').replace('</h1>','</p>').replace('<h1>','<p>')
    afanti_wapper = '<div class="aft_question_wrapper"></div>'
    doc = PyQuery(afanti_wapper)
    div = doc('div')
    div.append(html)
    return div

def deal_one_select(min_id,max_id):
    select_sql = "select * from 1010jiajiao_spider_html_archive_table_20181107 " \
                 "where `html_id` >= %d and `html_id` < %d"%(min_id,max_id)
    cursor.execute(select_sql)
    result = cursor.fetchone()
    while result:
        cursor2.execute("select `spider_url` from question where `spider_url`='%s'"%(result['key']))
        added_key = cursor2.fetchone()
        if added_key:
            logger.info('had added:{}'.format(result['key']))
            result = cursor.fetchone()
            continue
        question_item = parser.parse(result['html'],result['key'],result['info'])
        for key in ['question_html','option_html','answer_all_html','jieda','fenxi','dianping']:
            if question_item[key] != '':
                result = deal_with_label(question_item[key])
                question_item[key] = str(result)
        print(question_item['spider_url'])
        insert_sql = '''insert into 1010jiajiao_question_20190107 (spider_source,spider_url,knowledge_point,subject,zhuanti,exam_year,
                                            exam_city,difficulty,question_type,question_quality,question_html,option_html,
                                            answer_all_html,jieda,fenxi,dianping,
                                            flag) values(%d,'%s','%s',%d,'%s',%d,'%s',%d,'%s','%s','%s','%s','%s','%s','%s','%s',%d)
                                            ''' % (question_item['spider_source'], question_item['spider_url'],
                                                   question_item['knowledge_point'], question_item['subject'],
                                                   question_item['zhuanti'], question_item['exam_year'],
                                                   question_item['exam_city'], question_item['difficulty'], question_item['question_type'],
                                                   question_item['question_quality'],
                                                   question_item['question_html'].replace('"', '\\"').replace('\'','\'\''),
                                                   question_item['option_html'].replace('"', '\\"').replace('\'','\'\''),
                                                   question_item['answer_all_html'].replace('"', '\\"').replace('\'','\'\''),
                                                   question_item['jieda'].replace('"', '\\"').replace('\'', '\'\''),
                                                   question_item['fenxi'].replace('"', '\\"').replace('\'', '\'\''),
                                                   question_item['dianping'].replace('"', '\\"').replace('\'', '\'\''),
                                                   0)
        try:
            offline_cursor.execute(insert_sql)
            connect_db_offline.commit()
        except Exception as e:
            logger.error('error in insert data {}:{}'.format(question_item['spider_url'],e))
        result = cursor.fetchone()
    logger.info('finish a process:[{},{})'.format(min_id,max_id))
def run(min_id, max_id, step):
    process_list = []
    for i in range(min_id, max_id, step):
        process_list.append(gevent.spawn(deal_one_select, i , i+step))
    gevent.joinall(process_list)


def main1():
    min_html_id = 2000
    max_html_id = 4000
        #350902394
    step = 20
    singe_id_range = step * MAX_PROCESS_COUNT
    for i in range(min_html_id,max_html_id,singe_id_range):
        run(i, i+singe_id_range, step)

if __name__ == '__main__':
    main1()


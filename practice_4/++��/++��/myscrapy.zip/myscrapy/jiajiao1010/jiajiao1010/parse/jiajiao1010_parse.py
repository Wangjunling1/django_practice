# -*- coding: utf-8 -*-

import re
import json
from afanti_tiku_lib.html.extract import get_html_element
from afanti_tiku_lib.html.beautify_html import remove_tag

from afanti_tiku_lib.html.magic import HtmlMagic
from afanti_tiku_lib.html.beautify_html import center_image

import string
OPTION_DICT = {i: k for i, k in enumerate(string.ascii_uppercase)}

SUBJ = {
# 高中
'/gzyy/': 23,
'/gzyw/': 21,
'/gzsx/': 22,
'/gzwl/': 25,
'/gzdl/': 27,
'/gzhx/': 26,
'/gzsw/': 29,
'/gzls/': 28,
'/gzzz/': 30,

# 初中
'/czyy/': 3,
'/czyw/': 1,
'/czsx/': 2,
'/czwl/': 5,
'/czdl/': 7,
'/czhx/': 6,
'/czsw/': 9,
'/czls/': 8,
'/czzz/': 10,
}

re_comment = re.compile(r'<!--.+?-->')
re_qs = re.compile(r'<strong>题目[^<>]+?</strong>\s*</p>')


class ParseError(Exception): pass


class Jiajiao1010Parser(object):

    def __init__(self, archive_image=False, download=False):
        self.html_magic = HtmlMagic(65, archive_image=archive_image,
                                    download=download, beautify=False)


    def parse(self, html_string, url, info):
        cols = dict()
        self.url = url

        question_html = html_string
        try:
            # print(info)
            # pattern = re.compile('{"ans": "(.*?)"}',re.M|re.I)
            # result = pattern.search(info)
            # # result = pattern.findall(info)
            # print(result.group(1))
            new_str = info.encode('utf8', 'strict')[9:-2]
            info = {}
            info['ans'] = new_str.decode('utf8')
        except Exception as e:
            print(e)
            print('json.loads失败')
            print(info)
            return
        if not self.is_jy(question_html + info['ans']):
            question_html = self.html_magic.bewitch(question_html, spider_url=self.url)
            cols['question_html'] = question_html

            jieda = self.get_jieda(info['ans'])
            cols['jieda'] = jieda
        else:
            return None

        subj = self.get_subject(url)
        cols['subject'] = subj

        cols['answer_all_html'] = ''
        cols['fenxi'] = ''
        cols['dianping'] = ''
        cols['difficulty'] = 0
        cols['zhuanti'] = ''
        cols['spider_url'] = url
        cols['spider_source'] = 65
        cols['question_type'] = 0
        cols['question_quality'] = 0
        cols['knowledge_point'] = ''
        cols['exam_year'] = 0
        cols['exam_city'] = ''
        cols['option_html'] = ''
        return cols


    def get_question_html(self, html_string):
        # e = get_html_element('<div class=\'timutext\'>', html_string,
                             # with_tag=False, limit=1)[0]
        mod = re_qs.search(html_string)
        if not mod:
            return self.get_question_html2(html_string)
        i = mod.end()
        ii = html_string.find('<div class=\'timutext\'>')
        e = html_string[i:ii]
        # e = get_html_element('<div class=motable>', html_string[i:],
                             # with_tag=False, limit=1)
        # if not e:
            # raise ParseError('{} can not find <div class=motable>'.format(self.url))
        # e = e[0]
        e = center_image(e)
        e = self.fix_any(e)
        return e


    def get_question_html2(self, html_string):
        i = html_string.find('<strong>题目详情</strong>')
        if i == -1:
            raise ParseError('{} can not find <strong>题目详情</strong>'.format(self.url))

        e = get_html_element('<div class=\'timutext\'>', html_string[i:],
                             with_tag=False, limit=1)
        if not e:
            raise ParseError('{} can not find <div class=\'timutext\'>'.format(self.url))

        e = e[0]
        e = center_image(e)
        e = self.fix_any(e)
        return e


    def get_answer_all_html(self, html_string):
        pass


    def get_jieda(self, html_string):
        html_string = center_image(html_string)
        html_string = self.html_magic.bewitch(html_string, spider_url=self.url)
        html_string = self.fix_any(html_string)
        return html_string


    def get_fenxi(self, html_string):
        pass


    def fix_any(self, html_string):
        html_string = remove_tag('<h1 ', html_string)
        html_string = html_string.replace('\r\n', ' ')\
                                 .replace('\t', ' ')
        html_string = re_comment.sub('', html_string)
        return html_string


    def is_jy(self, html_string):
        if '<div class="sanwser">' in html_string:
            return True
        elif 'mathtag="math"' in html_string:
            return True
        elif 'MathJye' in html_string:
            return True
        elif 'jyeoo' in html_string:
            return True
        else:
            return False


    def get_subject(self, url):
        k = url[22:28]
        return SUBJ[k]

def make_option(options):
    tr_t = '<tr><td class="aft_option" data="{}">{}</td></tr>'
    option = '<table class="aft_option_wrapper" style="width: 100%;"><tbody class="measureRoot">{}</tbody></table>'.format(
        ''.join([tr_t.format(OPTION_DICT[index], td) for index, td in enumerate(options)]))
    return option



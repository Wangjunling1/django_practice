# -*- coding: utf-8 -*-
from jiajiao1010.items import Jiajiao1010Item,Jiajiao1010QusItem
from afanti_tiku_lib.html.extract import get_html_element
from collections import OrderedDict
from bs4 import BeautifulSoup
from .common import SUBJ,SUBJ_MAPPING
import scrapy
import json
import datetime
import hashlib
import time
import re
import logging
import requests
import copy

logger = logging.getLogger('mylogger')
logger.setLevel(logging.DEBUG)

class Jj1010Spider(scrapy.Spider):
    name = 'jj1010'
    html_id = 10
    allowed_domains = ['1010jiajiao.com']
    # @Author:xiaopeng
    def __init__(self):
        self.sum_page_num = 0
        #初始化日志格式
        fh = logging.FileHandler('jiajiao.log')
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '[%(asctime)s][%(thread)d][%(filename)s][line: %(lineno)d][%(levelname)s] ## %(message)s')
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    def start_requests(self):
        #获取所有科目的信息
        # resp = requests.get("http://1010jiajiao.com/gzyw/index.php")
        # soup = BeautifulSoup(resp.text,'lxml')
        # gaozhong = soup.find(name='div',attrs={'class':'box boxC'})
        # chuzhong = soup.find(name='div',attrs={'class':'box boxB'})
        # xiaoxue = soup.find(name='div',attrs={'class':'box boxA'})
        #
        # gz_urls = {item['href'].replace('index.php','shiti_page_1'):'高中{}'.format(item.getText()) for item in gaozhong.p.find_all('a')}
        # cz_urls = {item['href'].replace('index.php','shiti_page_1'):'初中{}'.format(item.getText()) for item in chuzhong.p.find_all('a')}
        # xx_urls = {item['href'].replace('index.php','shiti_page_1'):'小学{}'.format(item.getText()) for item in xiaoxue.p.find_all('a')}
        #
        # all_urls = gz_urls.copy()
        # all_urls.update(cz_urls)
        # all_urls.update(xx_urls)
        #
        # print(all_urls)
        for url in SUBJ.keys():
            yield scrapy.Request(url,meta={'url':url,'subj':SUBJ[url]})
    def parse(self,response):
        meta = copy.copy(response.meta)
        soup = BeautifulSoup(response.text,'lxml')
        try:
            alabel = soup.find('div', attrs={'class': 'ndwz'}).find_next_siblings('a')[-1]
            page_num = alabel.getText()
        except Exception as e:
            logger.error('[parse][url:{},error:{}]'.format(response.meta['url'],e))
        if response.meta['url'] != 'http://1010jiajiao.com/yuedu_page_0':
            for i in range(int(page_num)):
                url = response.meta['url'].replace('shiti_page_0','shiti_page_{}'.format(i))
                meta['url'] = url
                meta['current_page'] = i
                meta['page_num'] = page_num
                yield scrapy.Request(url,meta=meta,callback = self.parse_detail,dont_filter = True)

    def parse_detail(self,response):
        meta = copy.copy(response.meta)
        quss = response.xpath('//div[@class="xiti"]/a[@class="daan"]/@href').extract()
        for url in quss:
            meta['url'] = url
            yield scrapy.Request(url,meta=meta,callback = self.parse_qus,dont_filter = True)

    def parse_qus(self,response):
        print(response.meta['url'])
        logger.info('[parse_qus][url:{},subj:{},current_page:{},page_num:{}]'.format(response.meta['url'],
                                                                    response.meta['subj'],
                                                                    response.meta['current_page'],
                                                                    response.meta['page_num']))
        soup = BeautifulSoup(response.text,'lxml')
        timu_info = soup.find_all('div',attrs={'class':'timutext'})

        qus = get_html_element('<div class="timutext">',str(timu_info[0]), with_tag=False)[0]
        ans = timu_info[1].find('div',attrs={'class':'sublist'}).find('div',attrs={'class':'answer_inner'})
        ans = get_html_element('<div class="answer_inner"',str(ans), with_tag=False)[0]

        item = Jiajiao1010QusItem()
        item['source'] = 65
        item['subject'] = SUBJ_MAPPING[response.meta['subj']]
        item['html'] = qus

        m2 = hashlib.md5()
        m2.update(qus.encode('utf-8'))
        item['md5'] = m2.hexdigest()
        item['key'] = response.meta['url']
        item['request_info'] = ''
        item['info'] = {'ans':ans}
        item['flag'] = 0
        item['flag_str'] = ''
        yield item


    # @Author:wangkaixi

    # def start_requests(self):
    #     for i in range(9240, 9260):
    #         for j in range(53700,53900):
    #             url = "http://www.1010jiajiao.com/daan/workbook.php?action=edit&bookid="+str(i)+"&chapterid="+str(j)
    #             print(url)
    #             yield scrapy.Request(url=url, callback=self.parse)

    # def parse(self, response):
    #     # sleep防止抓取速度过快
    #     #time.sleep(0.1)
    #     questions = Jiajiao1010Item()
    #     if response.xpath('//div[@class="xiti"]'):
    #
    #         for i in response.css('div.xiti'):
    #             #print(i)
    #             self.html_id += 1
    #
    #
    #             questions['html_id'] = int(self.html_id)
    #             questions['source'] = 65
    #             questions['subject'] = 0
    #             questions['html'] = i.extract()
    #             source_id = re.findall(
    #             r'.*?qid="(.*?)".*?', i.extract())[0]
    #             m2 = hashlib.md5()
    #             m2.update(i.extract().encode('utf-8'))
    #             questions['md5'] = m2.hexdigest()
    #             questions['key'] = "1010jiajiao_book_qs_" + source_id
    #             paper_name = response.css("div.ndwz strong::text").extract()[0]
    #             paper_name = re.findall(r'.*?> (.*?) >.*?', paper_name)[0]
    #             paper_url = str(response)[5:-1]
    #             questions['info'] = str({'paper_url':paper_url,'paper_name':paper_name})
    #
    #             questions['record_time'] = datetime.datetime.now().strftime(
    #                 '%Y-%m-%d %H:%M:%S')
    #             questions['request_info'] = ''
    #             questions['flag_str'] = ''
    #             questions['book_id'] = re.findall(r'.*?bookid=(.*?)&chapterid=.*?', str(response))[0]
    #             if int(str(response)[1:4]) != 200:
    #                 questions['flag'] = 0
    #             else:
    #                 questions['flag'] = None
    #
    #             print('-'*50)
    #             print("完成第%d条数据摘取" % self.html_id)
    #
    #             yield questions



